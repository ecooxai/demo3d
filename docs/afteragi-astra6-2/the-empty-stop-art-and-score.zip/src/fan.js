// Mizuhama repair shop / Model H-34. Original table-fan drawing with enamel, copper and stamped steel.
window.fan=(g,x,y,r,t,opt={})=>{
const {path:P,line:L,ell:E,grad:G,radial:D,rr:RR,text:TXT,R,TAU,clamp,ease}=Art;
const ink='#243538',deep='#233d42',brass='#bf8760',cream='#efe1b7';
const yaw=opt.yaw??.82, spin=opt.spin??0,arrive=opt.arrive??1;
g.save();g.translate(x,y);g.scale(r/100,r/100);if(spin>3)g.translate(.115*Math.sin(t*39.1),.075*Math.sin(t*44.6));g.lineJoin='round';g.lineCap='round';
const gr=(x,y,X,Y,colors)=>G(g,x,y,X,Y,colors);
const enamel=gr(-40,0,42,0,[[0,'#2c4949'],[.13,'#51766e'],[.27,'#a0b19a'],[.43,'#7e9d8c'],[.6,'#577e75'],[.87,'#385959'],[1,'#213b40']]);
if(!opt.noBase){
// Contact shadow and braided power cord. Twin edge is real line variation, not a blurred duplicate.
E(g,1,161,67,7,'rgba(27,31,31,.32)');P(g,'M 39 153 C 84 161 91 144 129 151 S 172 156 193 147',null,'#3e4240',2.8);P(g,'M 40 152 C 84 160 91 143 129 150',null,'#b5976b',.7);
P(g,'M -20 71 Q -19 64 -9 65 L 16 67 Q 23 67 23 75 L 18 136 C 19 143 34 146 43 148 Q 46 151 42 155 Q -9 166 -56 153 Q -60 150 -55 145 L -28 138 Q -20 136 -21 128 Z',enamel,ink,2.4);
P(g,'M -23 113 L -17 110 -18 135 Q -19 140 -29 142 L -48 147 Q -34 148 -22 146 L -5 141 -4 95 Z','#a3b4a0');
P(g,'M 6 94 L 18 85 14 133 Q 12 140 32 147 L 8 149 -8 143 Z','#4b6b64');P(g,'M -55 150 Q -10 161 43 150 L 42 155 Q -7 167 -55 154 Z','#384546',ink,.8);
P(g,'M -17 80 L -13 121 Q -12 125 -8 125 L 0 124 Q 4 123 4 118 L 7 74 Z','#344c4c','#acb6a1',1.2);
for(let k=0;k<4;k++){let sy=88+k*7;P(g,'M -11 '+sy+' L 1 '+(sy-1),null,k===1?'#d09e70':'#7b9081',1.1)}
// Small inherited wear: the family has used this enamel for many summers.
const chips=R(1137);for(let i=0;i<20;i++){let cx=-48+chips()*80,cy=146+chips()*7;if(i%3===0)L(g,[[cx,cy],[cx+1.3+chips()*1.5,cy-.26]],'#c3b58e',.44);else E(g,cx,cy,.24+chips()*.40,.22,'#68736a')}
RR(g,-11,127,15,5,1,'#6e796d','#afa98e',.32);TXT(g,'H-34',-9,131,3.2,'#d7c8a2','Noto Sans',650);
RR(g,-17,139,16,4,1.6,'#283e3e','#b9ad8a',.75);RR(g,-11,137+1.7*(opt.button??0),5,4,1.1,'#dfb87a',ink,.8);
}
// Rear motor, bracket and tilt screw supported behind cage.
g.save();g.scale(yaw,1);
P(g,'M -3 -31 C 30 -51 66 -52 86 -39 C 106 -25 112 0 102 18 Q 93 32 73 39 L 18 38 Z',enamel,ink,2);
for(let j=0;j<8;j++){let xx=75+j*3.4;P(g,'M '+xx+' '+(-35+(j*.9))+' q 10 20 2 40',null,j%2?'#385551':'#b3b39a',1.2)}
P(g,'M 73 30 Q 65 63 32 77 Q 14 83 4 67 L 11 53 Q 33 71 48 50 L 59 29 Z',enamel,ink,2);
E(g,59,34,10,9,'#485d56',ink,1.8);E(g,60,33,6,6,'#bd9c70','#d5bf97',1);L(g,[[56,35],[64,31]],'#645843',1.3);
E(g,0,1,98,98,'rgba(41,60,55,.32)',ink,3.4);
g.save();g.beginPath();g.arc(0,0,96,0,TAU);g.clip();
// A rear guard that catches light on the upper-left quadrant.
for(let j=0;j<18;j++){let a=j*TAU/18;L(g,[[Math.cos(a)*24+7,Math.sin(a)*24],[Math.cos(a)*96,Math.sin(a)*96]],'rgba(47,67,64,.80)',.95)}
const phase=opt.phase??(spin?(.4+spin*t):.43);
if(spin>3){
 const shutter=Math.min(.53,Math.abs(spin)/46),blade='M -8 -10 C -15 -31 -47 -47 -51 -61 Q -54 -71 -39 -80 C -26 -88 -6 -88 5 -78 Q 15 -69 11 -54 C 8 -35 3 -19 9 -9 Z';
 for(let pass=3;pass>=1;pass--)for(let j=0;j<4;j++){g.save();g.rotate(phase+j*TAU/4-shutter*pass/3);g.globalAlpha=.08+(3-pass)*.025;P(g,blade,'#b5bfa5');g.restore()}
}
for(let k=0;k<4;k++){
g.save();g.rotate(phase+k*TAU/4);
const bg=gr(-34,-78,18,8,[[0,'#c5c7ab'],[.14,'#a8bca5'],[.49,'#81a594'],[.72,'#64897e'],[1,'#4c726b']]);
P(g,'M -8 -10 C -15 -31 -47 -47 -51 -61 Q -54 -71 -39 -80 C -26 -88 -6 -88 5 -78 Q 15 -69 11 -54 C 8 -35 3 -19 9 -9 Z',bg,'#354c4d',1.7);
P(g,'M -44 -63 Q -41 -73 -22 -78 Q -4 -83 4 -74 C -8 -75 -22 -69 -32 -57 Z','#c4ccb3');P(g,'M -17 -31 Q -29 -52 -42 -60 C -27 -55 -9 -46 -2 -39 L 1 -21 Z','rgba(49,85,80,.48)');
L(g,[[-43,-69],[-35,-74],[-26,-77]],'#f0d6a6',.8);
g.restore()}
if(spin>3){let a=clamp(spin/44)*.24;E(g,0,0,82,82,'rgba(173,193,169,'+a+')');for(let j=0;j<4;j++){g.strokeStyle='rgba(226,225,187,.25)';g.lineWidth=2.3;g.beginPath();g.arc(0,0,69+j*2,phase+j*.8,phase+j*.8+.63);g.stroke()}}
g.restore();
// Individual curved cage spokes, two-layer outlines, reeded rings.
for(let j=0;j<44;j++){
let a=j*TAU/44,cs=Math.cos(a),sn=Math.sin(a);
let sx=cs*16,sy=sn*16,ex=cs*98,ey=sn*98,cp=[cs*61-5*sn-4,sn*59+5*cs];
let d='M '+sx+' '+sy+' Q '+cp.join(' ')+' '+ex+' '+ey;
P(g,d,null,'rgba(36,49,45,.85)',2.0);P(g,d,null,j%5===0?'#e0c49a':sn<.1?'#b5b9a0':'#889b89',.94);
}
for(let rad of [22,48,76,96,101]){E(g,-1,0,rad,rad,null,'#344344',rad>90?2.9:2.0);g.strokeStyle=rad>96?'#d2b485':'#b5b99d';g.lineWidth=rad>96?1.4:.85;g.beginPath();g.arc(-1,-.5,rad,2.72,5.92);g.stroke()}
for(let a of [.2,2.18,4.2]){let X=Math.cos(a)*99,Y=Math.sin(a)*99;g.save();g.translate(X,Y);g.rotate(a);RR(g,-4,-4,8,8,1.9,'#b49c77',ink,1.3);L(g,[[-3,1],[2,1]],'#f4dfb2',.8);g.restore()}
E(g,-1,0,18,18,'#415953',ink,1.5);E(g,-2,0,15,15,'#b46f4f','#d3ae7d',1.3);E(g,-2,-.2,11.7,11.7,'#b87354','#e2bb8a',.6);
P(g,'M -10 3 Q -4 -7 2 -8 L -2 -1 4 -4 8 -6 Q 5 0 7 3 L 11 3',null,'#f2d8aa',1.55);
// A thin testing ribbon makes the repair visible. Its knot stays on the grille, so only the tail moves.
if(opt.ribbon!==false){
 const flow=ease(clamp(spin/9.5)),sx=-65,sy=-75,pts=[],edges=[];
 for(let j=0;j<=14;j++){let f=j/14;
  let xx=sx+(.8*Math.sin(f*4.7))*f*(1-flow)-flow*(33*f**1.28+5.4*Math.sin(t*8.8-f*5.7)*f**1.7);
  let yy=sy+(1-flow)*31*f+flow*(5.2*f+5.6*Math.sin(t*8.8-f*6.0+.34)*f**1.50);
  pts.push([xx,yy])
 }
 for(let i=0;i<pts.length;i++){let j=Math.min(pts.length-1,i+1),k=Math.max(0,i-1),dx=pts[j][0]-pts[k][0],dy=pts[j][1]-pts[k][1],ln=Math.hypot(dx,dy)||1,f=i/14,ww=(2.32-.5*f)*(1-flow*.66*(.5+.5*Math.sin(t*6.8-f*7))*f);edges.push([[-dy/ln*ww,dx/ln*ww],[dy/ln*ww,-dx/ln*ww]])}
 const side=(i,k)=>[pts[i][0]+edges[i][k][0],pts[i][1]+edges[i][k][1]],cont=pts.map((_,i)=>side(i,0)).concat(pts.map((_,i)=>side(14-i,1)));
 g.beginPath();g.moveTo(...cont[0]);for(const v of cont.slice(1))g.lineTo(...v);g.closePath();g.fillStyle=gr(sx-8,sy-3,sx+5,sy+30,[[0,'#a85c49'],[.42,'#c8845b'],[.67,'#d5a071'],[1,'#a56251']]);g.fill();g.strokeStyle='#72574a';g.lineWidth=.58;g.stroke();
 let seam=pts.map((_,i)=>{let a=side(i,0);return[a[0]*.7+pts[i][0]*.3,a[1]*.7+pts[i][1]*.3]});L(g,seam,'rgba(249,209,151,.68)',.42);
 E(g,sx,sy,2.5,1.56,'#997754','#e1bd8b',.60);
}
g.restore();g.restore()
};
