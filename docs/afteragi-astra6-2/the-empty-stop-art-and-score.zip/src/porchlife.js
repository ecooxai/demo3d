// The repair shop becomes usable public space: clean water, cold towels, a shelf anyone can reach.
(() => {
const {path:P,line:L,ell:E,grad:G,radial:D,rr:RR,text:T,R,TAU,ease,clamp}=Art;
window.porchLife=(g,w,h,t)=>{
 const tall=h>w,u=Math.min(w/(tall?950:1500),h/820),cx=w*(tall?.057:.080),cy=h*(tall?.536:.548);
 g.save();g.translate(cx,cy);g.scale(u,u);g.lineCap='round';g.lineJoin='round';
 // Narrow projecting cedar ledge. Sits behind the figures and is grounded by metal brackets.
 P(g,'M -115 18 L 60 14 76 22 73 26 -109 30 Z','#a38665','#595653',1.45);
 P(g,'M -106 27 L -93 28 -89 53 -96 53 Z','#5a5d56');P(g,'M 43 25 L 51 25 46 44 39 44 Z','#5a5d56');L(g,[[-103,21],[56,17]],'#d4ac7a',1.0);
 // A ceramic water jug with a translucent glazed edge and small beads under the spout.
 let pot=G(g,-47,-47,12,8,[[0,'#547c7b'],[.21,'#83a49b'],[.45,'#b9c9ad'],[.61,'#94b5a8'],[.83,'#648c87'],[1,'#4f7375']]);
 E(g,-22,16,36,5,'rgba(40,52,51,.31)');P(g,'M -44 -47 Q -48 -56 -41 -61 L -13 -61 Q -6 -60 -9 -53 L -9 -43 Q 4 -35 7 -20 L 11 3 Q 12 13 2 16 Q -22 23 -48 16 Q -53 12 -50 0 L -44 -28 Q -42 -40 -44 -47 Z',pot,'#4b6664',1.95);
 P(g,'M -42 -54 L -55 -56 Q -58 -58 -53 -59 L -39 -58 Z','#afc0a8','#647c73',1.28);
 E(g,-27,-60,17,5,'#ccd0b1','#6c8378',1.18);E(g,-27,-60,13,3.3,'#6e9189');
 P(g,'M -8 -44 C 11 -52 22 -40 19 -20 Q 17 -4 8 0',null,'#516f6e',7.8);P(g,'M -7 -45 C 9 -50 17 -40 16 -27 Q 15 -16 10 -12',null,'#93ada1',4.8);
 P(g,'M -42 -38 Q -40 -30 -46 -1 Q -48 8 -41 10 L -36 11 Q -40 4 -38 -7 L -34 -33 Z','#b6c6a9');
 for(let j=0;j<10;j++){let x=-34+(j*19%36),y=-27+(j*23%35),q=.7+(j%3)*.4;E(g,x,y,q,q*1.43,'rgba(209,219,190,.69)','#809b91',.32);E(g,x-.2*q,y-.42*q,q*.34,q*.36,'#e4e0bf')}
 // Stacked glass tumblers. The upper ellipses preserve their thin glass character.
 for(let k=0;k<3;k++){let x=24+k*10,dy=(k%2)*1.7;P(g,'M '+(x-6)+' '+(-1+dy)+' l 12 0 -1 15 q -4 3 -10 0 Z','rgba(180,200,180,.44)','#8c9f91',.8);E(g,x,-1+dy,6,1.6,null,'#cbd1b7',.9);L(g,[[x-4,2+dy],[x-3,11+dy]],'#d6d8bc',.8)}
 // Edge of a clean folded cloth responds to the same fan breeze as the hanging bell.
 let wave=1.04*Math.sin(t*3.05+.7);P(g,'M -92 10 L -65 7 -51 10 -52 16 -91 19 Z','#9ca898','#677f79',.85);
 P(g,'M -91 14 L -56 12 -54 19 Q -67 '+(24+wave)+' -84 23 L -92 21 Z','#b6bba3','#7d9186',.8);
 for(let j=0;j<3;j++)L(g,[[-87+j*4,17],[-84+j*4,22+wave*.2]],'#789b95',.65);
 g.restore()
};
})();
