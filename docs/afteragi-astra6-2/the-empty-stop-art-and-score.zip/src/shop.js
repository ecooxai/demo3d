/* First Light • interior plates. Original hand-built Canvas2D, no external assets.
   All dimensions are adapted to a 1000-unit-high layout. Layer edges overscan.
   Public: shop(ctx,width,height,sceneTimeSeconds,'bench'|'office'|'table'). */
(()=>{
'use strict';
const ink='#34393c',cache=new Map();
let c,W,H=1000,small=false;
const R=(x,y,w,h,k)=>{c.fillStyle=k;c.fillRect(x,y,w,h)};
const G=(x,y,X,Y,stops)=>{const g=c.createLinearGradient(x,y,X,Y);for(let i=0;i<stops.length;i++)g.addColorStop(i/(stops.length-1),stops[i]);return g};
function P(a,k,edge,lw=2){c.beginPath();c.moveTo(a[0],a[1]);for(let i=2;i<a.length;i+=2)c.lineTo(a[i],a[i+1]);c.closePath();if(k){c.fillStyle=k;c.fill()}if(edge){c.lineWidth=lw;c.strokeStyle=edge;c.stroke()}}
function L(a,k,lw=2){c.beginPath();c.moveTo(a[0],a[1]);for(let i=2;i<a.length;i+=2)c.lineTo(a[i],a[i+1]);c.lineCap='round';c.lineJoin='round';c.lineWidth=lw;c.strokeStyle=k;c.stroke()}
function Q(a,k,lw=2){c.beginPath();c.moveTo(a[0],a[1]);for(let i=2;i<a.length;i+=4)c.quadraticCurveTo(a[i],a[i+1],a[i+2],a[i+3]);c.lineCap='round';c.lineWidth=lw;c.strokeStyle=k;c.stroke()}
function E(x,y,rx,ry,k,edge,lw=2){c.beginPath();c.ellipse(x,y,rx,ry,0,0,2*Math.PI);if(k){c.fillStyle=k;c.fill()}if(edge){c.strokeStyle=edge;c.lineWidth=lw;c.stroke()}}
const frac=v=>v-Math.floor(v), hash=i=>frac(Math.sin(i*127.1+311.7)*43758.5453);
const box=(x,y,w,h,k,b,d=2)=>{R(x,y,w,h,b);R(x+d,y+d,w-2*d,h-2*d,k)};
const at=(x,y,s,fn)=>{c.save();c.translate(x,y);c.scale(s,s);fn();c.restore()};
function clip(x,y,w,h,fn){c.save();c.beginPath();c.rect(x,y,w,h);c.clip();fn();c.restore()}
function skyline(x,y,w,h,kind){ // inhabited neighborhood, not a generic skyline
const warm=kind==='table',cool=kind==='office';
clip(x,y,w,h,()=>{
 R(x,y,w,h,G(0,y,0,y+h,warm?['#687591','#b8a3a5','#f7c6a5']:cool?['#849ca5','#bdd2cc','#dde4d3']:['#8ab5c1','#d7ddc3','#fae0a7']));
 for(let n=0;n<9;n++){let xx=x+w*hash(n+64),yy=y+h*(.07+.31*hash(n+41)),ww=w*(.04+.16*hash(n+34));P([xx-ww*.3,yy+4,xx,yy,xx+ww*.75,yy-3,xx+ww,yy,xx+ww*.4,yy+5],warm?'#d6b4b355':'#eeefdb93')}
 for(let z=0;z<2;z++){let xx=x-60;for(let i=0;xx<x+w+120;i++){let ww=30+57*hash(i+81+z*71),hh=h*(.09+(.31+.09*z)*hash(i+23+z*82)),base=y+h*(.84+.2*z),top=base-hh;
 let faces=warm?[['#9597ab','#83889e'],['#727f91','#616e82']]:cool?[['#98aeb2','#8aa1a4'],['#759097','#617e83']]:[['#b4bbae','#a5b2a9'],['#96a59b','#799192']];let [face,shadow]=faces[z];
 R(xx,top,ww,hh,face);P([xx+ww*.72,top,xx+ww,top-3,xx+ww,base,xx+ww*.72,base],shadow);
 R(xx-2,top-3,ww+4,4,shadow);
 if(i%3===0){R(xx+4,top-8,ww*.29,5,face);L([xx+ww*.5,top,xx+ww*.5,top-14],shadow,1.2)}
 for(let r=0;r<Math.min(8,hh/15-1);r++)for(let j=0;j<Math.max(1,(ww-12)/14);j++){let xx2=xx+5+j*12;R(xx2,top+7+r*15,5+2*hash(i+4*j),4,warm&&hash(i+r*13+j)>.67?'#f4cea1':shadow)}
 if(z===1&&i%3===1){P([xx-5,top+2,xx+8,top-10,xx+ww*.69,top-13,xx+ww,top],warm?'#6c7485':'#80908b');L([xx+6,top-10,xx+ww*.69,top-13],warm?'#9a98a1':'#afb8a9',1.8)}xx+=ww+3+hash(i)*12}}
 let pole=x+w*.78;L([pole,y+h+4,pole-2,y+h*.28],warm?'#586374':'#758a87',3);L([pole-11,y+h*.36,pole+13,y+h*.35],warm?'#586374':'#758a87',2);
 for(let z=0;z<3;z++)Q([x-5,y+h*(.20+z*.027),x+w*.5,y+h*(.43+z*.022),pole,y+h*(.315+z*.025),x+w*.93,y+h*(.31+z*.024),x+w+6,y+h*(.22+z*.024)],warm?'#62697b':'#869790',1.2);
});
}
function windowPane(x,y,w,h,kind){skyline(x+7,y+5,w-14,h-12,kind);let frame=kind==='table'?'#584a4c':kind==='office'?'#43565c':'#60625a';let lit=kind==='table'?'#b78a71':kind==='office'?'#a9b7b4':'#d4bc86';
 c.save();c.beginPath();c.rect(x+7,y+5,w-14,h-12);c.clip();for(let i=0;i<3;i++){let xx=x+w*(.11+i*.44);P([xx,y,xx+w*.08,y,xx-w*.18,y+h,xx-w*.32,y+h],'#f3eee3' + (kind==='table'?'0c':'22'))}c.restore();
 R(x,y,w,8,frame);R(x,y+h-10,w,10,frame);R(x,y,9,h,frame);R(x+w-9,y,9,h,frame);
 for(let i=1;i<(w>450?3:2);i++){let xx=x+w*i/(w>450?3:2);R(xx-3,y,7,h,frame);R(xx+4,y+2,2,h-5,lit);R(xx+7,y+h*.63,4,11,frame)}
 R(x,y+h*.32,w,5,frame);R(x-4,y+h,w+8,5,lit);R(x-4,y+h+5,w+9,7,frame)}
// Distant details are grouped into light and shadow families so the character holds contrast.
function plants(x,y,s,home=false){at(x,y,s,()=>{let twig=home?'#515653':'#536b61',cols=home?['#657f66','#56715d','#394f49']:['#759580','#618673','#486b60'];for(let n=0;n<11;n++){let bend=(hash(n+4)-.5)*105,dy=-37-73*hash(n+93);
 Q([0,0,bend*.25,dy*.69,bend,dy],twig,1.8);for(let j=1;j<6;j++){let k=j/6,xx=bend*(k*.62+k*k*.38),yy=dy*k;for(let a of [-1,1]){let sx=a*(17+6*hash(n+j))*(1-k*.55),sy=-7-6*k;P([xx,yy,xx+sx*.47,yy+sy-3,xx+sx,yy+sy,xx+sx*.59,yy+sy+3],cols[(n+j+(a===1?1:0))%3])}}}
 P([-23,-1,24,-1,18,32,-15,33],home?'#9a6e5e':'#a47c64',ink,1.4);P([7,1,24,-1,18,32,4,32],home?'#735956':'#7a665e');R(-26,-3,52,6,home?'#ba8971':'#c09877')})}
function shelves(x,y,w,h,kind){let p=kind==='bench'?['#57594f','#434c4b','#b19c74','#a89374','#d0b991','#727569','#827863']:['#655853','#504c4c','#b59877','#ad8971','#c8ab83','#80786d','#997b66'];
 R(x,y,w,h,p[0]);R(x+4,y+4,w-8,h-8,G(0,y,0,y+h,[p[1],p[0]]));let step=h/3;
 for(let j=0;j<3;j++){let base=y+step*(j+1)-8;let xx=x+8;for(let i=0;xx<x+w-17;i++){let typ=(i+j*3)%6;let bw=typ<2?26+24*hash(i+j+22):typ<4?10+15*hash(i+j+5):20+15*hash(i*7+j);if(xx+bw>x+w-6)break;let bh=step*(.26+.54*hash(i+13*j+2));let col=p[2+(i+2*j)%5];
 if(typ<2){box(xx,base-bh,bw,bh,col,p[1],1.4);R(xx+1,base-bh+3,bw-2,3,p[4]);R(xx+4,base-bh*.54,bw*.45,Math.max(3,bh*.12),p[4]);L([xx+bw*.72,base-bh+6,xx+bw*.72,base-3],p[6],1.1)}
 else if(typ<4){P([xx+2,base-bh,xx+bw-1,base-bh+1,xx+bw,base,xx,base],col,p[1],1.5);R(xx+4,base-bh+5,2,bh-9,p[4]);R(xx+1,base-8,bw-2,3,p[4])}
 else{P([xx+2,base-bh+4,xx+bw-2,base-bh+4,xx+bw,base-4,xx+bw-2,base,xx+1,base],col,p[1],1.4);R(xx+3,base-bh,bw-5,5,p[3]);R(xx+2,base-bh*.65,bw-3,bh*.30,p[4])}xx+=bw+2+hash(i+7)*4}
 R(x-2,base,w+4,4,p[4]);R(x-2,base+4,w+4,8,p[1])}R(x,y,5,h,p[2]);R(x+w-5,y,5,h,p[1])}
function scratches(x,y,w,h,n,col){for(let i=0;i<n;i++){let xx=x+w*hash(i+49),yy=y+h*hash(i+378);L([xx,yy,xx+2+hash(i+18)*13,yy-hash(i+5)*1.7],col,.5+hash(i+7)*.7)}}
function grain(x,y,w,h,n,colors){for(let i=0;i<n;i++){let xx=x+w*hash(i+443),yy=y+h*hash(i+374);R(xx,yy,1+hash(i+15)*5,.5+hash(i+55)*1.8,colors[i%colors.length])}}
function drawers(x,y,w,h,rows,cols){R(x,y,w,h,'#514f48');let bw=w/cols,bh=h/rows;for(let j=0;j<rows;j++)for(let k=0;k<cols;k++){let xx=x+bw*k,yy=y+bh*j;box(xx+1,yy+2,bw-2,bh-4,['#7c7b69','#85816c','#75786a'][(j+k)%3],'#4d544f',2);L([xx+4,yy+5,xx+bw-5,yy+5],'#aca386',1.8);box(xx+bw*.30,yy+bh*.22,bw*.34,bh*.23,'#c7ba99','#575c52',1.3);L([xx+bw*.39,yy+bh*.32,xx+bw*.52,yy+bh*.32],'#878570',.8);L([xx+bw*.42,yy+bh*.63,xx+bw*.6,yy+bh*.63],'#555c52',2.6)}}
function paintWall(x,y,w,h,colors){R(x,y,w,h,G(x,y,x+w,y+h,colors));grain(x,y,w,h,Math.round(w*.65),['#463e4320','#fff2cf27','#d5caad24'])}
function woodTop(y,depth,edge,col){P([-45,y+17,W*.64,y-8,W+45,y+7,W+45,y+depth,-45,y+depth+7],G(0,y,W*.22,y+depth,col));P([-40,y+depth+4,W+40,y+depth-4,W+40,y+depth+edge,-40,y+depth+edge+8],col[2]);L([-30,y+depth+4,W+30,y+depth-4],col[0],3);
 for(let i=0;i<30;i++){let u=hash(i+388),xx=W*hash(i+553),yy=y+7+depth*u;Q([xx,yy,xx+20,yy-1,xx+55+hash(i+443)*112,yy-2],i%3?'#825d481f':'#f7d39a49',.8+u*.7)}
 }
function bench(back){
 const winW=small?W*.39:W*.34,wy=small?143:143,wh=small?328:345;let vx=small?-25:W*.025;const sx=small?W*.82:W*.79;
 if(back===0){paintWall(-24,-12,W+48,760,['#d6c9a5','#c5c0a5','#aaa997']);P([-25,32,W+22,-3,W+22,95,W*.72,124,-25,162],G(0,0,0,160,['#777d72','#b0ad94']));P([-20,118,W+25,52,W+25,78,-20,146],'#7b7d6c');L([-20,147,W+22,79],'#e3cca0',4);
 for(let i=0;i<6;i++){let ax=W*(i/4.5-.16);P([ax,-13,ax+18,-13,ax+W*.14,130-ax/W*64,ax+W*.14-8,130-ax/W*64],'#70796b')}
 windowPane(vx,wy,winW,wh,'bench');
 // Sun rays and the cast shadow of old transom glazing.
 c.save();c.beginPath();c.rect(vx+winW+6,127,W*.66,557);c.clip();P([vx+winW,175,W*.70,367,W*.88,587,vx+winW,407],'#ffe7ac72');P([vx+winW,260,W*.67,445,W*.69,470,vx+winW,284],'#8d97854a');P([vx+winW+68,171,vx+winW+83,184,W*.73,575,W*.71,578],'#8d978550');c.restore();
 R(-20,526,W+40,190,'#949989');R(-20,523,W+40,4,'#ced0ad');for(let xx=-12;xx<W+20;xx+=small?69:82){L([xx,530,xx+1,709],'#7c867857',2);L([xx+3,530,xx+4,707],'#c1bd9c80',1)}
 // Conduit, neatly tied at clips, and two certificates behind the work area.
 Q([-12,185,W*.19,175,W*.35,156,W*.42,149,W*.53,144],'#828874',2.6);
 for(let i=0;i<4;i++){let xx=W*(.354+i*.048);L([xx,158-5*i,xx+2,164-5*i],'#9b977d',2)}
 let fx=small?W*.50:W*.50,fy=small?227:239,sz=small?.71:.90;
 at(fx,fy,sz,()=>{box(0,0,99,80,'#c6b698','#7c7969',3);box(5,5,89,70,'#d9cbb0','#a3967b',2);R(29,16,37,3,'#a69c83');for(let i=0;i<5;i++)R(18+(i%2)*4,28+i*5,62-(i%3)*7,1.7,'#aea48b');E(74,60,5,5,'#a58b78');box(111,12,54,60,'#c1b69b','#777c68',3);P([116,60,132,45,139,50,151,34,159,39,159,66,116,66],'#989e86');E(132,31,4,4,'#d2c8aa')});
 // Fender corner and organized workshops exhibit accumulated, utilitarian detail.
 shelves(sx,147,W-sx+26,256,'bench');let xx=small?W*.77:W*.76,ww=W-xx+22;box(xx,430,ww,178,'#9d9b80','#697260',3);
 for(let j=0;j<10;j++)for(let i=0;i<ww/15;i++)E(xx+7+i*15,439+j*16,1.1,1.1,'#767c67');
 for(let i=0;i<(small?3:6);i++){at(xx+17+i*25,458+9*(i%2),.82,()=>{if(i%3===0){Q([-4,1,-13,-6,-4,-13,-5,-5,0,-3,6,-6,8,-13,12,-3,4,2],'#55635d',3.4);L([1,0,-2,43],'#52635f',6);E(-2,43,2,2,'#a4a58b')}else if(i%3===1){L([0,4,0,47],'#626d65',3);P([-4,-1,4,-1,5,16,3,25,-3,25,-5,18],'#ac7050','#697466',1.2)}else{Q([-5,-10,-8,-2,-2,4,3,8,4,35],'#5b6b62',3);Q([5,-10,8,-2,2,4,-4,8,-6,35],'#5b6b62',3);L([4,17,6,36],'#977c5f',4);L([-4,18,-7,36],'#977c5f',4)}})}
 // transom pocket and old cupboard at far side
 let rx=small?W*.80:W*.82;drawers(rx,617,W-rx+23,108,3,4);
 let wx=vx+13;plants(wx+winW*.15,wy+wh-14,small?.57:.82);let bs=small?.66:.83;at(vx+winW*.74,wy+wh-3,bs,()=>{for(let j=0;j<3;j++){box(j*9,-7-5*j,57-j*10,6,'#b3ac8c','#818771',1)}});
 // Side electric mains rail
 R(-16,629,W*.21,43,'#898d79');R(-14,630,W*.21,3,'#b1b395');for(let i=0;i<3;i++){let xx=11+i*31;box(xx,642,19,16,'#aaa98c','#737b69',1.3);R(xx+6,647,2,5,'#707967');R(xx+11,647,2,5,'#707967')}
 }else{
 R(-25,704,W+50,330,G(0,708,W*.3,1000,['#8a7c60','#716752','#545851']));
 let ww=small?W*.26:W*.28;for(let i=0;i<4;i++){let xx=i*ww-8;box(xx,839,ww-6,170,'#7a735d','#575c52',3);P([xx+7,846,xx+ww-15,846,xx+ww-15,857,xx+10,854],'#aaa080');box(xx+ww*.38,863,ww*.23,8,'#797e6b','#4c534b',1.5)}
 woodTop(705,109,18,['#d9bf8d','#b79b73','#79674f']);
 // fine edge, pencilled measuring ticks and dark dowel holes
 for(let i=0;i<Math.ceil(W/11);i++)L([i*11,811-i*7/(W/11),i*11+1,815+(i%5===0?4:0)-i*7/(W/11)],'#87795d',.9);
 for(let i=0;i<10;i++)E(35+i*W*.105,776-i*.5,1.8,1,'#95815f');scratches(0,720,W,79,50,'#705e4328')
 }
}
function dispatchMap(x,y,w,h){let frame='#46595b';box(x,y,w,h,'#b3c0ac',frame,5);box(x+6,y+6,w-12,h-12,'#b6c2b3','#d1d1ae',2);
 clip(x+8,y+8,w-16,h-16,()=>{for(let a=0;a<12;a++){let xx=x+a*w/10;L([xx-30,y,xx+w*.21,y+h],'#cdd0b751',3)}for(let a=0;a<9;a++){let yy=y+a*h/8;L([x,yy,x+w,yy-h*.1],'#cdd0b77a',3)}
 let pathSet=[['#7b9183',[[-.01,.19],[.18,.19],[.39,.39],[.73,.39],[.85,.29],[1,.29]]],['#af9372',[[-.01,.77],[.16,.77],[.36,.57],[.66,.57],[.85,.74],[1,.74]]],['#788f98',[[.25,-.1],[.25,.23],[.49,.47],[.49,.68],[.59,.8],[.59,1.1]]]];for(let [color,pts] of pathSet){let xy=pts.flatMap(p=>[x+p[0]*w,y+p[1]*h]);L(xy,color,3.4);for(let j=1;j<pts.length-1;j++){let [u,v]=pts[j];E(x+u*w,y+v*h,2.6,2.6,'#ded9bd',color,1.1)}}
 R(x+13,y+h-26,w*.22,2.7,'#84978a');R(x+13,y+h-19,w*.14,1.5,'#93a298');Q([x+w*.78,y-4,x+w*.57,y+h*.20,x+w*.74,y+h*.42,x+w*.99,y+h*.54,x+w*.85,y+h+3],'#98afaa8c',w*.026)});
}
function smallClock(x,y,s){at(x,y,s,()=>{E(1.5,2,28,28,'#46515c44');E(0,0,27,27,'#c9cabb','#52656a',3);for(let i=0;i<12;i++){let a=i*Math.PI/6-.5*Math.PI;L([21*Math.cos(a),21*Math.sin(a),24*Math.cos(a),24*Math.sin(a)],'#7a8a88',i%3?1:2)}L([0,0,-10,-5],'#52656b',2.6);L([0,0,4,-16],'#51666b',1.9);E(0,0,1.8,1.8,'#566d70')})}
function office(back){if(back===0){
paintWall(-24,-22,W+48,800,['#aabbbb','#9aaeb0','#778f96']);P([-24,-24,W+24,-24,W+24,103,W*.53,130,-24,84],G(0,0,0,130,['#5b727c','#8c9d9d']));L([-22,87,W*.54,133,W+20,106],'#607b81',4);L([-20,91,W*.54,137,W+20,110],'#a3b2ae',2);
// Recessed fluorescent strip in two perspective planes. 
P([W*.13,42,W*.42,62,W*.415,71,W*.125,51],'#486672');P([W*.138,44,W*.411,63,W*.409,67,W*.136,48],'#dce0c8');
for(let i=0;i<7;i++){let xx=W*(i*.20-.16);L([xx,-10,W*.53+(xx-W*.54)*.71,122],'#748b8e',2)}
 let xw=small?W*.60:W*.55,yw=small?179:163,ww=W-xw+25,hh=small?326:347;windowPane(xw,yw,ww,hh,'office');
 // The transit shed across the window and booth's solar shading slats.
 clip(xw+8,yw+8,ww-16,hh-18,()=>{P([xw-3,yw+hh*.79,xw+ww*.68,yw+hh*.64,xw+ww+4,yw+hh*.67,xw+ww,yw+hh*.73,xw+ww*.70,yw+hh*.70,xw,yw+hh*.85],'#677f80');for(let i=0;i<5;i++)L([xw+ww*i*.27,yw+hh*.78-9*i,xw+ww*i*.27,yw+hh],'#748989',3)});
 for(let i=0;i<4;i++){let yy=yw+9+i*11;P([xw+6,yy,xw+ww-8,yy,xw+ww-8,yy+4,xw+6,yy+7],i%2?'#778b8d':'#7e9191');L([xw+9,yy,xw+ww-8,yy],'#b5c2ba',1.1)}
 const mx=small?-W*.035:W*.04;dispatchMap(mx,small?204:185,small?W*.41:W*.34,small?220:270);
 smallClock(small?W*.493:W*.45,small?218:201,small?.68:.81);
 R(-24,533,W+48,250,G(0,535,0,768,['#70888d','#647d83']));R(-24,528,W+48,5,'#adbbb3');R(-24,534,W+48,7,'#566e75');
 for(let j=0;j<7;j++){let xx=j*W/6.2;L([xx,544,xx,714],'#5a757a',1.6);L([xx+2,546,xx+2,706],'#809599',1.2)}
 // Railside communication panel and neighboring windowed equipment cabinet, peripheral.
 let lx=small?-45:W*.018;at(lx,560,small?.75:.89,()=>{box(0,0,164,99,'#839396','#4d676e',2);box(9,8,144,58,'#9da9a1','#687e80',1.6);for(let i=0;i<10;i++)L([16,13+i*4.9,99,13+i*4.9],'#697d80',1.5);L([111,13,111,61],'#77888a',1);for(let j=0;j<2;j++)for(let i=0;i<3;i++)E(121+10*i,22+20*j,2.3,2.3,j?'#c7ba89':'#a2ac92');box(13,75,52,13,'#9aa7a1','#657d80',1.4);R(82,79,58,3,'#61777e')});
 let rx=small?W*.9:W*.84;box(rx,548,W-rx+20,178,'#7f9394','#526d73',3);for(let i=0;i<3;i++)box(rx+7+(W-rx)*i/3,560,(W-rx)/3-5,102,'#90a19c','#607b7d',2);
 P([xw+ww*.08,537,xw+ww*.27,537,xw+ww*.76,724,xw+ww*.45,724],'#c4cdb52b');
 }else{R(-22,735,W+44,290,G(0,740,W*.4,1000,['#728185','#576c74','#41555f']));P([-20,761,W*.69,720,W+20,730,W+20,852,-20,878],G(0,740,0,880,['#bac2b4','#a7b3a8','#849998']));P([-20,878,W+20,851,W+20,862,-20,892],'#536e76');L([-20,878,W+20,850],'#d0ceba',3);for(let i=0;i<4;i++){let xx=W*(.02+.28*i);L([xx,899-25*i/4,xx,1008],'#415962',2);box(xx+15,910-25*i/4,W*.08,6,'#929e96','#506770',1)}
 // Fine join in two desk panels, no devices in character action corridor.
 L([W*.87,730,W*.95,851],'#829594',1.7);scratches(0,775,W,60,24,'#72898c31')
}}
function home(back){let ww=small?W*.39:W*.39,wx=small?-22:W*.018,wy=small?175:148,wh=small?349:382;
 if(!back){
 paintWall(-25,-20,W+50,830,['#c7a489','#bd9881','#8d7272']);P([-24,-22,W+24,-22,W+24,98,W*.48,119,-24,81],G(0,0,0,119,['#655b62','#8a7475']));
 P([-20,74,W*.48,111,W+24,89,W+24,104,W*.48,127,-20,90],'#695c60');L([-20,91,W*.48,128,W+20,106],'#c49e7c',2.7);let z=W*.725;L([z,121,z,613],'#947d73',2);L([z+3,121,z+3,613],'#d3af8b69',2);
 // Sliding door opened to an evening neighborhood; irregular linen drapes soften the architecture.
 windowPane(wx,wy,ww,wh,'table');R(wx-7,wy-15,ww+11,7,'#795f60');L([wx-5,wy-16,wx+ww+5,wy-16],'#c2a286',1.8);
 let ex=wx+ww;P([ex-ww*.16,wy-11,ex+5,wy-10,ex+5,wy+wh+3,ex-ww*.04,wy+wh,ex-ww*.1,wy+wh+5,ex-ww*.108,wy+wh-64,ex-ww*.041,wy+wh*.57,ex-ww*.145,wy+wh*.20],'#c1ad9e','#8b797a',1.4);P([ex-ww*.09,wy-9,ex-ww*.056,wy-9,ex-ww*.007,wy+wh*.58,ex-ww*.042,wy+wh*.56],'#a89991');L([ex-ww*.067,wy+wh*.568,ex+.6,wy+wh*.577],'#8d7870',4);
 P([wx-3,wy-11,wx+ww*.135,wy-10,wx+ww*.054,wy+wh*.48,wx+ww*.029,wy+wh*.56,wx+ww*.078,wy+wh+2,wx+ww*.035,wy+wh+6,wx-3,wy+wh+1],'#c5b1a0','#998681',1.2);
 // Uneven, hand-finished wooden wainscoting, domestic rather than high-tech.
 R(-25,573,W+50,300,G(0,573,0,790,['#9b7766','#926f63','#795e5c']));R(-25,568,W+50,7,'#cab08b');R(-25,575,W+50,5,'#896e62');
 for(let i=0;i<W/66+1;i++){let xx=i*66-26;L([xx,581,xx-1,774],'#82695d',1.5);L([xx+3,581,xx+2,772],'#b0896e',1)}
 // Reflected dusk on plaster.
 P([wx+ww+5,wy+63,W*.68,316,W*.728,437,wx+ww+5,wy+200],'#eed4a72e');P([wx+ww+5,wy+215,W*.735,457,W*.735,490,wx+ww+5,wy+246],'#e0c19b2b');
 // A tiny family history: framed pressed leaves and a faded print instead of pictures of faces.
 at(small?W*.55:W*.51,small?241:224,small?.71:.94,()=>{box(0,0,102,130,'#d0bea0','#76635e',5);box(12,12,78,106,'#c9c0a2','#b39d80',2);Q([44,104,48,79,64,47,70,36,75,25],'#7c8069',1.7);for(let j=0;j<6;j++){let xx=48+j*4,yy=91-j*10;P([xx,yy,xx-13,yy-5,xx-18,yy-13,xx-8,yy-10],'#a29f78');P([xx+1,yy-4,xx+15,yy-12,xx+19,yy-21,xx+7,yy-14],'#9b9974')}});
 // Unlit bookcase, amber wall lamp; objects remain softly grouped.
 const sx=small?W*.84:W*.804;shelves(sx,371,W-sx+18,253,'table');
 let lx=small?W*.91:W*.86;at(lx,148,small?.75:.94,()=>{L([0,-63,0,0],'#65585a',3.5);P([-10,0,10,0,21,14,36,27,38,30,-37,30,-36,26,-20,14],'#7e685f','#6b5959',2);P([-36,30,37,30,30,35,-28,35],'#e1b387');E(0,33,9,4,'#f4d0a0')});
 const side=small?W*.91:W*.87;plants(side,559,small?.54:.62,true);
 // Low sideboard under window with sliding fronts and small woven seams.
 let cw=small?W*.24:W*.27;R(-20,615,cw+20,150,'#846558');P([-20,610,cw-4,607,cw+13,615,-20,623],'#bf9474');R(-20,622,cw+32,7,'#765f56');for(let i=0;i<2;i++){box(-15+i*cw/2,634,cw/2-3,93,'#a08267','#7d665a',2);for(let j=0;j<12;j++)L([-8+i*cw/2+j*(cw/2-18)/12,637,-8+i*cw/2+j*(cw/2-18)/12,722],'#94775f',1)}}
 else{
 R(-24,753,W+48,275,G(0,760,0,1000,['#8f6c60','#75595b','#5c5058']));
 // Long wide table with a pale honey semicircular edge in the foreground.
 P([-26,826,W*.13,794,W*.78,752,W+26,786,W+26,996,-26,1022],G(0,761,W*.14,1010,['#ddb58d','#c59977','#a67c65']));
 L([-20,827,W*.13,794,W*.78,752,W+22,786],'#e6c8a0',3);
 P([-22,1008,W+22,974,W+22,998,-22,1038],'#795c55');L([-22,1005,W+22,973],'#d1a57c',2.8);
 for(let j=0;j<3;j++){let yy=819+j*61;L([-30,yy+23,W+34,yy-23],'#ad826943',1.5)}for(let i=0;i<85;i++){let xx=W*hash(i+456),yy=802+180*hash(i+622),sz=24+hash(i+887)*138;Q([xx,yy,xx+sz*.42,yy-1.5-hash(i+33)*3.5,xx+sz,yy-2.9],i%3?'#9e71571e':'#ffe3ae31',.6+hash(i+911)*1.2)}
 }
}
// Painted finishing pass: the frame edges describe nearby architecture, the central stage stays quiet.
function bloom(x,y,rx,ry,col){c.save();c.translate(x,y);c.scale(rx,ry);let g=c.createRadialGradient(0,0,0,0,0,1);g.addColorStop(0,col);g.addColorStop(1,'rgba(0,0,0,0)');R(-1,-1,2,2,g);c.restore()}
function bolt(x,y,s,body,shine){E(x,y,s,s,body);L([x-s*.45,y+s*.38,x+s*.37,y-s*.38],shine,Math.max(.6,s*.35))}
function signrail(x,y,w){box(x,y,w,35,'#294958','#627e83',2);R(x+3,y+2,w-6,3,'#839e99');
 for(let j=0;j<2;j++){let yy=y+11+j*10;E(x+9,yy+1,2.6,2.6,j?'#bdab7c':'#b67c65');for(let a=0;a<10;a++){let p=x+15+a*(w-37)/11;R(p,yy-1,(w-40)/11*(.3+hash(a+j)*.55),1.7,j?'#a2b2a6':'#bdc1a7');if(a%3===0)R(p,yy+3,3,.9,'#9eaea5')}}
 for(let j=0;j<4;j++)R(x+w-12,y+8+j*5,6,1,'#94a69c')}
function rafter(x,y,s){at(x,y,s,()=>{
 // The view from the workshop doorway: just a sliver of an articulated shade and spine.
 P([-34,-11,2,-16,56,35,50,43],'#37444a','#334046',2);P([-17,-2,-4,-7,50,41,45,45],'#6b7270');Q([0,7,20,40,49,53,56,61,59,73],'#485654',2);
 at(52,43,1,()=>{E(0,0,8,8,'#66726d','#3f5050',2);bolt(0,0,4,'#a7a58a','#60695e')});
 P([54,42,60,44,77,78,72,81],'#495a59','#34484a',1.5);P([69,77,80,73,86,86,76,93,64,87],'#74817a','#4e5d58',1.7);
 P([66,86,80,80,91,83,107,90,123,105,129,113,128,117,51,145,45,143,45,137,49,121,58,97],'#4c5d5a','#38494c',2.2);P([65,90,79,83,90,86,102,92,113,101,99,97,81,95],'#839084');P([46,138,75,124,115,111,128,112,129,116,83,135,47,146,43,144],'#5b675f','#394d4c',1.8);P([49,142,83,128,126,115,121,122,68,143,53,146],'#e6c994');L([49,139,70,129,104,117],'#bac1a2',1.3)
})}
function intricateMap(x,y,w,h){clip(x+10,y+10,w-20,h-20,()=>{
 // ghosted cadastral blocks and a pair of bays, then station rings on the printed map.
 for(let j=0;j<65;j++){let ax=x+w*hash(j+467),ay=y+h*hash(j+547),size=3+hash(j+83)*20;P([ax,ay,ax+size*.75,ay-2,ax+size,ay+5,ax+2,ay+6],j%3?'#899e9526':'#b6b49e4d',null)}
 for(let j of [0,1]){let sx=x+w*(j?.08:.63),sy=y+h*(j?.65:.25);for(let i=0;i<9;i++){let xx=sx+i*w*.025,yy=sy+Math.sin(i*.73)*4;L([xx,yy,xx+w*.021,yy+1],'#8b9c9266',1.3);L([xx+2,yy-2,xx+3,yy+2],'#82968d6b',1)}}
 let pts=[[.18,.19],[.39,.39],[.73,.39],[.85,.29],[.16,.77],[.36,.57],[.66,.57],[.85,.74],[.25,.23],[.49,.47],[.49,.68],[.59,.8]];
 pts.forEach(([u,v],i)=>{let px=x+w*u,py=y+h*v;E(px,py,i%4?2.1:3,i%4?2.1:3,'#e6dfc1','#829489',.9);R(px+4,py-5,5+hash(i+19)*11,1.4,'#70877e99');if(i%3===1)R(px+5,py-2,6,1,'#91a295')});
 let k=x+13,l=y+17;R(k,l,w*.19,2.4,'#799286');R(k,l+5,w*.1,1.1,'#8aa092');
});}
function knit(x,y,s){at(x,y,s,()=>{P([-3,1,27,1,29,52,24,62,14,60,6,65,-2,61],'#c5a893','#8c7971',1.4);P([4,2,9,2,11,61,7,62],'#a68f83');P([22,2,26,2,28,52,25,61,22,59],'#9c867c');for(let i=0;i<3;i++)L([0,49+i*4,9,51+i*4,17,49+i*4,27,48+i*4],'#a2877b',1.2);L([-4,1,28,1],'#d0b39a',2.5)})}
function finish(m,near){if(!near){
 if(m==='bench'){
 let wx=small?-25:W*.025,ww=small?W*.39:W*.34,wy=143,wh=small?328:345;
 bloom(wx+ww*.67,wy+wh*.35,ww*.94,wh*.8,'rgba(255,238,183,.23)');
 bloom(W*.953,145,W*.20,179,'rgba(239,186,124,.17)');
 // Shelf cast onto the plaster behind. Dusty bottom edge not a clean geometric stripe.
 let ss=small?W*.82:W*.79;P([ss-2,404,W+6,404,W+6,429,ss+17,422],'#56625438');
 // Stamped paper ticket and faded colored insulation sleeves beside the tool rail.
 let tx=small?W*.79:W*.773;at(tx,541,small?.62:.84,()=>{Q([0,4,4,20,13,29,30,45,39,21,41,9,36,2],'#80765e',3);Q([1,4,7,18,13,25,28,41,36,18],'#b99a77',1.3);E(3,3,2,2,'#5f7162');E(37,1,2,2,'#607163')});
 let ee=small?W*.49:W*.434;P([ee,551,ee+17,549,ee+18,574,ee+1,576],'#a6a490');P([ee+2,549,ee+19,547,ee+20,571,ee+3,573],'#c2ba98');R(ee+7,549,7,2.3,'#aaa487');
 // Instrument worker's old clip lamp frames the light source, not the actors.
 rafter(-22,-9,small?.81:1.13);
 }else if(m==='office'){
 let mx=small?-W*.035:W*.04,my=small?204:185,mw=small?W*.41:W*.34,mh=small?220:270;intricateMap(mx,my,mw,mh);
 signrail(small?W*.015:W*.059,my+mh+12,small?W*.24:W*.18);
 let edge=small?W*.60:W*.55,yy=small?179:163,hh=small?326:347;
 // Travel light grazes the painted frame and dashboard wall; a red track signal breaks the cool palette.
 bloom(W*.92,yy+hh*.50,W*.35,235,'rgba(223,234,211,.16)');clip(edge+12,yy+hh*.60,W-edge-15,hh*.34,()=>{let px=edge+(W-edge)*.80;R(px-1,yy+hh*.62,2,hh*.32,'#627e81');box(px-4,yy+hh*.6,8,14,'#566e73','#657f81',1);E(px,yy+hh*.6+4,2,2,'#c68a73');E(px,yy+hh*.6+10,1.5,1.5,'#82958d')});
 // Expanding paint seams in the desk bay, exposed brushed metal end cap at far right.
 let hang=small?W*.959:W*.953;L([hang,yy+15,hang,yy+hh*.56],'#8b9d96',1.5);E(hang,yy+hh*.56,2,3,'#a6b0a3');
 P([-20,80,W*.54,130,W*.54,137,-20,93],'#4c68733d');bloom(W*.20,600,W*.3,190,'rgba(46,77,91,.11)');
 }else{
 let wx=small?-22:W*.018,ww=small?W*.39:W*.39,wy=small?175:148,wh=small?349:382;
 // Narrow shoji pocket down the side of the slider; backed by indigo paper in the evening.
 let px=wx+ww*.018,pw=ww*.10;clip(px,wy+8,pw,wh-20,()=>{R(px,wy+8,pw,wh,'#c0ac9e81');for(let j=0;j<6;j++){let yy=wy+wh*j/5;L([px,yy,px+pw,yy],'#897b7680',1.8)}L([px+pw*.52,wy,px+pw*.52,wy+wh],'#897b768f',1.8)});
 bloom(wx+ww*.57,wy+wh*.57,ww*.93,wh*.96,'rgba(128,142,182,.15)');
 let lx=small?W*.91:W*.86;
 // Paper pendant with ribbed oiled paper replacing the distant conical fitting.
 at(lx,153,small?.75:.94,()=>{P([-3,-41,3,-41,3,-31,12,-28,22,-20,28,-7,29,7,25,20,18,27,8,31,-9,31,-19,26,-26,17,-30,7,-29,-7,-24,-18,-13,-28,-3,-31],G(-28,0,30,2,['#ae8975','#e4c19b','#e9bf96','#b38d75']),'#957965',1.7);for(let j=0;j<7;j++){let yy=-22+j*7,ww=Math.sqrt(Math.max(0,1-((yy-1)/33)**2))*26;Q([-ww,yy,0,yy+4,ww,yy],'#a68a7382',1.05)}R(-9,29,18,3,'#927565');R(-6,-33,12,3,'#af8d72')});
 bloom(lx,200,small?145:200,200,'rgba(246,191,119,.18)');
 let sx=small?W*.84:W*.804;knit(sx+8,617,small?.53:.70);
 // Asymmetrical light at the edges and shadow beneath the rail.
 P([-15,579,W*.375,579,W*.372,586,-15,591],'#7d665c42');
 }
}else{
 if(m==='bench'){
 // Darkened drawer seams, visible screw heads, the worn strip along the nose.
 let width=small?W*.26:W*.28;for(let j=0;j<4;j++){let xx=j*width;for(let k of [.15,.86])bolt(xx+width*k,850,2.2,'#676653','#a49978');L([xx+width*.42,875,xx+width*.58,875],'#b8a485',1)}
 bloom(-10,989,W*.24,136,'rgba(46,58,58,.18)');
 }else if(m==='office'){bloom(W*.02,973,W*.45,143,'rgba(35,62,78,.23)');}
 else{bloom(W*.91,888,W*.25,97,'rgba(255,206,146,.13)');bloom(-21,985,W*.23,120,'rgba(84,65,82,.18)');}
}}
function passingTrain(time){const xw=(small?.60:.55)*W,ww=W-xw+25,yw=small?179:163,hh=small?326:347;let phase=frac(time/21+.315),cycle=phase*21;
if(cycle>11.3)return;const len=(small?175:228),left=xw+ww+12-(cycle/11.3)*(ww+len+45),y=yw+hh*.628,ht=small?19:23;
c.save();c.beginPath();let panes=ww>450?3:2;for(let j=0;j<panes;j++){let x0=j===0?xw+9:xw+ww*j/panes+8,x1=j===panes-1?xw+ww-9:xw+ww*(j+1)/panes-4;c.rect(x0,yw+hh*.45,x1-x0,hh*.37)}c.clip();
// Quiet local passenger service seen from the duty room. Two cars have separate livery.
for(let a=0;a<2;a++){let xx=left+a*(len*.5),w0=len*.5-3;P([xx+2,y+4,xx+7,y,xx+w0-5,y,xx+w0,y+4,xx+w0+1,y+ht-2,xx+w0-2,y+ht,xx+2,y+ht,xx,y+ht-3],a?'#93a4a1':'#9caca6','#788e8e',.8);R(xx+3,y+ht*.68,w0-5,2.2,'#778f8a');for(let k=0;k<9;k++){let px=xx+5+k*(w0-11)/9;let dw=(w0-11)/9-2;if(k===3||k===6){R(px,y+4,dw,ht-6,'#899d99');R(px+1,y+5,dw-2,ht*.24,'#72898a');L([px+dw*.5,y+5,px+dw*.5,y+ht-3],'#748b88',.65)}else{R(px,y+4,dw,ht*.33,'#6f898c');R(px+1,y+4,dw*.37,1,'#b3c0b4')}}R(xx+9,y-2,w0*.16,2.3,'#8fa39f');R(xx+w0*.62,y-2,w0*.17,2.3,'#8fa39f');L([xx+5,y+ht-1,xx+w0-3,y+ht-1],'#607d80',1.3)}
// Repaint the platform edge that is closer than the train.
P([xw-3,yw+hh*.79,xw+ww*.68,yw+hh*.64,xw+ww+4,yw+hh*.67,xw+ww,yw+hh*.73,xw+ww*.70,yw+hh*.70,xw,yw+hh*.85],'#677f80');for(let i=0;i<5;i++)L([xw+ww*i*.27,yw+hh*.78-9*i,xw+ww*i*.27,yw+hh],'#748989',3);
c.restore()}
function layer(w,h,m,i){const key=[w,h,m,i].join('/');if(cache.has(key))return cache.get(key);const o=typeof OffscreenCanvas!=='undefined'?new OffscreenCanvas(w,h):document.createElement('canvas');o.width=w;o.height=h;c=o.getContext('2d');c.setTransform(h/1000,0,0,h/1000,0,0);W=w*1000/h;small=W<1120;if(i){c.save();let edge=m==='bench'?[-45,722,W*.64,697,W+45,712]:m==='office'?[-20,761,W*.69,720,W+20,730]:[-26,826,W*.13,794,W*.78,752,W+26,786];c.beginPath();c.moveTo(edge[0],edge[1]);for(let n=2;n<edge.length;n+=2)c.lineTo(edge[n],edge[n+1]);c.lineTo(W+50,1050);c.lineTo(-50,1050);c.closePath();c.clip()}if(m==='bench')bench(i);else if(m==='office')office(i);else home(i);finish(m,i);if(i)c.restore();cache.set(key,o);if(cache.size>12)cache.delete(cache.keys().next().value);return o}
// Repaint this optional isolated near plane after characters, before any on-table prop.
window.shopFront=function(ctx,w,h,t,mode='bench'){if(!(w>0&&h>0))return;w=Math.round(w);h=Math.round(h);t=Number(t)||0;let m=mode==='office'?'office':mode==='table'?'table':'bench',f=layer(w,h,m,1);let wv=w*1000/h,dx=Math.sin(t*.24+(m==='bench'?.2:m==='office'?1.1:2.6))*2.6,dy=Math.sin(t*.19)*.9;ctx.save();ctx.scale(h/1000,h/1000);ctx.drawImage(f,-6-dx*.64,-3-dy*.65,wv+12,1007);ctx.restore()};
window.shop=function(ctx,w,h,t,mode='bench'){if(!(w>0&&h>0))return;w=Math.round(w);h=Math.round(h);t=Number(t)||0;let m=mode==='office'?'office':mode==='table'?'table':'bench';// Two cached moving depth planes plus repeatable, non-flickering light animation.
 let b=layer(w,h,m,0),f=layer(w,h,m,1);W=w*1000/h;small=W<1120;c=ctx;c.save();c.scale(h/1000,h/1000);
 let osc=Math.sin(t*.24+(m==='bench'?.2:m==='office'?1.1:2.6)),dx=osc*2.6,dy=Math.sin(t*.19)*.9;
 c.drawImage(b,-4+dx,-2+dy,W+8,1004);
 if(m==='bench'){for(let i=0;i<19;i++){let xx=W*(.06+.67*hash(i+771))+(Math.sin(t*.32+i)*2.5),yy=150+frac(hash(i+133)+t*(.002+hash(i+37)*.003))*440;E(xx,yy,.66+hash(i+304)*.85,.64+hash(i+761)*.65,'rgba(252,241,202,'+(.18+.12*Math.sin(t*.5+i))+')')}}
 else if(m==='office'){c.save();c.translate(-4+dx,-2+dy);c.scale((W+8)/W,1.004);passingTrain(t);c.restore()}
 else{let gl=c.createRadialGradient(W*(small?.91:.86),173,4,W*(small?.91:.86),173,small?100:145);gl.addColorStop(0,'rgba(255,205,143,.12)');gl.addColorStop(1,'rgba(255,205,143,0)');R(W*(small?.91:.86)-150,30,300,295,gl)}
 c.drawImage(f,-6-dx*.64,-3-dy*.65,W+12,1007);c.restore();
};
})();
