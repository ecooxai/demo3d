/* Original artwork for AFTER AGI. Artist's coordinates use a 720-high plate.
   All ink, hand-built silhouettes, characters in signage and textures are procedural. */
(() => {
'use strict';
const cache = new Map();
function rand(seed) { let q=seed>>>0; return ()=>((q=(Math.imul(q,1664525)+1013904223)>>>0)/4294967296); }
function poly(c, pts, color, stroke=null, line=1) { c.beginPath();c.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=2)c.lineTo(pts[i],pts[i+1]);c.closePath();if(color){c.fillStyle=color;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=line;c.stroke();} }
function line(c,pts,col,lw=1) {c.beginPath();c.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=2)c.lineTo(pts[i],pts[i+1]);c.strokeStyle=col;c.lineWidth=lw;c.stroke();}
function curve(c,pts,col,lw=1){c.beginPath();c.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=6)c.bezierCurveTo(...pts.slice(i,i+6));c.strokeStyle=col;c.lineWidth=lw;c.stroke();}
function rect(c,x,y,w,h,col){c.fillStyle=col;c.fillRect(x,y,w,h);}
function ell(c,x,y,rx,ry,col,a=0){if(rx<.001||ry<.001)return;c.beginPath();c.ellipse(x,y,rx,ry,a,0,Math.PI*2);c.fillStyle=col;c.fill();}
function vg(c,y0,y1,stops){let g=c.createLinearGradient(0,y0,0,y1);for(const [t,v] of stops)g.addColorStop(t,v);return g;}
function glow(c,x,y,r,color){let g=c.createRadialGradient(x,y,.1,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'rgba(255,220,183,0)');rect(c,x-r,y-r,r*2,r*2,g);}
function txt(c,s,x,y,sz,col,align='left'){c.textAlign=align;c.textBaseline='middle';c.font='700 '+sz+'px "Noto Sans CJK JP","Yu Gothic",sans-serif';c.fillStyle=col;c.fillText(s,x,y);}
function shape(c, pts, fill) {c.beginPath();c.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=6)c.bezierCurveTo(...pts.slice(i,i+6));c.closePath();c.fillStyle=fill;c.fill();}
function cloud(c,x,y,s,night,R) {
 c.save();c.translate(x,y);c.scale(s,s);
 // A single inkless silhouette, then curved bands of cool shadow with lost edges.
 const contour=new Path2D();contour.moveTo(-141,52);contour.bezierCurveTo(-160,45,-141,32,-119,33);contour.bezierCurveTo(-127,20,-111,6,-89,12);contour.bezierCurveTo(-94,-3,-78,-17,-65,-13);contour.bezierCurveTo(-68,-38,-40,-49,-23,-37);contour.bezierCurveTo(-17,-76,30,-83,47,-55);contour.bezierCurveTo(61,-67,87,-57,86,-37);contour.bezierCurveTo(103,-38,118,-23,112,-9);contour.bezierCurveTo(143,-14,161,6,150,20);contour.bezierCurveTo(172,12,182,27,181,36);contour.bezierCurveTo(209,40,210,49,235,48);contour.bezierCurveTo(206,68,142,53,101,62);contour.bezierCurveTo(62,68,-53,57,-141,52);contour.closePath();
 c.save();c.clip(contour);rect(c,-165,-82,415,166,vg(c,-77,71,night?[[0,'#fff4cc'],[.23,'#fbd3b1'],[.52,'#ecacac'],[.85,'#9c86a6'],[1,'#806e96']]:[[0,'#fff9d8'],[.31,'#ffe6bd'],[.62,'#e8bba9'],[1,'#b3a6b1']]));
 shape(c,[-151,37,-89,30,-93,-1,-66,-7,-67,6,-48,16,-32,9,-32,-22,1,-29,17,-18,8,-6,17,2,36,1,62,1,72,21,74,26,90,8,112,17,117,29,143,18,176,41,209,44,186,77,-69,86,-151,57],night?'#b999ae':'#d3b0ad');
 shape(c,[-162,54,-113,44,-103,32,-81,37,-90,47,-48,48,-26,31,-28,45,-6,47,13,42,48,29,44,36,68,37,101,26,124,44,133,41,176,34,191,47,216,52,152,65,-68,80,-155,62],night?'#9a87a7':'#bca7ae');
 shape(c,[-88,16,-80,-18,-53,-20,-45,-13,-64,-13,-71,2,-68,9,-78,8,-82,13,-88,16],night?'#ffe3c3':'#fff3d0');
 shape(c,[-20,-34,-9,-66,21,-69,39,-54,13,-63,2,-52,-1,-46,-9,-46,-12,-42,-20,-34],night?'#fff1cf':'#fff9dd');
 for(let i=0;i<48;i++){let xx=-125+R()*290, yy=33+R()*44;ell(c,xx,yy,2+R()*19,.35+R()*.65,night?'#fbd4bf45':'#fff5df46',-.035);}
 c.restore();c.restore();
}
function ridge(c,W,y,col,amp,seed){let r=rand(seed),p=[-15,720,-15,y],xx=-15,v=y;while(xx<W+25){v+=(r()-.49)*amp;v=Math.min(y+14,Math.max(y-27,v));xx+=6+r()*19;p.push(xx,v);}p.push(W+40,720);poly(c,p,col);}
function skyline(c,W,y,k,pal,seed){
 let r=rand(seed),x=-20;while(x<W+30){let w=(9+r()*38)*k,h=(9+Math.pow(r(),2)*69)*k,b=y-h;
  rect(c,x,b,w,h,pal[0]);if(r()>.25)rect(c,x+w*.1,b-3*k,w*.5,4*k,pal[1]);rect(c,x,b,w,1.55*k,pal[2]);rect(c,x+w*.81,b+1,w*.19,h,pal[1]);
  if(r()>.5){rect(c,x+w*.72,b-(4+r()*16)*k,1.2*k,16*k,pal[1]);}
  for(let yy=b+5*k;yy<y-2*k;yy+=7*k)for(let xx=x+3*k;xx<x+w*.8-1;xx+=5.5*k){if(r()>.37)rect(c,xx,yy,2.4*k,2.8*k,pal[r()>.62?2:1]);}
  x+=w+1.8*k;
 }
}
function drawSky(c,W,night){let r=rand(707),wx=W*(night?.72:.78),wy=night?302:162;
 rect(c,0,0,W,470,vg(c,0,465,night?[[0,'#364d80'],[.27,'#697ca2'],[.55,'#d5a7aa'],[.75,'#ffd4aa'],[1,'#ffe1ad']]:[[0,'#3d7e98'],[.3,'#83b7bf'],[.62,'#e2d7bd'],[.9,'#ffe1b2'],[1,'#ffecd0']]));
 glow(c,wx,wy,night?165:133,night?'rgba(255,206,139,.62)':'rgba(255,232,162,.45)');ell(c,wx,wy,night?23:17,night?23:17,night?'#ffefc2':'#fff2c4');
 // Stratocirrus torn into long strokes by high wind.
 for(let i=0;i<34;i++){let xx=r()*W,yy=25+r()*261,len=20+r()*102;shape(c,[xx,yy,xx+len*.28,yy+.4,xx+len*.57,yy-.5,xx+len,yy-8,xx+len*.77,yy-4,xx+len*.3,yy+3.7,xx,yy+1],night?'#e9b7b64a':'#eef1d447');}
 distantVapor(c,W,night,r);skyTower(c,W,night);c.save();c.translate(W*.91,night?269:244);c.scale(-1.16,.69);cloud(c,0,0,W<660?.60:.85,night,r);c.restore();
 ridge(c,W,371,night?'#b693a6':'#a7b5b3',13,21);ridge(c,W,395,night?'#938a9f':'#93aaa8',10,57);
 skyline(c,W,409,.74,night?['#a99aa4','#9a90a2','#dbb4ad']:['#a9b9b2','#98aba9','#e3d5ba'],64);
 skyline(c,W,449,.92,night?['#8a8093','#706f87','#d2aaa0']:['#92a4a4','#738c91','#ccbcaa'],82);
}
function facade(c,x,y,w,h,n,seed){let r=rand(seed);let a=n?'#8b7e89':'#a6abaa',b=n?'#6d687e':'#829195',gl=n?'#deb599':'#d5d0b9';
 rect(c,x,y,w,h,a);rect(c,x+w*.7,y,w*.3,h,b);rect(c,x-2,y-4,w+4,5,n?'#9c8a91':'#b9b7ac');
 for(let i=0;i<Math.floor(h/18)-1;i++){let yy=y+8+i*17;for(let j=0;j<Math.floor(w/12);j++){let xx=x+5+j*11.3;rect(c,xx,yy,6,9,r()>.75?gl:b);rect(c,xx,yy,6,.9,gl);}if(i%2===0)rect(c,x-1,yy+10,w+2,2,b);}
}
function asphalt(c,W,n){
 const vp=W*.69,vy=437;
 poly(c,[0,443,W,427,W,720,0,720],vg(c,426,720,n?[[0,'#c69b98'],[.38,'#8d8190'],[1,'#514e65']]:[[0,'#ccbca5'],[.38,'#a3a3a0'],[1,'#687982']]));
 let r=rand(9);
 for(let j=0;j<1900;j++){let xx=r()*W, yy=442+r()*281;let sz=(yy-426)/268;rect(c,xx,yy,.5+r()*2.8*sz,.3+r()*.68*sz,j%3===0?'#ffeac21f':'#273e4c11');}
 // Tactile raised paving and longitudinal seam with irregular street markings.
 poly(c,[0,466,vp-3,vy,0,571],n?'#a89391':'#b4b6aa');
 poly(c,[0,565,vp,vy,0,576],n?'#534f64':'#787f7e');
 line(c,[0,575,vp,vy],n?'#ffd4aa':'#e6d8b9',2.2);
 poly(c,[W,449,vp+8,vy,W,486],n?'#93838e':'#a8aaa1');line(c,[W,487,vp+8,vy],n?'#e5b6a3':'#d3c9b3',1.3);
 for(let i=0;i<5;i++){let y1=vy+Math.pow((i+1)/5,2.4)*279,y2=vy+Math.pow((i+.67)/5,2.4)*279,off=(y1-vy)*.98;poly(c,[vp+off,y1,vp+off+Math.max(1,(y1-vy)*.043),y1,vp+(y2-vy)*1.025,y2,vp+(y2-vy)*.98,y2],n?'#d5b6a2':'#e0d7b9');}
 for(const i of [0,1,2,3,4,5]){let of=(i-3)*.17;poly(c,[vp+(of-.045)*92,478,vp+(of+.05)*92,478,vp+(of+.05)*113,486,vp+(of-.045)*113,486],n?'#d2b2a3':'#d2d1b9');}
 let mx=W*.85,my=646;ell(c,mx,my,25,5.5,n?'#514b60':'#65727a');for(let k=-3;k<=3;k++){line(c,[mx-14,my+k*.8,mx+13,my+k*.8],'#d1bbaa70',.7);}
}
function transitRoad(c,W,n){
 const curbFar=x=>551-141*x/W,curbNear=x=>666-179*x/W, lane=x=>618-127*x/W;
 let far=n?'#bba09a':'#bbbdae',ed=n?'#ae9a94':'#b2b7a6',lineCol=n?'#e7bb9d':'#e4d5b7';
 // This camera is under the shelter facing diagonally down the road, not looking along the old shop lane.
 // The original side lane narrows into a T on the far side of the same three-storey block.
 poly(c,[-3,451,W,394,W,720,-3,720],far);
 let s=W*.67,yy=curbFar(s);poly(c,[W*.44,441,W*.58,436,s+W*.097,yy+8,s-W*.054,yy+24],n?'#a0878e':'#a1a8a0');
 line(c,[W*.44,441,s-W*.054,yy+24],ed,2.1);line(c,[W*.58,436,s+W*.097,yy+8],lineCol,1.5);
 poly(c,[-12,curbFar(-12)+8,W+12,curbFar(W+12)+8,W+12,curbNear(W+12),-12,curbNear(-12)],vg(c,380,710,n?[[0,'#c0a5a4'],[.42,'#9b8b91'],[1,'#686372']]:[[0,'#b9b8a8'],[.44,'#a5aaa1'],[1,'#78878c']]));
 for(let k=0;k<2;k++){let o=k*6;line(c,[-10,curbFar(-10)+8+o,W+8,curbFar(W+8)+8+o],k?(n?'#8f848a':'#8d9992'):lineCol,k?.95:2.5);}
 poly(c,[-10,curbNear(-10),W+10,curbNear(W+10),W+12,731,-12,731],vg(c,510,720,n?[[0,'#ab999a'],[1,'#706977']]:[[0,'#b3b4a7'],[1,'#8a9692']]));
 line(c,[-9,curbNear(-9)-1.5,W+10,curbNear(W+10)-1.5],n?'#5d586b':'#64777e',3.1);
 line(c,[-9,curbNear(-9)+4,W+10,curbNear(W+10)+4],lineCol,1.85);
 // Lane center and uninterrupted gutter line make the bus direction unambiguous.
 for(let k=0;k<7;k++){let a=(k*.175-.08)*W,b=a+W*(.083-.004*k);poly(c,[a,lane(a),b,lane(b),b,lane(b)+3-k*.18,a,lane(a)+3.4-k*.18],n?'#cdb2a0':'#d9d6b9');}
 for(let k=0;k<13;k++){let a=(k/13)*W,u=k/13;line(c,[a,curbNear(a)+4,a+W*(.043+.016*u),curbNear(a)+12+37*(1-u)],n?'#67657479':'#6d817c66',.81);}
 const r=rand(12421);
 for(let j=0;j<1860;j++){let x=r()*W,y=curbFar(x)+r()*(720-curbFar(x)),s=(y-410)/310;rect(c,x,y,.45+r()*2.4*s,.35+r()*.71*s,j%4===0?'#ffe7c032':'#334b5220');}
 // Storm-drain bars and ordinary tactile-edge paint establish the shelter side of the roadway.
 let x=W*.19,y=curbNear(x)-10;poly(c,[x-19,y+1,x+12,y-4,x+21,y-2,x-10,y+4],n?'#6c6371':'#667b7c');
 for(let k=0;k<9;k++){let xx=x-16+k*3.5;line(c,[xx,y+1-k*.48,xx+4,y+2-k*.52],n?'#ba9c92':'#abb1a0',.72);}
 for(let k=0;k<6;k++){let x=W*(.15+k*.045);line(c,[x,curbNear(x)+9,x+W*.024,curbNear(x+W*.024)+9],n?'#d8ae8758':'#d6c79480',2);}
 // Patches of hedge and a far guard sit above the roadway block rather than hidden underneath it.
 // Their perspective spacing notes the corner of the block without creating a second "stop."
 for(let j=0;j<7;j++){
  if(j===3||j===4)continue;
  let x=W*(.39+j*.092),y=curbFar(x)-13,h=7+5*(1-x/W),span=W*.042;
  line(c,[x,y+2,x,y-h,x+span,y-h-5,x+span,y-3],n?'#716d7b':'#778a84',1.25);
  line(c,[x+.3,y-h+.4,x+span,y-h-4.6],n?'#c5a596':'#a9b5a2',.65);
  if(j===0||j===1||j===5||j===6){let ux=x+span*.43,uy=y-h-.8;for(let k=0;k<12;k++){let ix=ux+(r()-.5)*span*.84,iy=uy-r()*3.6;ell(c,ix,1+iy,1.2+r()*2.7,.66+r()*1.36,n?(k%3?'#807f7c':'#9a8c83'):(k%3?'#7f9781':'#9fa98a'));}}
 }

}

function poles(c,W,n){let ink=n?'#565369':'#536475',hi=n?'#ccaaa0':'#c6c8b3';for(let j=0;j<4;j++){let x=W*(1.014-j*.087),h=[390,248,162,101][j],y=455-h,f=[1,.7,.47,.3][j];poly(c,[x-3*f,y,x+2.3*f,y,x+6*f,455,x-1*f,455],ink);line(c,[x+1*f,y+2,x+5*f,455],hi,1.0*f);for(let z=0;z<2;z++){rect(c,x-21*f,y+16*f+z*13*f,40*f,3*f,ink);for(let k=-1;k<=1;k++){rect(c,x+k*16*f,y+10*f+z*13*f,2.4*f,7*f,ink);ell(c,x+k*16*f,y+11*f+z*13*f,3*f,1.6*f,hi);}}}
 for(let j=0;j<4;j++){let dx=j*5;curve(c,[-5,-15+j*4,W*.35,38+j*8,W*.65,158+j*9,W+5,70+j*5],ink,1.3-(j%2)*.38);curve(c,[W*.73,357+dx,W*.83,314+dx,W*.91,242+dx,W+4,79+dx],ink,.84);}
}
function smallBlock(c,W,n){let r=rand(13);for(let j=0;j<5;j++){let fw=(W<690?25:38)*(1+j*.39),x=W*.71+j*W*.068,y=395-j*11;facade(c,x,y,fw,447-y,n,30+j);if(j%2===0){rect(c,x-1,427-j*1.8,fw+3,3+j,n?'#9f717a':'#ac8376');rect(c,x+2,435-j,fw-2,10+j*2,n?'#5f6073':'#748588');}}
 for(let j=0;j<5;j++){let x=W*.53+j*W*.038,y=411+j*3,w=W*.035;poly(c,[x,y,x+w*.48,y-12+j*1.2,x+w,y,x+w,446,x,446],n?'#8e7885':'#a1a69c');poly(c,[x-2,y,x+w*.48,y-13+j*1.2,x+w+2,y,x+w*.92,y+2,x+w*.48,y-8+j,x+3,y+3],n?'#696c82':'#859091');}
 // Low station fence at the crossing.
 for(let j=0;j<14;j++){let x=W*.61+j*W*.012;line(c,[x,439,x,449],n?'#686d7b':'#879388',.95);}
 line(c,[W*.61,441,W*.77,441],n?'#777381':'#8b978c',1);
}
function leaf(c,x,y,s,n,r){for(let i=0;i<30;i++){let a=r()*Math.PI*2,q=Math.sqrt(r());let xx=x+Math.cos(a)*s*q, yy=y+Math.sin(a)*s*.61*q;ell(c,xx,yy,2.3+r()*4.9,1.1+r()*3.5,[n?'#344958':'#415d59',n?'#607266':'#71866a',n?'#b39478':'#a7aa74'][i%3],a*.17);}}
function shop(c,W,n){
 let A=Math.min(W*.45,365),ink=n?'#363949':'#344957',dark=n?'#414557':'#3b5360',cream=n?'#c6a494':'#cdc3ac',edge=n?'#e7b89b':'#e1d4b6',blue=n?'#4d7478':'#527d84',r=rand(34);
 c.save();
 // Street-facing third-generation repair co-op, with a small glazed clerestory and projecting machine shed.
 poly(c,[-8,207,A*.58,222,A*.98,308,A*.98,464,A*.57,500,-8,557],cream,ink,1.6);
 poly(c,[A*.57,221,A*.98,308,A*.98,465,A*.57,501],n?'#a58b84':'#9ba49d',ink,1.65);
 poly(c,[-9,205,A*.58,220,A*.58,499,-9,557],n?'#b49a93':'#b4b5a6');
 // Horizontal siding follows perspective on each side.
 for(let y=230;y<500;y+=9){line(c,[-4,y,A*.57,y+(370-y)*.115],n?'#7e6d7555':'#657e7b4a',.8);}
 for(let j=0;j<17;j++){let yy=236+j*14.5;line(c,[A*.58,yy,A*.97,312+(yy-236)*.615],n?'#705e7170':'#677c7775',.9);}
 // Great ridged tile roof, upturned flashing and exposed narrow rafters.
 poly(c,[-12,198,A*.20,168,A*.65,193,A*1.016,295,A*.57,233,-9,218],n?'#504a5d':'#526575',ink,2);
 poly(c,[-8,197,A*.2,169,A*.645,194,A*.566,219],n?'#696075':'#74838b',ink,1);
 for(let j=0;j<=19;j++){let u=j/19;line(c,[A*.2+u*A*.445,171+u*24,-12+u*(A*.58+13),198+u*22],n?'#b28e8c':'#9ba7a3',.85);}
 for(let j=0;j<11;j++){let u=j/11;line(c,[A*.65+u*A*.363,194+u*97,A*.57+u*A*.44,220+u*74],n?'#806f7f':'#7b8c91',1.2);}
 poly(c,[-12,199,A*.575,218,A*1.022,293,A*1.027,300,A*.571,228,-12,208],ink);
 line(c,[-8,198,A*.57,217,A*1.021,292],edge,1.9);
 line(c,[-8,212,A*.56,233,A*1.01,304],n?'#877583':'#81908e',2);
 for(let j=0;j<12;j++){let u=j/12;line(c,[u*A*.55,213+u*19,u*A*.55+2,220+u*19],ink,2);}
 // Upper loft windows; mirror sky with two diagonal bands rather than flat blue rectangles.
 let ax=A*.07,ay=239,aw=A*.365,ah=53;
 poly(c,[ax,ay,ax+aw,ay+2,ax+aw,ay+ah,ax,ay+ah+5],ink);
 poly(c,[ax+3,ay+3,ax+aw-3,ay+5,ax+aw-3,ay+ah-3,ax+3,ay+ah+2],vg(c,ay,ay+ah,[[0,n?'#777e95':'#819eac'],[.53,n?'#b2a0a7':'#a6bdba'],[1,n?'#565569':'#677e88']]));
 for(let j=0;j<4;j++){let x=ax+aw*j/4;rect(c,x,ay+2,2,ah,ink);line(c,[x+2,ay+4,x+2,ay+ah-2],edge,.7);}
 line(c,[ax,ay+ah*.58,ax+aw,ay+ah*.57],ink,2);line(c,[ax,ay+ah+4,ax+aw+2,ay+ah-1],edge,2.3);
 // Wall-mounted fan and old condenser bracket.
 let cx=A*.444,cy=254,cw=A*.106;rect(c,cx,cy,cw,29,n?'#b5a79f':'#c3c5b7');rect(c,cx+1,cy+2,cw-2,2,edge);ell(c,cx+cw*.51,cy+15,Math.min(10,cw*.4),10,n?'#6b6675':'#7d8986');for(let k=-3;k<=3;k++)line(c,[cx+cw*.51-7,cy+15+k*2,cx+cw*.51+7,cy+15+k*2],cream,.7);line(c,[cx+3,cy+30,cx+5,cy+35,cx+9,cy+30],ink,1.5);
 // Enameled vertical shingle uses a spanner pictogram robust to absent CJK fonts.
 let sx=A*.82,sy=294;line(c,[sx-7,sy+1,sx+19,sy-3,sx+18,sy+34],ink,2.5);
 poly(c,[sx+8,sy-10,sx+30,sy-11,sx+30,sy+48,sx+8,sy+50],n?'#c67762':'#c97d61',ink,1.45);
 poly(c,[sx+10,sy-8,sx+27,sy-9,sx+27,sy+46,sx+10,sy+47],n?'#e59b74':'#e4a277');
 c.save();c.translate(sx+18,sy+6);c.rotate(.65);rect(c,-1.4,0,2.8,11,ink);ell(c,0,-.4,3.8,3.8,ink);poly(c,[-2,-4,1,-3,2,-.3,-.8,.1],n?'#e59b74':'#e4a277');c.restore();
 for(let j=0;j<3;j++){rect(c,sx+14,sy+21+j*6,9,1.3,ink);rect(c,sx+18,sy+19+j*6,1.25,5.3,ink);}
 // Carved name board on the shop front. Its main emblem is a hand-inked setting sun.
 let fy=310,fl=A*.565;poly(c,[-4,fy,fl,fy-4,fl,fy+32,-4,fy+38],ink);poly(c,[-4,fy+3,fl-3,fy-1,fl-3,fy+27,-4,fy+33],n?'#cfac87':'#d9c39f');c.save();c.translate(fl*.12,fy+16);ell(c,0,0,7.5,7.5,n?'#944f4e':'#a26654');rect(c,-8,2.3,17,1.7,cream);rect(c,-8,5.3,17,1.3,cream);c.restore();
 txt(c,'REPAIR',fl*.235,fy+13,Math.min(20,fl*.16),ink);line(c,[fl*.235,fy+25,fl*.83,fy+22],n?'#9f725e':'#ad8d70',1.2);
 // Open workshop: dark cool overhead cast shadow, warm repair bench and paper lamps.
 let gx=-3,gy=363,gw=A*.553,gh=150;poly(c,[gx,gy,gw,gy-15,gw,502,-3,553],ink);c.save();c.beginPath();c.moveTo(-3,gy+4);c.lineTo(gw-4,gy-10);c.lineTo(gw-4,499);c.lineTo(-3,547);c.closePath();c.clip();
 rect(c,-4,343,gw+7,209,vg(c,350,545,[[0,n?'#564243':'#344a51'],[.39,n?'#c89262':'#637272'],[1,n?'#5c494a':'#3b5057']]));
 for(let j=0;j<13;j++){let x=r()*gw;rect(c,x,369+r()*48,3+r()*14,6+r()*19,n?'#8c685638':'#31455761');}
 for(let j=0;j<3;j++){let yy=388+j*25;line(c,[-3,yy+7,gw*.8,yy],n?'#604949':'#334d56',2.6);for(let k=0;k<6;k++){let x=5+k*gw*.125+r()*3,h=5+r()*8;rect(c,x,yy+6-x*.046-h,4+r()*5,h,[n?'#d7ae78':'#c5b999',n?'#866864':'#77877c',n?'#a07c69':'#ac9b85'][k%3]);}}
 line(c,[gw*.69,355,gw*.69,378],ink,.9);poly(c,[gw*.69-7,382,gw*.69-3,376,gw*.69+3,376,gw*.69+8,382],n?'#ffcf87':'#d7cdb0');if(n)glow(c,gw*.69,384,27,'rgba(255,197,116,.43)');
 line(c,[-3,468,gw,448],dark,5);rect(c,gw*.32,468,3,40,ink);let bikeX=gw*.37;for(let xx of [bikeX,bikeX+27]){c.strokeStyle=n?'#b09686':'#85958d';c.lineWidth=1.6;c.beginPath();c.ellipse(xx,485,11,11,0,0,Math.PI*2);c.stroke();}line(c,[bikeX,485,bikeX+8,469,bikeX+16,483,bikeX,485,bikeX+20,472,bikeX+27,485],n?'#c5a285':'#9caaa0',1.1);
 c.restore();line(c,[gw*.82,351,gw*.82,508],ink,2.7);
 // Stable sawn beam, roll-down shutter and corrugated side canopy.
 poly(c,[fl,347,A*.98,346,A*.98,465,fl,500],n?'#8f7c80':'#929c99');
 for(let j=0;j<32;j++){let y=350+j*4.4;line(c,[fl+2,y,A*.975,347+(y-350)*.777],j%2?n?'#be9d8c':'#b5b5a4':n?'#756871':'#738886',.86);}
 poly(c,[-8,340,fl,334,fl+11,361,-9,373],blue,ink,1.45);
 for(let j=0;j<9;j++){let u=j/9,v=(j+.46)/9;poly(c,[-8+u*(fl+8),340-6*u,-8+v*(fl+8),340-6*v,-10+v*(fl+21),372-11*v,-10+u*(fl+21),372-11*u],n?'#718c84':'#8fa89a');}
 poly(c,[-8,370,fl+11,358,fl+10,367,-8,382],n?'#3e5962':'#45676b');line(c,[-8,370,fl+11,359],n?'#b7ab89':'#b4bca0',1.5);
 for(let i=0;i<8;i++){let x=(i+.58)*fl/8;line(c,[x,373-(x/fl)*11,x,380-(x/fl)*11],dark,.8);}
 poly(c,[fl,334,A*.996,336,A*.997,350,fl+11,361],n?'#686c70':'#798e88',ink,1);
 line(c,[A*.963,316,A*.963,457,A*.947,460,A*.949,466],ink,3);line(c,[A*.962,317,A*.962,454],edge,.87);
 let boxx=A*.78,boxy=388;rect(c,boxx,boxy,9,15,n?'#bdaa9a':'#b7bdad');rect(c,boxx+2,boxy+3,4,4,dark);line(c,[boxx+5,boxy+15,boxx+5,boxy+35,boxx+10,boxy+37],ink,.9);
 // Potted little tree and a narrow two-step threshold.
 poly(c,[-5,548,fl,499,A*.98,463,A*.98,469,fl,508,-5,559],n?'#786e73':'#7f8b87');line(c,[-4,547,fl,498,A*.98,463],edge,1.35);
 let tx=fl+17,ty=491;poly(c,[tx-7,ty-11,tx+6,ty-13,tx+4,ty+1,tx-4,ty+3],n?'#b1816d':'#b98b73',ink,.8);line(c,[tx,ty-12,tx+2,ty-34],dark,1.2);leaf(c,tx,ty-31,11,n,r);
 for(let j=0;j<4;j++){let bx=A*.65+j*10;line(c,[bx,472-j*1.35,bx+1,477-j*1.4],n?'#d0ae91':'#c9c7ad',1);}
 c.restore();
}
function cosmos(c,W){const r=rand(205),H=720;
 rect(c,0,0,W,H,vg(c,0,720,[[0,'#101936'],[.27,'#263459'],[.62,'#485777'],[.9,'#9a7f89'],[1,'#d69b8f']]));
 // Pigment nebula: fine interleaved translucent brushmarks instead of a generic black star field.
 for(let i=0;i<21;i++){let u=i/20,xx=W*u,yy=360-235*u+30*Math.sin(7*u),ss=46+22*Math.sin(i*2.7);let gg=c.createRadialGradient(xx,yy,1,xx,yy,ss);gg.addColorStop(0,'rgba(196,174,199,.043)');gg.addColorStop(1,'rgba(174,181,216,0)');ell(c,xx,yy,ss,ss,gg);} 
 for(let i=0;i<1470;i++){const u=r(),x=u*W,cy=368-227*u+32*Math.sin(7*u),j=(r()+r()+r()-1.5),y=cy+j*116;ell(c,x,y,.45+r()*5.8,.27+r()*1.34,[ '#c3ada620','#a89aa51d','#95aabe26','#c79a9d19'][i%4],-.21);}
 for(let i=0;i<300;i++){let x=r()*W,y=r()*627,sz=Math.pow(r(),7)*1.34+.11;ell(c,x,y,sz,sz,[ '#faf1d6','#c3d9da','#e3cad2'][i%3]);if(sz>1.29){line(c,[x-2.8,y,x+2.8,y],'#f5ebcf80',.58);line(c,[x,y-3,x,y+3],'#fff5e199',.62);}}
 const px=W*.66,py=1012,rr=610;
 // Orbiting structures vanish behind the limb, then return across the near hemisphere.
 for(let i=0;i<3;i++){const u=i*5;curve(c,[-42,605+u,W*.17,449+u,W*.53,283+u,W+40,295+u],i===0?'#fed1a3ad':'#e7bda438',i===0?1.45:.7);}
 for(let j=0;j<11;j++){let u=.08+j*.082,v=1-u;let xx=v*v*v*(-42)+3*v*v*u*(W*.17)+3*v*u*u*(W*.53)+u*u*u*(W+40),yy=v*v*v*605+3*v*v*u*449+3*v*u*u*283+u*u*u*295;ell(c,xx,yy,j%4===0?2.9:1.4,j%4===0?2.9:1.4,j%4===0?'#ffe2a9':'#e3bfa8');}
 let atmo=c.createRadialGradient(px,py,rr-19,px,py,rr+26);atmo.addColorStop(0,'#f9b79700');atmo.addColorStop(.37,'#ffcaa8b8');atmo.addColorStop(.49,'#ffe9bf');atmo.addColorStop(.55,'#ffcfac77');atmo.addColorStop(.7,'#f7b0a335');atmo.addColorStop(1,'#bc98c300');ell(c,px,py,rr+26,rr+26,atmo);
 // Distant uncrewed observatory, three planes of hull shadow and drawn panel divisions.
 const sx=W*.27,sy=259;glow(c,sx+13,sy,44,'rgba(255,207,159,.16)');c.save();c.translate(sx,sy);c.rotate(-.31);line(c,[-32,0,36,0],'#a8b3b9',1.6);for(let sg of [-1,1]){poly(c,[sg*12,-4,sg*34,-5,sg*33,6,sg*11,6],'#4d6582','#94a8b1',.7);for(let j=0;j<5;j++)line(c,[sg*(13+j*4),-4,sg*(12+j*4),5],'#bdab9d',.65);line(c,[sg*12,1,sg*34,.7],'#96aab5',.65);}
 poly(c,[-6,-5,3,-6,7,-2,6,6,-4,6,-8,2],'#c8b9aa','#38445f',1);poly(c,[3,-6,7,-2,6,6,1,4],'#9e8a92');line(c,[-1,-5,1,-15,6,-18],'#d9ceba',.9);c.restore();
}
// Second real art pass: local cooling-room transformation, depth cues, habitat and handmade foliage.
function smallGrove(c,x,y,s,n,seed,details=1){
 let r=rand(seed);c.save();c.translate(x,y);c.scale(s,s);
 let p=n?['#656777','#827e80','#989287','#b9a484']:['#608178','#7f9b81','#99ae89','#b7bb8d'];
 poly(c,[-2,0,-1,-29,2,-31,2,0],n?'#756775':'#73837c');for(let j=0;j<5;j++){let u=j/4-.5;line(c,[0,-13,1+u*16,-25,1+u*24,-29],n?'#776b75':'#6a8175',1.5);}
 const groups=[[-10,-27,14],[-4,-36,15],[9,-31,17],[15,-25,10],[-16,-22,9],[1,-23,17]];
 for(let [ax,ay,rad] of groups){ell(c,ax,ay,rad,rad*.58,p[0],-.09);for(let k=0;k<21*details;k++){let a=r()*6.283,v=Math.sqrt(r()),xx=ax+rad*Math.cos(a)*v,yy=ay+rad*.59*Math.sin(a)*v;let co=yy<ay-2?p[2+(k%4===0)]:p[1];ell(c,xx,yy,1.2+r()*4.7,.55+r()*2.8,co,r()*.8-.45);}}
 c.restore();
}
function streetLife(c,W,n){let r=rand(656);
 // Distant blocks now have balconies, true gable profiles, fire stair landings and TV aerials.
 for(let i=0;i<4;i++){let x=W*(.35+i*.045),y=404+i*3,w=Math.min(39,W*.046);
 poly(c,[x,y,x+w*.5,y-11,x+w,y,x+w,443,x,443],n?'#a08e91':'#a7b3a8');
 poly(c,[x-2,y+1,x+w*.47,y-14,x+w+2,y-1,x+w+1,y+2,x+w*.46,y-8,x,y+4],n?'#707386':'#73888b');
 for(let k=0;k<2;k++){rect(c,x+w*.17+k*w*.43,y+7,w*.18,9,n?'#c9aa98':'#8fa6a0');line(c,[x+w*.14+k*w*.43,y+16,x+w*.37+k*w*.43,y+16],n?'#847789':'#798d89',1);}
 if(i===0||i===2){line(c,[x+w*.7,y-4,x+w*.7,y-22],n?'#848091':'#8c9c98',.8);for(let k=0;k<4;k++)line(c,[x+w*.7-5+k,y-21+k*2,x+w*.7+6+k,y-22+k*2],n?'#968998':'#929f9c',.6);}}
 for(let j=0;j<8;j++){let xx=W*(.58+j*.053),s=.26+j*.074, yy=442+j*1.25;smallGrove(c,xx,yy,s,n,564+j,.7);}
 // Right-hand pedestrian barrier, warmly lit in the last scene.
 let inp=n?'#6e6d79':'#7e9090',hil=n?'#f5c39d':'#ded4b5';const x1=W*.806,x2=W+12,y1=446,y2=476;
 line(c,[x1,y1-5,x2,y2-18],inp,2.6);line(c,[x1,y1-6.3,x2,y2-19],hil,1);
 for(let k=0;k<8;k++){let u=Math.pow(k/7,1.5),xx=x1+(x2-x1)*u, yy=y1+(y2-y1)*u;line(c,[xx,yy-6-u*13,xx,yy+1.5],inp,1+u*1.5);}
 // A crossing beacon, a convex roadside mirror and an unambiguous transit stop.
 let bx=W*.72,by=447;c.save();c.translate(bx,by);line(c,[0,0,0,-39,15,-39],n?'#737183':'#748788',1.65);rect(c,10,-42,15,5.5,n?'#676779':'#62797a');for(let i=0;i<3;i++)ell(c,12.9+i*4.4,-39.2,1.22,1.22,i===0?'#f1a182':i===2?'#94b4a3':'#a5a59b');c.restore();
 let xx=W*.891,yy=451;line(c,[xx,yy,xx-1,yy-60],n?'#a97566':'#ba876e',2.2);ell(c,xx-1,yy-61,5.7,6.8,'#cf8c73');ell(c,xx-1,yy-61,4.4,5.5,vg(c,yy-67,yy-55,[[0,n?'#d2b8a9':'#b9cfbd'],[.53,n?'#8f8193':'#90a799'],[1,n?'#5c6179':'#70868a']]));
 xx=W*.61;yy=454;rect(c,xx-1,yy-33,1.8,33,inp);ell(c,xx,yy-34,4.9,5.2,n?'#c5927c':'#cc9c7e');rect(c,xx-4,yy-35,8,2,n?'#f9ddab':'#efe1bc');rect(c,xx-4,yy-24,8,11,n?'#beb2a4':'#bbc5b5');for(let k=0;k<3;k++)rect(c,xx-2.5,yy-22+k*2.6,5,.65,inp);
 // Hand set pavers with private gutter rather than a flat triangular sidewalk.
 let vp=W*.69;for(let k=0;k<21;k++){let u=Math.pow(k/21,1.65),xx=vp*(1-u),yt=437+124*u,yb=437+137*u;line(c,[xx,yt,xx-1.7,yb],n?'#857b835e':'#7e8d8861',.75);}
}
function livingShop(c,W,n){const A=Math.min(W*.45,365),fl=A*.565,ink=n?'#4c4a58':'#435a60',dim=n?'#9a7e78':'#8b9c91',e=n?'#e4b597':'#d1cfb0';
 if(n){ // The formerly closed side shutter is physically raised for the public room.
  poly(c,[fl+4,359,A*.953,353,A*.953,457,fl+4,491],vg(c,351,488,[[0,'#6e5961'],[.21,'#b2826c'],[.59,'#c39a71'],[1,'#736663']]),ink,1.15);
  poly(c,[fl+5,360,A*.952,353,A*.95,373,fl+5,385],'#847476');
  for(let j=0;j<7;j++)line(c,[fl+5,360+j*3.5,A*.95,354+j*2.8],j%2?'#aa9390':'#746672',.85);
  line(c,[fl+5,385,A*.946,373],'#f2c797',1.4);
  // Central lamp, reflected as two broken gold stripes on the sill.
  let lx=A*.75,ly=383;line(c,[lx,376,lx,ly+1],ink,.85);poly(c,[lx-5,ly+4,lx-2,ly,lx+2,ly,lx+5,ly+4],'#fae2a5');glow(c,lx,ly+5,24,'rgba(255,201,117,.33)');
  let f=A*.864;line(c,[f,380,f,461],ink,2);line(c,[fl+7,450,A*.949,430],ink,3);line(c,[fl+8,448,A*.915,431],'#f2c397',1.2);
  rect(c,A*.64,410,9,13,'#e2cba5');for(let k=0;k<3;k++)rect(c,A*.64+2,414+2.6*k,5,.68,'#9e8e7c');
  // Two folding chairs backed by a hanging linen cooling towel.
  let sx=A*.77,sy=443;line(c,[sx-5,sy+9,sx+5,sy-1,sx+7,sy+8],ink,1.6);line(c,[sx-3,sy,sx+6,sy-1,sx+5,sy-8],ink,1.7);
  poly(c,[A*.89,389,A*.93,388,A*.93,407,A*.914,408,A*.91,406,A*.892,407],'#bebcb1');line(c,[A*.9,393,A*.926,392],'#668787',1.3);
  line(c,[fl+6,491,A*.955,456],ink,2.1);line(c,[fl+14,486,A*.70,475],'#f4c18d',1.3);
 } else {
  // Shaded line of an outdoor queue and the half-lowered fabric screen.
  poly(c,[-2,379,fl*.78,372,fl*.78,390,-2,400],n?'#8d8c84':'#a7b2a1');
  for(let j=1;j<5;j++){let xx=fl*.78*j/5;line(c,[xx,379-7*j/5,xx+.7,398-9*j/5],ink,.9);}
  rect(c,fl*.12,382,fl*.23,1.3,'#6d8982');rect(c,fl*.125,386,fl*.19,1,'#83988d');
 }
 // Co-op soda crate, delivery parcels and a local notice overlap the previous sterile threshold.
 let bx=fl*.14,by=516;poly(c,[bx,by,bx+18,by-2,bx+18,by+8,bx,by+11],n?'#89635e':'#9b7663',ink,.8);
 for(let k=0;k<3;k++){rect(c,bx+2+k*5,by+2,3,2,ink);}
 let px=A*.405,py=490;poly(c,[px,py,px+10,py-1,px+10,py+10,px,py+13],n?'#b89a79':'#b5a687',ink,.7);line(c,[px+5,py,px+5,py+11],e,.8);
 // Condenser support sheet, real pipe lagging, chipped fascia paint.
 for(let k=0;k<9;k++)line(c,[A*.074+k*A*.038,230+k*.1,A*.08+k*A*.038,230+k*.1],e,.6);
 let sx=A*.976,sy=390;poly(c,[sx,sy,sx+13,sy-3,sx+13,sy+17,sx,sy+20],n?'#a69b91':'#aeb4a4',ink,1);ell(c,sx+6,sy+8,4.1,5.4,dim);for(let j=0;j<4;j++)line(c,[sx+2,sy+4+j*2.2,sx+10,sy+2+j*2.2],e,.55);line(c,[sx+1,sy+21,sx+2,sy+27,sx+7,sy+20],ink,1);
 // Verge: storm drain, tactile slab, weeds and tufts at real wall contact.
 let r=rand(349);for(let j=0;j<19;j++){let u=r(),x=A*(.57+.4*u),y=507-37*u;for(let k=0;k<4;k++)line(c,[x,y,x+(r()-.5)*8,y-r()*5],n?'#847e6a':'#839777',.85);}
 let dx=A*.88,dy=482;poly(c,[dx-11,dy+3,dx+9,dy-3,dx+15,dy-2,dx-7,dy+5],ink);for(let j=0;j<6;j++){let a=j/6;line(c,[dx-8+a*18,dy+2.6-a*5,dx-5+a*18,dy+3.8-a*5],dim,.8);}
}
function canopy(c,W,n){ // Close shaded plane, mirroring the shape of the crescent in the later orbital shot.
 let r=rand(7719),scale=W<720?.78:.92,ink=n?'#434657':'#3f595a';
 c.save();c.translate(W,0);c.scale(scale,scale);
 let ps=[[-5,8,-57,22,-83,57,-122,67],[-7,-3,-33,15,-70,21,-112,21],[-37,23,-55,33,-69,67,-94,92],[-20,9,-42,6,-60,-2,-81,-7]];
 for(let [x,y,a,b,d,e,f,g] of ps){curve(c,[x,y,a,b,d,e,f,g],n?'#494756':'#485b59',4.1);curve(c,[x,y-1,a,b-1,d,e-1,f,g],n?'#897667':'#899477',.7);}
 const pal=n?['#3f4b58','#515764','#68686b','#8b806d','#aea080']:['#405e5a','#526e61','#68866b','#839876','#abb083'];
 for(let j=0;j<280;j++){let rad=Math.sqrt(r()),a=-Math.PI+r()*Math.PI*.46,x=8+Math.cos(a)*rad*146,y=-19+Math.abs(Math.sin(a))*rad*109;
  if(y>70&&x<-96)continue;let s=1.65+Math.pow(r(),1.5)*5.6,ang=-1+r()*2.2;c.save();c.translate(x,y);c.rotate(ang);shape(c,[-s,0,-s*.47,-s*.55,s*.58,-s*.7,s,0,s*.4,s*.53,-s*.4,s*.45,-s,0],pal[Math.min(4,Math.floor(r()*4)+(x<-91&&j%5===0?1:0))]);c.restore();}
 c.restore();
}
// Third paint pass: non-repeating cumulonimbus, reflected ambient color and abraded street surfaces.
function distantVapor(c,W,n,r){c.save();
 // The common base of the distant cloud system hides the mountain edge in sea haze.
 let y=n?335:326;
 const cc=n?['#d3a5ae','#e7b7b0','#f8ceb7','#f7dac1']:['#cbbfba','#e8d4bd','#f2dfc4','#faeacd'];
 shape(c,[-70,y+34,W*.09,y+6,W*.14,y+32,W*.24,y+4,W*.31,y-8,W*.36,y+18,W*.43,y+7,W*.5,y-2,W*.52,y+12,W*.62,y+2,W*.70,y-12,W*.72,y+18,W*.79,y+9,W*.88,y-3,W*.95,y+15,W+55,y-1,W+55,y+31,W*.8,y+32,W*.57,y+29,W*.28,y+41,W*.12,y+33,-70,y+43],cc[0]);
 for(let i=0;i<51;i++){let x=r()*W,yy=y+1+12*Math.sin(x/W*12)+r()*16;let ww=5+r()*44;shape(c,[x,yy,x+ww*.2,yy-4,x+ww*.34,yy-4,x+ww*.52,yy-2,x+ww*.77,yy-7,x+ww*.9,yy-4,x+ww,yy-4,x+ww*.7,yy+1,x+ww*.27,yy+2,x,yy],cc[i%3]);}
 c.restore();
}
function skyTower(c,W,n){
 // Asymmetric vertical summer thunderhead; distant light alone defines its edges.
 let x=W*.40,sy=n?296:259,sc=Math.min(.93,Math.max(.63,W/1050));c.save();c.translate(x,sy);c.scale(sc,sc);
 let p=new Path2D('M -170 49 C -159 41 -145 43 -140 30 C -134 17 -123 22 -118 10 C -122 -4 -106 -15 -92 -11 C -93 -27 -80 -37 -68 -33 C -74 -46 -63 -64 -49 -64 C -59 -74 -50 -91 -36 -92 C -38 -106 -28 -115 -15 -114 C -20 -132 -7 -147 8 -145 C 12 -161 33 -158 38 -144 C 58 -144 62 -130 57 -119 C 73 -118 75 -105 71 -96 C 93 -94 100 -75 90 -60 C 105 -68 123 -65 128 -49 C 145 -53 153 -42 151 -29 C 172 -30 187 -17 182 -4 C 201 -9 219 -3 225 6 C 254 2 274 19 306 16 C 277 39 251 29 219 40 C 177 43 167 55 119 47 C 97 62 46 49 22 59 C -36 52 -109 69 -170 49 Z');
 c.save();c.clip(p);rect(c,-180,-170,505,245,vg(c,-160,61,n?[[0,'#ffedc7'],[.20,'#f8ceb5'],[.50,'#e5aba9'],[.80,'#b997ae'],[1,'#948aa6']]:[[0,'#fff8d8'],[.22,'#fff3d1'],[.5,'#f6dfbf'],[.81,'#d0b7b2'],[1,'#ada8b7']]));
 const sh=n?'#bea0b2':'#dbc5bd',sh2=n?'#a38fa9':'#beafba',rim=n?'#ffe8c6':'#fff7d8';
 shape(c,[-93,-9,-86,-28,-77,-31,-60,-30,-65,-47,-52,-61,-40,-57,-46,-72,-36,-83,-23,-81,-29,-63,-22,-57,-13,-55,-18,-38,1,-30,12,-34,10,-14,23,-11,37,-14,46,5,68,-8,80,4,105,-11,130,-5,154,9,181,-1,206,18,241,14,204,53,81,60,-45,70,-96,34,-121,17,-93,-9],sh);
 shape(c,[-32,-88,-22,-104,-11,-100,-4,-108,-4,-124,8,-128,18,-126,14,-118,18,-112,25,-112,19,-98,31,-92,40,-95,39,-84,24,-80,17,-88,2,-84,-4,-95,-12,-91,-19,-91,-26,-85,-32,-88],sh);
 shape(c,[-116,21,-87,11,-94,-7,-71,-7,-74,-1,-67,7,-54,3,-59,14,-44,15,-39,13,-35,24,-22,18,-13,19,6,11,4,24,28,20,61,8,74,23,84,21,121,13,134,28,158,22,181,16,205,35,241,29,170,64,-97,66,-128,47],sh2);
 shape(c,[-8,-143,9,-168,32,-155,37,-144,20,-151,16,-145,12,-138,6,-141,0,-141,-8,-136],rim);
 shape(c,[-74,-38,-67,-61,-55,-68,-43,-63,-56,-61,-60,-53,-60,-46,-67,-46,-69,-40,-74,-38],rim);
 shape(c,[82,-56,97,-74,120,-65,125,-51,106,-62,99,-58,94,-50,91,-55,87,-55,82,-56],rim);
 let r=rand(733);for(let j=0;j<56;j++){let xx=-128+r()*344,yy=26+r()*37;ell(c,xx,yy,2+r()*14,.3+r()*.7,n?'#e9bcb55d':'#f9ebd566',-.04);}
 c.restore();c.restore();
}
function finishPigment(c,W,n){let rng=rand(503),A=Math.min(W*.45,365);
 // Cast lattice of a left awning, broken over the gutter; shade never obscures human faces.
 c.save();c.beginPath();c.moveTo(-2,553);c.lineTo(A*.58,503);c.lineTo(A*1.02,467);c.lineTo(W*.61,502);c.lineTo(W*.19,626);c.lineTo(-1,646);c.closePath();c.clip();
 const shade=n?'#61596c27':'#4c657433';
 for(let j=0;j<4;j++){let x=-37+j*A*.13;poly(c,[x,540-j*5,x+7,540-j*5,x+W*.32,598-j*5,x+W*.32-4,598-j*5],shade);}
 // Crisp edge interrupted by leaves is legible as a real cast shadow instead of a vignette.
 poly(c,[-5,550,A*.57,501,A*.78,490,W*.4,539,W*.18,579,-5,591],n?'#6a627325':'#516a712b');c.restore();
 // Interlocking paver lines, road wound and sealed pothole, all obey the horizon.
 curve(c,[W*.929,721,W*.915,698,W*.857,697,W*.902,675,W*.915,660,W*.858,661,W*.886,645],n?'#423e522d':'#42545e38',1.2);
 curve(c,[W*.89,679,W*.86,679,W*.852,671,W*.823,676],n?'#413d5025':'#44596329',.8);
 let yy=650,x=W*.25;shape(c,[x-18,yy,x-6,yy-9,x+32,yy-4,x+46,yy+1,x+32,yy+9,x+9,yy+3,x-18,yy],n?'#9a889119':'#9aa59d20');
 for(let j=0;j<145;j++){let xx=rng()*W,yy=450+Math.pow(rng(),.55)*270;let b=(yy-450)/270;rect(c,xx,yy,.6+rng()*3.4*b,.32+rng()*.85*b,j%3===0?'#f1dfb73c':'#45516219');}
 // The distant side of the street takes a cyan-pink reflection in the last light.
 if(n){let gr=c.createLinearGradient(0,440,0,690);gr.addColorStop(0,'#f6c69542');gr.addColorStop(.38,'#ecaf8822');gr.addColorStop(1,'#e9ad8400');poly(c,[-4,547,A*.57,501,A*.96,466,W*.75,508,W*.08,659,-6,652],gr);}
 // Fixtures determine scale: roof snow guards, paint wear, running cables, old fascia joins.
 let ink=n?'#57566a':'#5d757b',hi=n?'#d4a894':'#bfbeab';for(let k=0;k<5;k++){let u=k/5,x=A*.1+u*A*.45,y=194+u*15;line(c,[x-2,y,x+2,y+1,x+3,y-2],ink,.85);}
 curve(c,[A*.57,240,A*.65,259,A*.81,273,A*.98,286],ink,.95);
 curve(c,[A*.57,244,A*.65,267,A*.82,280,A*.973,289],ink,.7);
 line(c,[A*.63,246,A*.63,259],ink,.8);line(c,[A*.85,279,A*.85,282],hi,.9);
 // Uneven, tiny physical wear marks never scratch across the full flat drawing.
 for(let k=0;k<80;k++){let u=rng(),v=rng(),xx=u*A*.53,yy=224+11*u+v*103;if(yy<236||yy>303)rect(c,xx,yy,.45+rng()*2.35,.3+rng()*.59,k%3?'#e9d5b42f':'#40505a17');}
}
function texturePaper(c,W){ // Original low-amplitude paper / camera color texture generated on first call.
 c.save();const side=128;let film=texturePaper.tile;if(!film){film=typeof OffscreenCanvas!=='undefined'?new OffscreenCanvas(side,side):document.createElement('canvas');film.width=side;film.height=side;let fx=film.getContext('2d'),im=fx.createImageData(side,side),r=rand(43321);for(let i=0;i<side*side;i++){let y=(r()+r()+r()-1.5)*29,idx=i*4;im.data[idx]=128+y;im.data[idx+1]=128+y*.92;im.data[idx+2]=128+y*.88;im.data[idx+3]=255;}fx.putImageData(im,0,0);texturePaper.tile=film;}
 c.globalCompositeOperation='soft-light';c.globalAlpha=.2;c.fillStyle=c.createPattern(film,'repeat');c.fillRect(0,0,W,720);c.restore();
}

// A true orthographic globe: geography, atmosphere and cloud cover are original 3D fields.
function paintedEarth(c,W){
 const px=W*.66,py=1012,rr=610,Y0=399,step=1.38,sw=Math.ceil(W/step),sh=Math.ceil((721-Y0)/step);
 const surface=typeof OffscreenCanvas!=='undefined'?new OffscreenCanvas(sw,sh):document.createElement('canvas');surface.width=sw;surface.height=sh;const cx=surface.getContext('2d'),im=cx.createImageData(sw,sh);
 const table=new Float32Array(32768),rng=rand(19028);for(let j=0;j<table.length;j++)table[j]=rng()*2-1;
 function noise(x,y,z){let i=Math.floor(x),j=Math.floor(y),k=Math.floor(z),u=x-i,v=y-j,w=z-k;u=u*u*(3-2*u);v=v*v*(3-2*v);w=w*w*(3-2*w);let a=(i&31),A=((i+1)&31),b=(j&31)<<5,B=((j+1)&31)<<5,d=(k&31)<<10,D=((k+1)&31)<<10;
 const ab=table[a+b+d],Ab=table[A+b+d],aB=table[a+B+d],AB=table[A+B+d],ab2=table[a+b+D],Ab2=table[A+b+D],aB2=table[a+B+D],AB2=table[A+B+D];
 let f=(ab+(Ab-ab)*u)*(1-v)+(aB+(AB-aB)*u)*v,F=(ab2+(Ab2-ab2)*u)*(1-v)+(aB2+(AB2-aB2)*u)*v;return f+(F-f)*w;}
 const clamp=(f,lo=0,hi=1)=>Math.max(lo,Math.min(hi,f));
 for(let j=0;j<sh;j++){let dy=(Y0+(j+.5)*step-py)/rr;for(let i=0;i<sw;i++){let dx=((i+.5)*step-px)/rr,ss=1-dx*dx-dy*dy;if(ss<=0)continue;let z=Math.sqrt(ss);
  // Rotate the sphere before sampling so the visible cap contains coast, open ocean and the weather belt.
  let sx=dx*.82+z*.572,sz=z*.82-dx*.572,sy=dy*.622+sz*.783;sz=sz*.622-dy*.783;
  let a=noise(sx*3.9+9,sy*3.9+5,sz*3.9+16),b=noise(sx*8.1+13,sy*8.1+21,sz*8.1+8),d=noise(sx*17.4+10.1,sy*17.4+18,sz*17.4+4.8),e=noise(sx*40,sy*40+21,sz*40+9),f=noise(sx*88+22,sy*88+17,sz*88+28);
  let land=a*.53+b*.27+d*.13+e*.055+f*.025-.031,lt=clamp(.64-.25*dx+.22*(-dy)-.13*z),rrc,gg,bb;
  if(land<=0){let shelf=clamp((land+.105)/.105);shelf=shelf*shelf;let waves=noise(sx*12+11,sy*29+5,sz*12+22);
   rrc=41+20*lt+22*shelf+4*waves;gg=74+27*lt+26*shelf+7*waves;bb=100+23*lt+15*shelf+7*waves;
  }else{let high=clamp(land*2.6),coast=Math.exp(-land*55),dry=clamp(.44+noise(sx*6+3,sy*6+12,sz*6+29)*.62);
   rrc=83+27*lt+32*dry+15*high+13*coast;gg=99+27*lt+10*dry+18*high+8*coast;bb=96+22*lt+11*dry+22*high+9*coast;
   let ridge=Math.max(0,Math.abs(e+f*.35)-.5)*high;rrc+=ridge*21;gg+=ridge*23;bb+=ridge*21;}
  let warp=noise(sx*2.3+23,sy*2.3+12,sz*2.3+4),wd=noise(sx*4.4+7,sy*4.4+13,sz*4.4+9);
  // Shallow wind-shear folds run around the sphere, not horizontally across the flat picture.
  let z1=sz*9.6+wd*.72, y1=sy*17.6+warp*2.6;
  let cl=noise(sx*9.1+.75*warp+5,y1+11,z1+8)*.48+noise(sx*19+2,sy*39+warp*4+4,sz*17.5+wd+7)*.27+noise(sx*49,sy*80+warp*7,sz*43+3)*.15+f*.1;
  let cloud=clamp((cl+.005)*2.5)*.84,light=.64+.36*lt;rrc+=(224*light-rrc)*cloud;gg+=(226*light-gg)*cloud;bb+=(218*light-bb)*cloud;
  // Distant limb scatters warm light. Only coast pixels in the nightside carry town lights.
  let haze=Math.pow(1-z,3.2);rrc+=(229-rrc)*haze*.92;gg+=(174-gg)*haze*.80;bb+=(168-bb)*haze*.80;
  if(land>0&&land<.045&&dx<-.14&&f>.56&&e>.05&&cloud<.43){rrc+=42;gg+=24;bb+=4;}
  let q=(j*sw+i)*4;im.data[q]=rrc;im.data[q+1]=gg;im.data[q+2]=bb;im.data[q+3]=255;
 }}
 cx.putImageData(im,0,0);c.save();c.beginPath();c.arc(px,py,rr-.72,0,Math.PI*2);c.clip();c.imageSmoothingEnabled=true;c.drawImage(surface,0,Y0,sw*step,sh*step);c.restore();
 // A delicate pencil-bright upper atmosphere, anchored to the accurate globe silhouette.
 c.save();c.strokeStyle='#ffe0b5';c.lineWidth=1.18;c.beginPath();c.arc(px,py,rr-.53,Math.PI,2*Math.PI);c.stroke();c.restore();
}

// A real, recurring place, not a title-only idea: empty bench, local stop and worn timetable case.
function stopLandmark(c,W,n,street=false){
 let A=Math.min(W*.45,365),vp=W*.69,x=A+9+(W<720?5:18),u=Math.min(.93,x/vp),y=569-133*u,s=.59+.45*(1-u);
 if(street){x=W*.16;y=666-179*x/W+26;s=.93;}
 c.save();c.translate(x,y);c.scale(s,s);
 const ink=n?'#514d5b':'#415c61',deep=n?'#706771':'#678481',hi=n?'#d6af92':'#c6c8a9',wood=n?'#ac8673':'#a9997b',warm=n?'#c28d74':'#c08a6e';
 // The shadow tells viewers this is on the sidewalk, not floating in the street.
 poly(c,[-19,1,8,-3,76,-18,93,-15,26,2,-4,6],n?'#7469784d':'#586d713d');
 // Back slats, front seat lip and galvanized bent-steel legs run into the vanishing point.
 let bx=12;for(let k=0;k<2;k++){let xx=bx+k*40,yy=-2-k*9;line(c,[xx,yy-28,xx+1,yy-8,xx-3,yy+1],ink,2);line(c,[xx+5,yy-7,xx+6,yy],ink,2);}
 for(let j=0;j<2;j++){let yy=-28+j*6;poly(c,[bx-4,yy,bx+47,yy-11,bx+47,yy-7.4,bx-4,yy+4.8],wood,ink,.63);line(c,[bx-3,yy+.7,bx+46,yy-10.2],hi,.77);}
 poly(c,[bx-5,-13,bx+47,-24,bx+54,-22,bx+2,-10],n?'#c39679':'#bba383',ink,.9);
 poly(c,[bx+2,-10,bx+54,-22,bx+54,-20,bx+2,-7],deep);
 for(let j=0;j<3;j++){let xx=bx+j*20;ell(c,xx,-25-j*4.4,.8,.68,ink);}
 // Small enameled route number is bolted to the bench rather than duplicated on another foreground post.
 poly(c,[bx+19,-29.5,bx+30,-32,bx+30,-26.5,bx+19,-23.7],n?'#8f8173':'#829385',ink,.6);line(c,[bx+21,-27.7,bx+27,-29],hi,.65);
 c.restore();
}

window.stopLandmark=function(c,w,h,t=0,mode="heat"){if(!c||!(h>0&&w>0))return;c.save();c.scale(h/720,h/720);stopLandmark(c,720*w/h,mode==="dusk");c.restore();};
// Separate foreground plate. The director can place it AFTER the moving street camera.
// Supports both native compositions and leaves middle/right unobstructed.
function shelterPlate(c,W){
 const portrait=W<850,postX=portrait?2:9,postW=portrait?26:34,xTop=postX+26,ax=portrait?W*.63:W*.49,ink='#293b46',deep='#344b55',paint='#527174',rim='#b1aa8c';
 // Smoked side glazing only on the near lip; a thin warm reflected sky stroke sells the physical sheet.
 let gx=postX+postW+17;
 poly(c,[-5,88,gx+18,77,gx+3,575,-5,626],'rgba(106,144,142,.084)');
 poly(c,[gx+14,93,gx+16,92,gx+4,564,gx+2,567],'rgba(231,224,190,.39)');
 poly(c,[-3,267,gx+9,244,gx+8,249,-3,276],'rgba(236,223,197,.13)');
 poly(c,[-3,280,gx+9,256,gx+8,257,-3,283],'rgba(245,232,201,.18)');
 // Roof planes: charcoal fascia; skylight panels reflecting seagreen and fading to sunlight at the far lip.
 poly(c,[-12,-12,ax+90,-12,ax*.83,20,ax*.51,48,-8,115],ink);
 poly(c,[-8,-9,ax*.88,-9,ax*.75,10,ax*.44,39,-7,100],vg(c,0,112,[[0,'#6f8988'],[.26,'#667e7e'],[.65,'#4b6168'],[1,'#425963']]));
 poly(c,[-8,101,ax*.45,40,ax*.79,11,ax*.78,18,ax*.45,48,-8,116],'#3d545e');
 line(c,[-6,103,ax*.47,39,ax*.80,9],'#9b9f8c',1.05);line(c,[-4,113,ax*.45,48,ax*.80,17],ink,3);
 for(let j=0;j<7;j++){let u=(j+1)/8,x1=-40+ax*.90*u,x2=-13+ax*.78*u,yy=106*(1-u)*.92;
   poly(c,[x1-2,-6,x1+2,-6,x2+2,yy,x2-1,yy+.5],'#415861');
   line(c,[x1+2.3,-6,x2+2.7,yy-.7],'#9ba795',.76);}
 for(let j=0;j<5;j++){let u=j/5;line(c,[-4,15+u*64,ax*(.32+.32*(1-u)),7+u*12],'rgba(188,196,172,.24)',.8);}
 // Rafters: triangulated welded brackets, not disembodied graphic lines.
 poly(c,[xTop-7,91,xTop+23,81,xTop+13,99,xTop+4,133,xTop-3,132],deep,ink,1.2);
 line(c,[xTop+3,114,xTop+21,85],rim,1.22);
 line(c,[xTop+18,92,xTop+53,77,xTop+3,156],ink,3.8);line(c,[xTop+19,91,xTop+51,77],rim,1.0);
 // Near upright with strong local contrast, two flanges, bolt heads and chipped weathered lacquer.
 poly(c,[xTop-11,86,xTop+postW-8,76,postX+postW,724,postX-6,724],vg(c,103,720,[[0,'#40585e'],[.36,'#466064'],[.74,'#455e64'],[1,'#3b5059']]),ink,1.8);
 poly(c,[xTop+postW-16,80,xTop+postW-8,77,postX+postW,724,postX+postW-7,724],'#708683');
 line(c,[xTop+postW-9,83,postX+postW-.5,720],'#b4ab89',1.2);
 line(c,[xTop-6,92,postX-.5,721],'#2b414b',2.1);
 let rn=rand(9095);
 for(let j=0;j<95;j++){let yy=103+rn()*598,tt=(yy-80)/640,xx=(xTop-6)*(1-tt)+(postX+1)*tt+rn()*(postW-10);if(j%3)rect(c,xx,yy,.5+rn()*1.75,.5+rn()*2.7,j%5?'#a6a59866':'#bd92787a');else line(c,[xx,yy,xx+.12,yy+2+rn()*4],'#283e4745',.65);}
 for(let j=0;j<5;j++){let yy=119+j*108,xx=xTop+postW-16-(yy-80)/640*21;ell(c,xx,yy,1.8,2,'#273d49');ell(c,xx-.3,yy-.6,1,.65,'#babb9d');}
 // Ferry Steps location panel strapped around the column, with genuine screw heads.
 let ox=postX+(portrait?17:21),oy=portrait?164:154,sd=portrait?.91:1;c.save();c.translate(ox,oy);c.rotate(-.035);c.scale(sd,sd);
 line(c,[-3,5,-9,7,-9,12,0,10],ink,2);line(c,[-3,50,-9,51,-9,56,0,55],ink,2);
 c.beginPath();c.roundRect(-2,0,112,61,5);c.fillStyle=ink;c.fill();
 c.beginPath();c.roundRect(-.5,1.1,108.8,56.9,4);c.fillStyle='#9a9f8b';c.fill();
 c.beginPath();c.roundRect(1,2.3,105.3,54.3,3);c.fillStyle='#d0c8a8';c.fill();
 rect(c,2,3,103,17,'#587a77');rect(c,3,47,101,1.2,'#a18e71');
 // Simplified bus mark is etched into the enamel, alongside its two physical wheels.
 c.beginPath();c.roundRect(9,6,10,9.5,1.8);c.fillStyle='#e4dbb8';c.fill();rect(c,10.5,7.6,7,3.7,'#6c8580');rect(c,10.1,14,1.4,2.9,'#e4dbb8');rect(c,16,14,1.4,2.9,'#e4dbb8');
 txt(c,'MIZUHAMA  /  LOCAL',25,12.3,5.6,'#e5dcbc');txt(c,'FERRY STEPS',8,34.8,13.5,'#475858');
 rect(c,9,51,14,1.3,'#748b7c');rect(c,26,51,34,.9,'#9c9c83');rect(c,63,51,10,1,'#9c9c83');txt(c,'07',93,51,5.6,'#788b7c','center');
 for(let [x,y] of [[3.7,4.8],[103.5,4.8],[3.7,54.4],[103.5,54.4]]){ell(c,x,y,.85,1,'#475d61');line(c,[x-.38,y+.26,x+.42,y-.36],'#d9cbaa',.43);}
 for(let j=0;j<24;j++){let xx=rn()*100+4,yy=(j%2?4:54)+rn();rect(c,xx,yy,.4+rn()*1.3,.5,'#aba58b8c');}
 c.restore();
 // Glass liquid-in-tube public shade thermometer: meter marks, brass mounting and a small capillary bulb.
 c.save();c.translate(postX+11,oy+82);c.rotate(.017);
 c.beginPath();c.roundRect(-.5,-1,17,61,3.3);c.fillStyle=ink;c.fill();
 c.beginPath();c.roundRect(.7,.7,14.1,56.7,2.8);c.fillStyle='#c3c0a9';c.fill();
 txt(c,'°C',8,5,4.15,'#657068','center');rect(c,6.6,10,1.5,34,'#e3d9bd');
 for(let j=0;j<=12;j++){let yy=12+j*2.45,len=j%3?2:3.7;line(c,[5.4-len,yy,5.4,yy],'#788578',.55);}
 rect(c,6.9,16.6,1.05,28.4,'#b37361');ell(c,7.4,46.5,2.1,2.3,'#bd7c65');line(c,[8.45,11,8.45,43],'#e8ddbe',.47);
 ell(c,8,53.5,.97,.99,'#667a72');c.restore();
 // The close side of the bench peeks into frame, leaving the bus's lower-right doorway visible.
 poly(c,[-3,664,postX+10,657,postX+34,664,-3,682],deep,ink,1.2);line(c,[-4,664,postX+11,658,postX+27,663],rim,1.3);
}
window.stopForeground=function(c,w,h,t=0){if(!c||!(w>0&&h>0))return;
 const W=720*w/h,rw=Math.max(1,Math.round(w)),rh=Math.max(1,Math.round(h)),key='stop:'+rw+':'+rh;
 let plate=cache.get(key);if(!plate){plate=typeof OffscreenCanvas!=='undefined'?new OffscreenCanvas(rw,rh):document.createElement('canvas');plate.width=rw;plate.height=rh;let p=plate.getContext('2d');p.scale(rw/W,rh/720);p.lineJoin='round';p.lineCap='round';shelterPlate(p,W);if(cache.size>12)cache.delete(cache.keys().next().value);cache.set(key,plate);}
 c.save();c.drawImage(plate,0,0,w,h);c.scale(h/720,h/720);
 // Loose maintenance tag moves slightly on its short thread in the heat. 
 let pp=W<850?2:9,x=pp+(W<850?114:129),y=(W<850?164:154)+47,a=Math.sin(t*1.32+.8)*.05;
 c.translate(x,y);c.rotate(a);line(c,[-.8,0,1,7,0,10],'#8f8269',.6);poly(c,[-2.8,9,2.6,9.2,3.6,19.1,-2.2,19.8],'#b59a7d','#8c8272',.48);line(c,[-1,13,2,12.7],'#8f7b65',.45);
 c.restore();
};

function bus(c,W,t,n,restored=false){
 const P=(v,a=0,b=1)=>Math.min(b,Math.max(a,v));
 const phase=restored?P(t/.71):P(t/3.12),u=restored?1-(1-phase)**2.8:phase;
 const route=restored?.375+.322*u:.33+.84*u;
 const xx=W*route,yy=restored?663-route*183-(1-u)*18:647-route*162;
 const base=Math.min(2.58,Math.max(1.37,W*(restored?.00266:.00230))),size=base*(1.18-.32*route);
 const slope=-(restored?183:162)/W,sy=(restored?.96:.94)*size, door=restored?P((t-.64)/.29):0;
 c.save();c.translate(xx,yy);c.transform(.92*size,.92*size*slope,.035*size,sy,0,0);
 ell(c,-31,3,73,5.3,n?'#4142535a':'#3d4b5e57');let ink='#394c59';
 // Front return plane gives diagonal depth while the sill and hubs follow the physical route.
 poly(c,[17,-47,28,-44,34,-37,37,-9,30,-5,25,-6,22,-29],n?'#b29b91':'#b6b49e',ink,.9);
 poly(c,[29,-37,34,-36,36,-27,30,-26],n?'#728288':'#809897',ink,.6);
 poly(c,[31,-24,36,-24,37,-18,31,-18],n?'#975f63':'#986d61');
 poly(c,[32,-14,37,-14,37,-10,32,-10],'#f4e3b5',ink,.42);
 poly(c,[-100,-43,-89,-48,18,-48,29,-39,31,-7,24,-3,-94,-3,-102,-11],n?'#c2ae9a':'#d4c5a6',ink,1.5);poly(c,[-100,-25,28,-25,30,-16,-101,-17],n?'#8b595c':'#a66e62');poly(c,[-75,-49,-72,-52,-41,-52,-36,-49],n?'#93919a':'#a9b2aa',ink,.6);for(let j=0;j<6;j++)line(c,[-68+j*4,-51,-69+j*4,-49],'#687e80',.5);rect(c,-90,-48,61,2,n?'#dfc9af':'#f0dbb3');
 for(let i=0;i<7;i++){
  let x=-93+i*13;poly(c,[x,-40,x+10,-40,x+10,-26,x,-26],vg(c,-40,-26,[[0,n?'#748397':'#8fa4a9'],[.46,n?'#859292':'#96aaa2'],[.62,n?'#6c798a':'#778d8f'],[1,n?'#575f74':'#637a80']]),ink,.80);
  poly(c,[x+.6,-39.5,x+8.4,-39.5,x+3.6,-35.3,x+.6,-34.6],n?'#adb0aaa6':'#c5cdbb96');
  line(c,[x+.8,-35.3,x+9.4,-35.3],'#647a7a',.57);line(c,[x+7.65,-38.7,x+7.65,-36.6],'#526f74',.43);
  // Seat backs, two differently posed riders, one child and otherwise empty glass.
  if(i!==3){poly(c,[x+.6,-28.3,x+2,-29.3,x+3.4,-29.2,x+4,-26.4,x+.5,-26.4],n?'#596273':'#526b70');}
  if(i===0||i===3||i===5){let px=x+(i===3?6:5.3),py=i===5?-30.8:-32.2,ct=i===5?1.03:1.37;
   ell(c,px,py,ct,ct*1.18,n?'#4f586b':'#546b70',i===3?.2:-.1);ell(c,px+.45,py+.3,ct*.78,ct*.77,n?'#9b918a':'#acb19b');
   poly(c,[px-.2,py+1,px+.65,py+1,px+1.2,py+2.4,px+2.1,-26.2,px-2,-26.2,px-1.7,py+2.2],i===0?'#677d79':i===3?'#7e827c':'#778789');
  }
  line(c,[x+.4,-26.4,x+9.6,-26.4],'#c0c9b6a8',.43);
 }
 poly(c,[1,-40,17,-40,24,-30,24,-25,1,-25],n?'#69788b':'#91a8a5',ink,.9);// Long glass ribbon and two slant reflections skim the silhouette on approach.
 for(const q of [-73,-34]){poly(c,[q,-39,q+7,-39,q-2,-27,q-8,-27],'#c7d7c866');}
 line(c,[-97,-24,22,-24],n?'#e9d2a8':'#eae1bf',.9);
 poly(c,[-99,-15,-46,-15,-34,-21,-13,-21,-32,-12,-98,-12],n?'#678381':'#708f87');
 rect(c,-92,-11,27,1.3,'#a39783');for(let k=0;k<5;k++)rect(c,-93+k*2,-11,1.2,4.4,ink);
 // Amber aperture, three visible risers and a metal sill; sideward leaves stay tied to the hinges.
 const jambL=-10.8,jambR=1.45;
 poly(c,[jambL,-40.8,jambR,-40.8,jambR,-5.2,jambL,-5.2],ink);
 if(door>.02){
  let level=door*.85+.15;
  c.save();c.beginPath();c.rect(jambL+1,-39.8,11.2,33.6);c.clip();
  rect(c,jambL+1,-39.8,11.2,33.6,vg(c,-39.8,-6.2,[[0,'#f5d29a'],[.23,'#ca956f'],[.5,'#a67565'],[.61,'#8f6058'],[.69,'#c99c77'],[1,'#ccac8b']]));
  // Narrow three-quarter interior wall gives the open door unmistakable depth. 
  poly(c,[-10,-38.7,-7.2,-36.7,-7.2,-18.5,-10,-12.8],'#deaf83');
  poly(c,[1,-38.9,-.7,-35.8,-.7,-17.3,1,-12.4],'#8f665d');
  poly(c,[-7.3,-36.8,-1.0,-36.8,-1.0,-25.0,-7.3,-26.4],'#b6806a');
  line(c,[-7.2,-35.2,-7.2,-23.8,-5.95,-22.15,-5.95,-17],'#f1c797',.92);
  // Two interior treads with dark risers and wear strips. The lower step projects toward sidewalk.
  poly(c,[-6.1,-19,-.7,-19,1,-15.25,-8.3,-15.25],'#ca9f79');
  poly(c,[-8.3,-15.25,1,-15.25,1,-13.2,-8.3,-13.2],'#5d5158');
  poly(c,[-8.3,-13.2,1,-13.2,1,-9.45,-9.6,-9.45],'#e0bd92');
  poly(c,[-9.6,-9.45,1,-9.45,1,-7.57,-9.6,-7.57],'#5c535b');
  line(c,[-8.12,-15.3,.78,-15.3],'#f7d6a4',.80);
  line(c,[-9.44,-9.65,.86,-9.65],'#fff0bd',.90);
  // Recessed overhead courtesy strip, warm enough to make a clean face-on silhouette.
  rect(c,-7.4,-38.6,5.0,1.25,'#fff0bb');
  glow(c,-4.8,-36.9,6.9,'rgba(255,218,143,'+(.49*level)+')');
  const fold=.30+3.15*(1-door);
  poly(c,[-10,-38.7,-9.9+fold,-37.2,-9.85+fold*.77,-8.0,-10,-6.2],'#657c79','#394954',.74);
  poly(c,[.9,-39.1,.88-fold*.88,-37.7,.94-fold*.65,-8.7,.92,-6.6],'#82918a','#3b4a54',.70);
  line(c,[-9.23,-36.9,-9.28,-21.1],'#d0b797',.65);
  c.restore();
  poly(c,[-10.35,-7.3,1.23,-7.3,3.85,-3.95,-11.10,-3.95],'#e5c399',ink,.44);
  line(c,[-10.35,-4.38,3.42,-4.38],'#ffe2a9',.81);
 }else{
  rect(c,-9.7,-38.1,4.65,14.7,'#849999');rect(c,-4.13,-38.1,4.42,14.7,'#8da09d');
  rect(c,-9.7,-22.0,4.65,14.3,'#bbb499');rect(c,-4.13,-22.0,4.42,14.3,'#b5ad97');
  line(c,[-4.61,-38.2,-4.61,-7.2],'#354952',.68);
  line(c,[-10,-6.9,1,-6.9],'#d9c9a4',.75);
 }
 line(c,[jambL+.15,-39.6,jambL+.15,-6.3],'#675c54',.73);
 rect(c,1.47,-23,24,2,n?'#ad9d92':'#b6ad95');
 for(let x of [-78,10]){
  ell(c,x,-4,8.0,8.0,'#394c55');ell(c,x,-4.25,6.5,6.15,'#495d61');ell(c,x,-4.4,4.55,4.45,n?'#a29a95':'#a1aaa2');
  for(let k=0;k<6;k++){let a=k*Math.PI/3+u*16;ell(c,x+Math.cos(a)*2.75,-4.4+Math.sin(a)*2.72,.55,.55,ink);}
  ell(c,x,-4.4,1.48,1.48,'#61787a');ell(c,x-.4,-4.8,.61,.46,'#c1c6b2');
  line(c,[x-8,-2,x-8.5,-5.7,x-6.5,-9.8,x-2.5,-12.5,x+2.4,-12.4,x+6.8,-9.6,x+8.1,-6.2],'#ad9e88',.67);
 }
 // Dashboard, driver's raised profile, wheel arc and glint in the laminated windscreen.
 poly(c,[2,-27,7,-28,12,-27.5,15.5,-26.6,18,-27.8,23,-27.6,23.7,-25.9,2,-25.8],'#566c72');
 ell(c,12.3,-31,1.6,2,'#536775',-.18);poly(c,[10.7,-32.1,11.3,-33.2,13.7,-33.1,14.6,-32.3,13,-32.3,12.8,-31.4],'#485e66');poly(c,[12.1,-31.4,13.4,-31.5,13.7,-31.0,14.1,-30.5,13.5,-30.3,13.4,-29.7,12.6,-29.6],'#b6ac95');
 poly(c,[12,-29.8,13.1,-29.7,14.2,-28.2,16.6,-27.7,16.3,-27.2,13.5,-27.4,12.8,-28,12,-26.3,10.1,-26.3,10.4,-28.3],'#617b7d');line(c,[16.5,-28.2,18,-27.5,18.5,-26.6],ink,.68);
 poly(c,[2.7,-39.3,7.6,-39.3,4.5,-35.6,2.6,-34.7],'#d1d6c395');
 // Lower service panels, door track, amber roof markers, metal bumper and weathered paint specks.
 line(c,[-62,-14,-62,-7,-39,-7,-39,-13],'#a69783',.49);
 line(c,[-37,-13,-37,-6.6,-16,-6.6,-16,-13],'#a69783',.49);
 for(let xx of [-58,-33])rect(c,xx,-12,2,.41,ink);for(let xx of [-92,-43,19])rect(c,xx,-46,.95,.62,'#e5a37d');
 poly(c,[24,-7,30,-8,30,-6.5,24,-5],'#8a928e');
 ell(c,-50,-19.6,2.2,2.1,'#d8b593');line(c,[-52,-19.4,-48,-19.4],'#93756c',.4);line(c,[-52,-18.4,-48,-18.4],'#93756c',.36);
 txt(c,'MIZUHAMA',-65,-15.8,2.1,'#ece1bf');
 rect(c,23,-12,6,3,'#ffedc1');rect(c,-101,-13,2.6,3.8,'#d17761');rect(c,2,-45,16,4,ink);line(c,[26,-33,29,-35,31,-34,31,-29],ink,1.1);rect(c,30,-32,2.5,4,'#5b6c70');line(c,[25,-21,27,-17,27,-15],'#ddd3b7',.8);txt(c,'07',-24,-10,3.9,ink);rect(c,6,-44,6,1.3,'#efd5a0');
 // Brake and curb-facing courtesy lamps sell the difference between pass-by and boarding.
 if(restored){
   let f=P((t-.12)/.3),q=door;glow(c,-99,-13,7,'rgba(236,116,92,'+(.18+.37*f)+')');
   rect(c,-101,-14,2.65,3.0,'#eaa795');
   if(q>0){poly(c,[-11,-3.98,3.6,-3.98,11.2,9.5,-16.7,9.8],'rgba(249,212,155,'+(.25*q)+')');line(c,[-17,9.8,11.1,9.5],'rgba(251,220,169,'+(.10*q)+')',.72);}
 }

 c.restore();
}
function finish(c,W,n){let r=rand(783); // Close foreground planar shadows give all ratios a strongly framed lower edge.
 poly(c,[0,618,W*.057,602,W*.14,609,W*.17,600,W*.26,608,W*.39,628,W*.41,637,W*.53,650,W*.58,648,W*.77,695,W,719,W,732,0,732],n?'#49495d50':'#45576640');
 // Barely visible brushed grain from hand-painted background elements, frozen with the painted plate.
 for(let j=0;j<Math.ceil(W*1.7);j++){let x=r()*W,y=r()*720;rect(c,x,y,.45+r()*1.15,.33+r()*.8,j%2?'#fff3d813':'#2737470d');}
}
function paint(mode,W,c){const n=mode==='dusk'||mode==='return',street=mode==='bus'||mode==='return';if(mode==='cosmos'){cosmos(c,W);paintedEarth(c,W);texturePaper(c,W);return;}drawSky(c,W,n);smallBlock(c,W,n);if(street){asphalt(c,W,n);streetLife(c,W,n);poles(c,W,n);transitRoad(c,W,n);shop(c,W,n);livingShop(c,W,n);stopLandmark(c,W,n,true);finish(c,W,n);}else{asphalt(c,W,n);streetLife(c,W,n);poles(c,W,n);shop(c,W,n);livingShop(c,W,n);stopLandmark(c,W,n);finish(c,W,n);finishPigment(c,W,n);}canopy(c,W,n);texturePaper(c,W);}
function animated(c,W,t,mode){let n=mode==='dusk'||mode==='return';if(mode==='cosmos'){for(let j=0;j<7;j++){let x=W*((.17+j*.153+t*.0011)%1),y=67+(j*33%181),f=(1+Math.sin(t*.72+j*2.1))/2;ell(c,x,y,.55+f*.8,.55+f*.8,'rgba(240,226,202,'+(.27+.45*f)+')');}return;}
 if(mode==='bus'||mode==='return')bus(c,W,t,n,mode==='return');
 // Three tiny birds lean into turn. They have moving wings rather than particle checks.
 for(let i=0;i<3;i++){let bx=W*(.58+((t*.011+i*.028)% .24)),by=(n?211:181)+i%2*8+t*.12;let flap=1.4+Math.sin(t*4.3+i)*2.35;curve(c,[bx-3.7,by-flap,bx-1.8,by-flap*.8,bx-.4,by+.7,bx,by+1.2,bx+.6,by-.5,bx+2.9,by-flap,bx+4.1,by-flap*.67],n?'#6b667a':'#667f86',.82);}
 if(n){for(let j=0;j<5;j++){let x=(.154+j*.048)*W+Math.sin(t*.39+j*4)*7,y=465+Math.sin(t*.72+j)*9+j*5;let al=(1+Math.sin(t*1.16+j*3))*.2;ell(c,x,y,1.0,1.0,'rgba(255,215,142,'+al+')');}}
 else if(mode==='heat'){for(let j=0;j<4;j++){let x=W*(.49+(j*.077)),y=443+j*2+Math.sin(t*.7+j)*1.3;curve(c,[x-6,y,x,y-1.5,x+8,y+1,x+16,y], 'rgba(255,234,200,'+(.08+.03*Math.sin(t*1.2+j))+')',.65);}}
}
window.city=function city(c,w,h,t=0,mode='heat'){
 if(!c||!(w>0&&h>0))return; t=Number.isFinite(t)?t:0;
 const rw=Math.max(1,Math.round(w)),rh=Math.max(1,Math.round(h)),W=720*w/h,key=mode+':'+rw+':'+rh;
 let plate=cache.get(key);if(!plate){plate=typeof OffscreenCanvas!=='undefined'?new OffscreenCanvas(rw,rh):document.createElement('canvas');plate.width=rw;plate.height=rh;const pc=plate.getContext('2d');pc.scale(rw/W,rh/720);pc.lineCap='round';pc.lineJoin='round';paint(mode,W,pc);
  if(cache.size>12)cache.delete(cache.keys().next().value);cache.set(key,plate);}
 c.save();c.drawImage(plate,0,0,w,h);c.scale(w/W,h/720);c.lineJoin='round';c.lineCap='round';animated(c,W,t,mode);c.restore();
};
// Supporting cast: a neighborhood rider waits under the shelter. Screen-space plane; no backdrop.
window.waitingPassenger=function waitingPassenger(c,w,h,t=0,returned=false){
 if(!c||!(w>0&&h>0))return;const p=h>w; t=Math.max(0,Math.min(returned?1.18:3.15,Number(t)||0));
 const ss=(x)=>{x=Math.min(1,Math.max(0,x));return x*x*(3-2*x);};
 const notice=returned?ss(t/.23):ss((t-.27)/.54), lift=returned?.22*ss((t-.7)/.36):ss((t-.61)/.59)*(1-ss((t-1.64)/.85));
 const lean=returned?ss((t-.45)/.53):.14*lift, step=returned?ss((t-.49)/.51):0;
 const scale=h*(p?.352:.334)/280,x=w*((p?.175:.143)+(p?.057:.046)*step),y=h*((p?.949:.952)-.016*step);
 const ink=returned?'#494659':'#435459', seam=returned?'#665e63':'#546660', warm=returned?'#e9bb98':'#d4ae92';
 const tunic=returned?'#9a766d':'#a18b78',shade=returned?'#765e60':'#7a7166',hi=returned?'#b58b78':'#baa488';
 const pants=returned?'#5e6670':'#637572',pantsDark=returned?'#505768':'#526568',light=returned?'#99958a':'#989f89';
 const stroke=(d,f,o=ink,l=1.25)=>{let q=new Path2D(d);if(f){c.fillStyle=f;c.fill(q);}if(o){c.strokeStyle=o;c.lineWidth=l;c.stroke(q);}};
 const offsetLine=(a,b,col,l)=>line(c,[a.x,a.y,b.x,b.y],col,l);
 const blue=returned?'#777c82':'#788e88';
 const breath=Math.sin(.7+t*3.13)*.78;
 c.save();c.translate(x,y);c.scale(scale,scale);c.lineCap='round';c.lineJoin='round';
 // Wide shallow penumbra shares the curb slope. Contact shadows stay directly under each foot.
 ell(c,-4,1.5,57,11.3,returned?'#403c5056':'#455b6654',-.134);
 ell(c,6,-1.9,32,6.6,returned?'#3f384a51':'#43545e46',-.134);
 // Shift the rear foot first, then swing/place the near forward foot before the shot ends.
 const near=-6+33*step, far=15-34*step, rearY=-Math.max(0,3.2*Math.sin(step*Math.PI*.9)), forwardY=-Math.max(0,18.3*Math.sin(Math.PI*step));
 ell(c,far+5,0,19,3.5,returned?'#3d374f57':'#3e525d57',-.065);
 ell(c,near+5,-1,20,3.9,returned?'#3d374f60':'#3e525d57',-.065);
 let fx=far;
 stroke('M 9 -107 C 17 -106 29 -101 28 -83 C 27 -64 '+(fx+15)+' -47 '+(fx+10)+' -38 L '+(fx+7)+' '+(-16+rearY)+' Q '+fx+' '+(-12+rearY)+' '+(fx-7)+' '+(-15+rearY)+' L '+(fx-10)+' -38 C 0 -51 -4 -74 -3 -95 Z',pantsDark);
 stroke('M '+(far+8)+' '+(-20+rearY)+' L '+(far+10)+' '+(-12+rearY)+' Q '+(far+14)+' '+(-10+rearY)+' '+(far+21)+' '+(-9+rearY)+' Q '+(far+28)+' '+(-7+rearY)+' '+(far+26)+' '+(-3+rearY)+' L '+(far-8)+' '+(-3+rearY)+' Q '+(far-9)+' '+(-9+rearY)+' '+(far-6)+' '+(-17+rearY)+' Z',returned?'#6b5d60':'#6d6760');
 line(c,[far-7,-4.0+rearY,far+25,-4+rearY], '#b2967b',1.1);
 stroke('M -27 -113 C -18 -118 4 -111 9 -96 C 6 -77 '+(near+11)+' -59 '+(near+10)+' -44 L '+(near+8)+' '+(-11+forwardY)+' Q '+(near+2)+' '+(-9+forwardY)+' '+(near-9)+' '+(-12+forwardY)+' L '+(near-11)+' -39 C -25 -57 -32 -68 -31 -90 Z',pants);
 stroke('M -23 -89 C -18 -74 '+(near-3)+' -56 '+(near-1)+' -43 L '+(near-2)+' '+(-16+forwardY),null,light,.71);
 line(c,[near-9,-42,near-1,-40,near+8,-44],returned?'#53546a':'#566968',1.1);
 stroke('M '+(near+7)+' '+(-17+forwardY)+' C '+(near+10)+' '+(-12+forwardY)+' '+(near+10)+' '+(-9+forwardY)+' '+(near+15)+' '+(-8+forwardY)+' Q '+(near+28)+' '+(-6+forwardY)+' '+(near+26)+' '+(-1+forwardY)+' Q '+(near+12)+' '+(1+forwardY)+' '+(near-10)+' '+(-.1+forwardY)+' Q '+(near-13)+' '+(-5+forwardY)+' '+(near-9)+' '+(-15+forwardY)+' Z',returned?'#876963':'#807568');
 line(c,[near-10,-2.2+forwardY,near+25,-2.1+forwardY],'#ba9b81',1.1);
 curve(c,[near+5,-9+forwardY,near+8,-8+forwardY,near+9,-6+forwardY,near+9,-5+forwardY],'#ad9582',.78);
 // The hips rotate a little toward the coach, but her weight remains over the planted foot.
 c.save();c.translate(5.5*lean,breath);c.rotate(lean*.075);
 // Far arm sleeve stays close to the shoulder under the bag load.
 stroke('M 11 -192 Q 24 -197 28 -185 L 34 -151 L 27 -137 L 19 -142 L 8 -182 Z',shade);
 // Buttonless light overshirt, dusty cotton; reads as a neighbor, not as a protagonist.
 stroke('M -26 -193 C -16 -204 2 -213 12 -206 C 20 -203 26 -192 26 -175 C 24 -157 27 -136 28 -108 C 11 -107 5 -98 -10 -99 Q -22 -102 -35 -104 C -32 -125 -35 -138 -37 -158 Q -41 -184 -26 -193 Z',tunic);
 stroke('M -32 -177 C -33 -161 -26 -154 -24 -146 Q -18 -130 -21 -110 Q -28 -109 -34 -105 L -35 -143 Z',shade,null);
 stroke('M -24 -193 C -17 -201 -9 -203 -4 -204 L 10 -207 Q 19 -201 21 -194 L 17 -195 L 11 -198 L 7 -194 L -4 -197 L -17 -190 Z',hi,ink,.74);
 stroke('M 9 -194 C 5 -184 9 -174 13 -166 C 18 -150 16 -136 18 -128',null,seam,.82);
 stroke('M -9 -113 Q 6 -111 12 -116 M -30 -133 Q -24 -132 -21 -126 M 18 -145 Q 21 -139 20 -131',null,seam,.68);
 stroke('M -26 -109 Q -12 -109 -8 -105 Q 5 -105 10 -108',null,hi,.78);
 // Held shopping tote has depth, a thick printed seam and one folded paper tucked above the lip.
 let toteX=-22+3*lean,toteY=-112+breath*.65;
 c.save();c.translate(toteX,toteY);c.rotate(.09+.065*Math.sin(t*2.1)-.10*lean);
 stroke('M -9 -19 C -11 -35 -6 -47 -2 -46 C 5 -45 10 -30 9 -17 L 5 -17 C 6 -31 1 -41 -2 -43 C -5 -41 -7 -33 -5 -18 Z',returned?'#9f8a76':'#a69e80',seam,.78);
 stroke('M -4 -24 C -1 -35 5 -40 16 -45 L 24 -27 L 22 -11 L 1 -10 Z',returned?'#d9c3a1':'#c9c8a8',seam,.72);
 stroke('M 8 -28 L 17 -33 L 19 -30 L 10 -25 M 11 -23 L 19 -27',null,returned?'#987e75':'#81917f',.55);
 stroke('M -14 -23 Q 2 -17 17 -23 L 20 17 Q 13 24 -9 20 L -16 14 Z',blue,ink,1.1);
 stroke('M 15 -22 L 20 -23 L 26 13 L 20 17 L 16 -10 Z',returned?'#666a79':'#647c77',ink,.75);
 stroke('M -13 -20 Q 2 -14 16 -20 M -8 14 Q 4 17 14 13 M -8 -19 L -6 18',null,returned?'#a59d88':'#9ca98b',.68);
 stroke('M -7 4 Q -1 -2 3 4 L 8 10 L 0 12 Z',returned?'#b99580':'#ad9d83',null);
 c.restore();
 // Near arm uses a real elbow-to-wrist chain; no icon or involuntary hold for the whole cut.
 let ax=-19+2*lean,ay=-185,ex=-12+25*lift+21*lean,ey=-153-14*lift-5*lean;
 let wx=-20+61*lift+36*lean,wy=-125-89*lift-15*lean; 
 const dx=wx-ex,dy=wy-ey,len=Math.hypot(dx,dy)||1,nx=-dy/len,ny=dx/len;
 stroke('M -26 -190 C -20 -194 -12 -191 -9 -182 L '+(ex+3)+' '+(ey+3)+' Q '+(ex-4)+' '+(ey+10)+' '+(ex-9)+' '+(ey+3)+' L -29 -173 Q -32 -182 -26 -190 Z',tunic,ink,1.2);
 line(c,[ax-9,ay+10,ex-7,ey+4,ex-4,ey+5],hi,.78);
 poly(c,[ex+nx*5.8,ey+ny*5.8,wx+nx*3.0,wy+ny*3.0,wx-nx*3.2,wy-ny*3.2,ex-nx*6.3,ey-ny*6.3],warm,ink,1.05);
 offsetLine({x:ex+nx*4,y:ey+ny*4},{x:wx+nx*2,y:wy+ny*2},returned?'#e3c39f':'#e1c6a5',.65);
 c.save();c.translate(wx,wy);c.rotate(lift*(2.65)+lean*.39);
 if(lift>.38)
  stroke('M -2.2 -3.0 Q 2 -4 4.1 -2 C 5.0 -.8 5.8 2.2 7.1 4.8 Q 7.6 6.7 6.2 6.1 L 3.8 3.9 L 5.0 10 Q 5.1 12.1 3.5 11.0 L 1.7 6.2 Q 1.55 13.2 .0 12.3 L -.9 6.0 Q -2.5 10.4 -3.59 8.5 L -3.30 3.0 Q -5.6 5.1 -6 3.2 Q -4.8 1.2 -4.7 -.6 Z',warm,ink,.83);
 else
  stroke('M -2.3 -3.0 C 1 -3.7 4.1 -2.9 4.7 -.1 C 5.3 1.4 6.0 4.6 4.7 5.6 Q 3.9 6.5 3.0 4.0 Q 2.9 8.5 1.1 8.6 Q .0 8.4 -.2 5.9 Q -2.0 7.4 -3.0 5.9 L -3.35 2.5 Q -5.5 3.7 -5.4 1.7 L -4.6 -.1 Z',warm,ink,.87);
 c.restore();
 // Turn from a three-quarter back to an ear/nose silhouette; her eye line is never pitched toward camera.
 c.save();c.translate(-3+9*notice+9*lean,-209-.95*notice);c.rotate(.083-.14*notice-.12*lean);
 stroke('M -10 -20 Q 1 -19 7 -17 L 8 7 Q 1 13 -8 7 Z',warm,ink,.93);
 stroke('M -17 -46 C -6 -59 10 -57 19 -45 L 21 -30 Q 23 -25 26 -24 L 24 -22 L 21 -21 L 20 -14 Q 14 -7 10 -9 L 0 -14 L -13 -18 C -19 -21 -22 -37 -17 -46 Z',warm,ink,1.20);
 stroke('M -23 -49 Q -13 -58 5 -55 Q 17 -52 21 -45 C 17 -40 9 -37 3 -35 Q 5 -31 1 -26 Q -4 -20 -8 -16 L -10 -9 Q -19 -7 -24 -13 Q -18 -15 -19 -24 C -28 -26 -27 -40 -23 -49 Z',returned?'#696270':'#686965',ink,1.2);
 stroke('M -23 -39 Q -21 -29 -20 -25 M -19 -45 Q -9 -49 -2 -43 M -17 -20 Q -12 -20 -10 -23',null,returned?'#928087':'#858780',.83);
 stroke('M 3 -31 Q -1 -35 -4 -31 Q -5 -26 -2 -23 Q 1 -22 3 -26',warm,seam,.71);
 stroke('M -2 -30 Q .2 -29 -1 -27 M 24 -17 L 21 -16 M 15 -15 Q 17 -14 20 -15 M 10 -18 Q 12 -16 14 -17',null,returned?'#95767a':'#927f71',.65);
 // Broad straw sunhat is the recurring silhouette. Worn indigo ribbon and linked radial seams.
 stroke('M -39 -47 C -34 -56 -15 -60 0 -63 C 16 -66 31 -62 36 -55 C 37 -49 29 -47 21 -46 C 0 -41 -24 -41 -35 -43 Z',returned?'#af907b':'#b7a181',ink,1.44);
 stroke('M -38 -47 C -18 -52 10 -57 30 -54 Q 36 -52 32 -50 C 16 -44 -7 -43 -27 -43 Q -37 -43 -38 -47 Z',returned?'#ceb090':'#cec09b',null);
 stroke('M -26 -52 C -25 -61 -24 -72 -13 -76 C -4 -80 10 -78 18 -72 Q 22 -67 22 -58 L 21 -55 Q 6 -56 -8 -49 Z',returned?'#d0b08d':'#d4c4a0',ink,1.22);
 stroke('M -25 -57 Q -7 -59 22 -65 L 22 -58 Q -8 -52 -25 -52 Z',returned?'#687581':'#657f80',ink,.69);
 stroke('M -22 -64 C -13 -71 6 -72 18 -67 M -17 -75 Q -4 -79 10 -75 M -37 -46 Q -8 -52 25 -52',null,returned?'#e0bf9b':'#e5d6ad',.9);
 for(let i=0;i<10;i++){let q=i/10,z=-37+66*q,dy=-46-4*Math.sin(q*Math.PI);line(c,[z,dy,z+1.3,dy+.98],returned?'#ac907b':'#aea178',.53);}
 c.restore();c.restore();c.restore();
};

window.returnBus=function(c,w,h,t=0){
 if(!c||!(w>0&&h>0))return;const p=h>w,z=p?1.17:1.21; t=Math.max(0,Math.min(1.18,Number(t)||0));
 c.save();c.beginPath();c.rect(0,0,w,h);c.clip();c.translate(w*.57,h*.76);c.scale(z,z);c.translate(-w*.57,-h*.76);city(c,w,h,t,'return');c.restore();
 waitingPassenger(c,w,h,t,true);
 stopForeground(c,w,h,t);
};
})();

