// Original painted close-up hand, index anchored at origin. Camera-right approach,
// with different pinching, pointing and relay poses. Wrist remains outside picture in macro.
window.hand=(g,x,y,s,rot,t,mode='point',kind='grandpa')=>{
const {path:P,line:L,ell:E,grad:G,rr:RR,R,clamp,ease}=Art;
const old=kind==='grandpa',teen=kind==='teen',mum=kind==='mum';
const ink=old?'#68584e':'#654a48',hi=old?'#e5c19a':'#f5d3b1',base=old?'#c49b7e':'#e7b393',shadow=old?'#a57e69':'#c48678',cast=old?'#8c7264':'#a56f68';
const pinch=mode==='pinch',tap=mode==='tap';
g.save();g.translate(x,y);g.rotate(rot);g.scale(s,s);g.lineJoin='round';g.lineCap='round';
// Continue the sleeve all the way beyond the photographic frame, even at a steep angle.
P(g,'M 205 -60 L 1120 -460 1200 -235 235 17 205 11 Z',teen?'#ded0af':mum?'#536676':'#858461',ink,1.5);
P(g,'M 233 -14 L 1150 -328 1200 -235 235 17 Z',teen?'#aa9980':mum?'#374b58':'#626750');
const skin=G(g,20,-37,97,47,[[0,hi],[.35,base],[.8,base],[1,shadow]]);
// Sleeves project back to camera; fingers nearest viewer are drawn last.
P(g,'M 116 -20 Q 135 -30 151 -39 L 198 -56 260 -85 295 -3 215 13 155 30 121 34 Z',teen?'#ded0af':mum?'#536676':'#858461',ink,2);
P(g,'M 153 1 Q 198 -9 241 -43 L 267 -35 285 -8 211 17 158 29 Z',teen?'#aa9980':mum?'#374b58':'#626750');
P(g,'M 139 -25 L 155 -31 170 22 Q 166 29 151 32 L 135 31 Z',teen?'#eee0bd':mum?'#667b84':'#9b9770',ink,1.3);
for(let j=0;j<5;j++){let z=j*4;P(g,'M '+(147+z*.65)+' '+(-24-z*.22)+' Q '+(149+z*.63)+' 0 '+(158+z*.55)+' 25',null,teen?'#b6a78d':mum?'#778b8e':'#73795c',.7)}
let shape=pinch?
'M -1 1 Q -4 -3 0 -7 Q 11 -14 23 -11 L 43 -7 Q 54 -12 65 -17 L 80 -30 Q 90 -39 103 -38 L 132 -30 Q 139 -26 145 -27 L 155 22 Q 138 29 128 28 Q 109 34 97 42 Q 85 50 74 47 L 51 36 35 25 Q 28 20 24 24 L 9 31 Q -1 34 -5 30 Q -8 26 -2 22 L 16 9 Q 22 4 29 6 L 46 12 54 11 45 6 24 1 8 3 Q 2 4 -1 1 Z':
'M 1 2 Q -4 1 -4 -3 Q -4 -8 3 -10 L 23 -13 Q 34 -16 50 -18 L 66 -21 Q 71 -23 78 -28 Q 85 -33 96 -29 L 111 -26 Q 124 -26 140 -24 L 152 21 127 27 Q 117 37 100 41 L 71 45 Q 59 45 51 41 L 40 36 Q 34 33 34 29 Q 33 25 39 23 Q 33 23 29 19 Q 26 15 32 11 L 47 3 Q 53 0 60 -3 L 47 -4 Q 35 -2 26 1 L 9 4 Z';
P(g,shape,skin,ink,1.8);
if(pinch){
 P(g,'M 0 -6 Q 12 -12 23 -9 L 45 -4 Q 59 -8 66 -13 L 75 -16 Q 58 -3 47 1 L 27 -4 12 -4 3 -2 Z',hi);
 P(g,'M -1 25 Q 9 20 20 13 Q 28 8 37 13 L 54 21 Q 61 22 65 20 L 55 30 36 18 Q 28 14 20 21 L 9 28 Z',shadow);
 P(g,'M 46 26 Q 57 36 68 38 Q 81 45 92 40 L 112 31 128 27 139 24 Q 128 34 112 39 L 89 49 72 47 58 39 Z',shadow);
 P(g,'M 5 -10 Q 12 -13 18 -11 L 20 -7 Q 13 -5 3 -6 Z','#ead1b6',ink,.65);
 P(g,'M -3 25 Q 3 21 6 21 L 8 25 Q 3 30 -3 30 Z','#ead1b6',ink,.65);
 P(g,'M 57 17 Q 65 10 72 5 M 60 26 Q 67 24 73 17 M 73 38 Q 84 36 88 30',null,ink,.83);
}else{
 P(g,'M 3 -9 Q 15 -13 26 -12 L 46 -16 62 -18 Q 55 -12 44 -11 L 24 -6 11 -5 1 -4 Z',hi);
 P(g,'M 31 13 L 53 1 65 -6 Q 72 -10 78 -9 L 72 -3 55 4 Q 37 12 32 17 Z',shadow);
 P(g,'M 35 26 L 51 18 63 14 76 6 Q 79 6 78 10 L 65 20 49 24 38 30 Z',shadow);
 P(g,'M 43 34 Q 61 42 72 39 L 93 36 Q 107 30 114 23 L 134 19 149 18 151 22 127 28 Q 115 38 98 42 L 72 45 Q 54 45 43 38 Z',shadow);
 P(g,'M -3 -5 Q 4 -10 10 -10 L 14 -8 Q 12 -5 6 -4 L -2 -3 Z','#ead3b7',ink,.55);
 P(g,'M 31 11 Q 34 9 40 9 L 49 6 M 39 23 Q 45 20 55 18 L 70 13 M 50 35 Q 59 32 71 31 L 82 23',null,ink,.95);
 P(g,'M 71 -23 Q 80 -21 85 -16 L 90 -12 M 95 -24 Q 105 -18 108 -13',null,shadow,1.15);
}
P(g,'M 93 -24 Q 104 -27 116 -25 L 135 -21 135 -14 119 -12 104 -17 Z',hi);
P(g,'M 116 16 Q 124 9 139 9 M 123 22 Q 133 17 142 16',null,shadow,.85);
if(old){for(let [a,b,d] of [[23,-11,5],[29,-12,4],[49,-15,5],[55,-14,4],[78,-22,5],[85,-24,5],[103,-19,5],[47,15,3],[62,25,5],[120,0,7],[91,32,7],[113,10,5],[95,-5,4]])P(g,'M '+a+' '+b+' q '+d+' 1 '+(d+2)+' 4',null,'rgba(109,83,70,.58)',.65);
for(let j=0;j<9;j++){let X=84+((j*19)%48),Y=-15+((j*17)%39);E(g,X,Y,.8,.6,'rgba(121,87,65,.45)')}}
g.restore()
};
