/* Original character animation · After AGI.
   200 units from shoes to crown; path drawing uses a common sepia ink. */
(() => {
  const ink='#443141', p2=new Map(), sin=Math.sin, pi=Math.PI;
  const clamp=(n)=>Math.min(1,Math.max(0,n));
  const ease=(a,b,n)=>{const v=clamp((n-a)/(b-a));return v*v*(3-2*v);};
  const S={
    teen:{skin:'#f9c0a0', shade:'#da887d', shine:'#ffe2be',hair:'#313248',hairHi:'#555770',hairShade:'#24253a', brow:'#493043',shirt:'#efe1c2', cuff:'#fff0ce', shadow:'#bfaa98', bottom:'#465568', bottomHi:'#6c7884', apron:'#a54f4b', apronHi:'#c77666',eye:'#753e38', shoe:'#56444e'},
    mum:{skin:'#ebb090', shade:'#c98377', shine:'#ffd5b0', hair:'#483941',hairHi:'#73555c',hairShade:'#302637',brow:'#4f3341',shirt:'#536c7e',cuff:'#c0ced0',shadow:'#3c5061',bottom:'#3b4553',bottomHi:'#596872',apron:'#474c66',apronHi:'#647990',eye:'#71534a',shoe:'#443947'},
    grandpa:{skin:'#e3ac87',shade:'#b77569',shine:'#ffd3a6',hair:'#a9a19f',hairHi:'#d8cfbb',hairShade:'#766b72',brow:'#76606a',shirt:'#7a7d5b',cuff:'#d7be90',shadow:'#585e47',bottom:'#6a6270',bottomHi:'#887b82',apron:'#4e664f',apronHi:'#8d9270',eye:'#61423a',shoe:'#4b3e46'}
  };
  function mixHex(a,b,t){
    const x=parseInt(a.slice(1),16), y=parseInt(b.slice(1),16);
    const R=(f)=>Math.round(((x>>f)&255)*(1-t)+((y>>f)&255)*t);
    return '#'+((R(16)<<16)|(R(8)<<8)|R(0)).toString(16).padStart(6,'0');
  }
  // Local palette grades, not canvas filters; cost per frame is a lookup.
  const schemeAlias={'warm-left':'workshop','cool-office':'office','dusk-rim':'evening'};
  const edgeLight={
    'warm-left':['#ffe4ac',.58,-1],
    'cool-office':['#d8eeed',.43,1],
    'dusk-rim':['#ffd488',.77,-1],
  };
  const schemes={
    workshop:['#f4c579','#816d65',.07,.10],
    office:['#ccd8d2','#63778b',.06,.10],
    evening:['#ffc88b','#8f6578',.105,.133],
    night:['#9db8c2','#53587f',.064,.145],
  };
  const grades=Object.fromEntries(Object.entries(schemes).map(([key,[hi,lo,h,l]])=>[
    key,Object.fromEntries(Object.entries(S).map(([kind,colors])=>[
      kind,Object.fromEntries(Object.entries(colors).map(([name,color])=>{
        const isLit=/skin|shine|Hi|cuff|shirt/.test(name);
        return [name,mixHex(color,isLit?hi:lo,isLit?h:l)];
      }))
    ]))
  ]));
  function path(d){if(!p2.has(d))p2.set(d,new Path2D(d));return p2.get(d);}
  function patch(c,d,fill,s=ink,w=.78){
    const q=path(d);
    if(fill){c.fillStyle=fill;c.fill(q);}
    if(s){c.strokeStyle=s;c.lineWidth=w;c.stroke(q);}
  }
  function oval(c,x,y,rx,ry,fill,stroke,w=.7,rot=0){
    c.beginPath();c.ellipse(x,y,rx,ry,rot,0,pi*2);
    if(fill){c.fillStyle=fill;c.fill();} if(stroke){c.lineWidth=w;c.strokeStyle=stroke;c.stroke();}
  }
  function line(c,x,y,X,Y,col,w=1){
    c.beginPath();c.moveTo(x,y);c.lineTo(X,Y);c.lineWidth=w;c.strokeStyle=col;c.stroke();
  }
  function limb(c,A,B,C,wa,we,ww,fill){
    // Segmented silhouette, kept rounded at the elbow and narrow at the wrist.
    const n=(a,b)=>{let dx=b[0]-a[0],dy=b[1]-a[1],m=Math.hypot(dx,dy)||1;return[-dy/m,dx/m];};
    const n1=n(A,B),n2=n(B,C),mid=n([0,0],[n1[1]+n2[1],-n1[0]-n2[0]]);
    const at=(a,v,w)=>[a[0]+v[0]*w,a[1]+v[1]*w];
    const a=at(A,n1,wa), e=at(B,mid,we), w=at(C,n2,ww), aa=at(A,n1,-wa), ee=at(B,mid,-we), w2=at(C,n2,-ww);
    c.beginPath(); c.moveTo(...a);c.quadraticCurveTo(...at(B,n1,we*1.35),...e);
    c.quadraticCurveTo(...at(B,n2,we),...w);c.quadraticCurveTo(...C,...w2);
    c.quadraticCurveTo(...at(B,n2,-we),...ee); c.quadraticCurveTo(...at(B,n1,-we*.78),...aa);
    const crown=[A[0]-n1[1]*wa*.87,A[1]+n1[0]*wa*.87];
    c.quadraticCurveTo(...crown,...a);c.closePath();c.fillStyle=fill;c.fill();c.strokeStyle=ink;c.lineWidth=.8;c.stroke();
  }
  function palm(c,x,y,a,s,gesture,kind){
    c.save();c.translate(x,y);c.rotate(a);
    if(gesture==='pat'){
      const top='M -3.7 -3.8 Q -1.1 -5.4 .9 -4.8 Q 3.05 -4.3 4.6 -4.76 Q 8.4 -5.5 10 -4.46 Q 10.75 -3.38 8.91 -2.8 L 7.74 -2.05 Q 11.5 -2.31 14.85 -1.38 Q 16.55 -1.24 17.6 -.23 Q 18.28 .76 17.24 1.36 Q 17.02 2.2 15.07 2.2 L 14.62 3.06 Q 13.9 3.94 12.17 3.33 L 11.65 4.16 Q 10.68 5.12 9.35 4.59 Q 8.79 5.65 7.37 5.47 Q 4.44 5.55 1.25 4.72 Q -2.06 4.09 -3.42 1.53Z';
      patch(c,top,s.skin,ink,.71);
      patch(c,'M -3.5 .35 Q -1.4 1.56 1.73 1.44 Q 3.78 2.24 7.37 3.1 L 8.85 4.55 Q 8.29 5.56 6.72 5.15 Q 1.63 4.95 -.26 3.91 Q -3.12 2.4 -3.5 .35Z',s.shade,null);
      patch(c,'M -.5 -2.94 Q 1.89 -3.81 5.22 -3.66 M 8.25 -1.54 Q 11.93 -1.74 14.14 -.79 M 15.49 -.54 L 16.42 -.25',null,s.shine,.57);
      patch(c,'M -.4 .74 Q 2.35 -.35 4.83 .03 Q 6.59 -.7 7.77 -2.15 M 9.09 1.04 Q 12.7 1.5 14.82 2.18 M 9.17 2.61 Q 10.77 2.91 12.12 3.36 M 7.09 3.85 L 9.07 4.48 M 3.55 2.38 Q 4.52 2.41 5.17 3.05',null,s.shade,.49);
      patch(c,'M 3.2 -1.35 Q 4.5 -1.69 5.61 -1.66 M 10.44 -.2 L 11.31 -.07 M 12.1 .03 L 12.84 .09',null,s.brow,.29);
      oval(c,16.04,.22,.81,.29,s.shine,null,.5,.21);
    } else if(gesture==='point'){
      patch(c,'M -2 -3 Q 1 -5 4 -5 L 15 -5 Q 18 -4 16 -2 L 8 0 Q 12 2 10 4 Q 10 7 4 7 Q 0 6 -2 3 Z',s.skin);
      patch(c,'M 2 -2 Q 5 -1 8 0 M 5 5 L 8 4',null,s.shade,.58);
    } else if(gesture==='open'){
      patch(c,'M -3 -3 Q 0 -6 4 -6 L 11 -8 Q 14 -8 12 -6 L 7 -3 L 16 -4 Q 18 -3 16 -1 L 9 0 L 16 1 Q 18 3 15 4 L 8 3 L 13 6 Q 14 8 11 8 L 3 6 Q -2 6 -3 3 Z',s.skin);
      patch(c,'M 1 1 Q 4 1 7 -1 M 2 3 L 6 4',null,s.shade,.58);
    } else if(gesture==='fix'){
      patch(c,'M -4 -3 Q -1 -6 7 -7 Q 15 -6 13 -1 Q 12 4 8 5 Q 7 8 2 7 L -4 3 Z',s.skin);
      patch(c,'M 5 -4 Q 10 -4 11 -1 M 6 -1 Q 10 -1 10 2 M 4 2 Q 7 2 8 5',null,s.shade,.62);
      if(kind==='teen'){
        patch(c,'M 8 -5 L 12 -12 Q 14 -15 16 -14 Q 18 -13 17 -10 L 13 -4 Z','#c65948',ink,.72);
        patch(c,'M 15 -13 L 22 -24 L 23 -24 L 24 -22 L 17 -12 Z','#c0c1bd',ink,.66);
        patch(c,'M 14 -12 L 11 -7',null,'#f0a077',.7);
      }
    } else {
      patch(c,'M -3 -3 Q 5 -7 7 -1 L 7 6 Q 6 9 3 6 Q 1 7 -1 5 L -4 2 Z',s.skin);
      patch(c,'M 1 1 L 4 4 M 4 0 L 6 3',null,s.shade,.6);
    } c.restore();
  }
  const walkStrength=t=>ease(0,.21,t)-ease(1.18,1.58,t);
  function gait(t,foot){
    const phase=(t+.06)*pi*2*1.12+(foot?pi:0), amp=walkStrength(t);
    return [Math.cos(phase)*.205*amp, Math.pow(Math.max(0,sin(phase)),1.45)*7.8*amp];
  }
  function pants(c,s,k,p,t){
    if(p==='sitDown'){
      const a=ease(.045,.5,t), d=(p,q)=>p+(q-p)*a, pair=(p,q)=>[d(p[0],q[0]),d(p[1],q[1])];
      patch(c,'M -18 106 Q 3 109 18 119 L 21 137 Q 8 146 -18 141 L -23 131Z',s.bottom);
      const backH=pair([-12,124],[-15,141]),backK=pair([-16,158],[18,152]),backA=pair([-14,185],[24,184.8]);
      const nearH=pair([8,123],[-3,139]),nearK=pair([13,157],[30,150]),nearA=pair([15,185],[33,187.45]);
      limb(c,backH,backK,backA,d(8.4,10.3),d(7.25,8),5.05,s.bottom);
      limb(c,nearH,nearK,nearA,d(9.1,10.5),d(7.6,8.4),5.55,s.bottomHi);
      line(c,nearK[0]+1,nearK[1]+1,nearA[0]+1,nearA[1]-8,s.bottom,.8);
      for(const [i,ankle] of [backA,nearA].entries()){
        c.save();c.translate(...ankle);c.rotate(i?-a*.13:a*.095);
        c.scale(i?1-a*.52:.8+a*.08,1);
        patch(c,'M -6 0 L 5 0 Q 10 6 15 6 Q 21 7 22 11 Q 18 14 -7 12Z',s.shoe);
        patch(c,'M -5 10.5 Q 7 11.5 20 10.5',null,'#c2a28c',.65);c.restore();
      }
      return;
    }
    if(p==='sit'||p==='invite'){
      patch(c,'M -18 110 Q 1 112 17 111 L 20 138 Q 22 146 6 152 L -20 145 Q -26 137 -18 110Z',s.bottom);
      patch(c,'M -17 116 Q -14 125 -19 140 Q -8 147 18 145 L 31 160 L 33 185 Q 29 190 21 187 L 14 167 Q -15 173 -24 159 Q -27 145 -17 116Z',s.bottom);
      patch(c,'M -11 136 Q 6 139 29 141 Q 40 143 41 155 L 43 187 Q 37 190 30 185 L 24 161 L -4 159 Q -16 159 -20 149Z',s.bottomHi);
      patch(c,'M 22 183 Q 28 185 32 183 L 37 191 Q 48 193 48 197 L 20 197Z',s.shoe);
      patch(c,'M 31 184 Q 36 187 42 184 L 49 191 Q 60 191 61 196 Q 49 200 31 198Z',s.shoe);
      patch(c,'M 34 196 Q 47 197 59 195 M 25 195 L 31 195',null,'#d2b19a',.68);
      patch(c,'M -16 146 Q 2 153 21 150 M 27 151 L 30 168 M 37 159 L 40 179',null,s.bottom,.72);
      return;
    }
    const yStretch=k==='mum'?1.28:k==='grandpa'?1.2:1.21, width=k==='grandpa'?1.08:k==='mum'?.88:.85;
    const split=p==='open'?.13:p==='present'?.11:p==='fix'?.09:p==='listen'?.045:k==='teen'?.074:.051;
    const stride=p==='open'||p==='present'?4.7:p==='fix'?2.4:0;
    const back=p==='walk'?gait(t,0):[0,0], near=p==='walk'?gait(t,1):[0,0];
    const fallA=back[1]/76,fallB=near[1]/76;
    c.save();c.translate(0,200);c.scale(width,yStretch);c.translate(0,-200);
    c.save(); c.transform(1,0,-split+back[0],1-fallA,(split-back[0])*119,fallA*119);
    patch(c,'M -17 119 Q -20 134 -18 154 L -17 184 Q -12 191 -4 186 L 3 157 L 8 127Z',s.bottom);
    patch(c,'M -17 143 Q -14 152 -11 162 L -10 181 L -5 185 L 1 156 L 2 147Z',s.bottomHi,null);
    patch(c,'M -15 185 Q -12 187 -6 185 L -2 191 Q 7 192 8 197 Q 0 199 -18 198 L -19 195Z',s.shoe);
    patch(c,'M -16 155 L -12 157 M -12 179 L -8 177',null,s.bottomHi,.61);
    patch(c,'M -16 196 L 5 196',null,k==='teen'?'#e5c09d':'#b0988b',.85);
    c.restore();
    c.save(); c.transform(1,0,split*.34+near[0],1-fallB,-(split*.34+near[0])*119+stride*.2,fallB*119);
    patch(c,'M -7 124 Q -4 147 1 164 L 7 187 Q 15 192 21 186 L 19 151 L 18 120Z',s.bottomHi);
    patch(c,'M 12 139 L 9 158 L 15 185 L 20 187 L 18 150Z',s.bottom,null);
    patch(c,'M 7 186 Q 13 188 20 185 L 24 191 Q 35 192 37 197 Q 25 200 8 198 Q 5 195 7 186Z',s.shoe);
    patch(c,'M 10 196 Q 23 198 35 196',null,k==='teen'?'#e5c09d':'#b0988b',.85);
    patch(c,'M 10 162 L 13 165 M 16 189 L 22 191 M 14 191 L 20 193',null,s.bottomHi,.61);
    if(k==='teen') patch(c,'M -1 163 L 4 186 M 7 189 Q 14 192 21 189',null,'#d69776',.69);
    c.restore();c.restore();
  }
  function coat(c,s,k){
    patch(c,'M -10 56 Q -8 50 -6 43 L 8 43 L 11 56 L 21 61 L 17 73 L -13 68Z',s.skin);
    patch(c,'M -6 47 L 8 46 L 9 55 Q 5 60 -4 61 L -10 56Z',s.shade,null);
    if(k==='teen'){
      patch(c,'M -12 56 Q -17 57 -22 63 Q -23 78 -20 100 L -23 129 Q -11 138 18 132 L 21 106 L 19 67 Q 15 58 10 56 Q 6 65 1 65 Q -7 63 -12 56Z',s.shirt);
      patch(c,'M -20 67 Q -18 87 -13 94 L -15 112 L -22 127 L -22 101Z',s.shadow,null);
      patch(c,'M -14 58 L -8 58 L -4 74 L 8 75 L 10 58 L 15 60 L 15 77 L 18 89 L 22 135 Q 5 141 -18 136 L -16 90 L -14 76Z',s.apron);
      patch(c,'M -14 87 L -11 96 L -13 134 Q -16 136 -18 135 L -16 101Z','#77404a',null);
      patch(c,'M 8 82 L 15 84 L 18 124 L 13 129 Q 9 112 8 82Z',s.apronHi,null);
      patch(c,'M -14 95 Q 0 99 17 94 M -14 98 Q 0 101 17 97',null,'#e6ab8a',.55);
      patch(c,'M -5 106 L 12 106 L 13 119 Q 4 125 -3 119Z','#a65353','#7d3c47',.65);
      patch(c,'M -4 108 L 11 108 M -2 109 L 0 118 L 8 118',null,'#eab28d',.54);
      oval(c,-11,77,1.7,1.8,'#f0c18a','#763a40',.65);oval(c,11,78,1.7,1.8,'#f0c18a','#763a40',.65);
      patch(c,'M -12 56 L -5 64 L 1 65 L -4 71 L -12 65Z M 10 56 L 1 65 L 6 71 L 13 64Z',s.cuff,s.shadow,.67);
    } else if(k==='mum'){
      patch(c,'M -11 55 Q -25 60 -25 68 L -24 89 L -20 104 L -24 131 Q -9 139 19 130 L 17 104 L 24 79 L 20 64 L 11 55 Q 1 67 -11 55Z',s.shirt);
      patch(c,'M -23 70 L -12 84 L -11 100 L -13 130 L -22 129 L -20 104 L -24 88Z',s.shadow,null);
      patch(c,'M -11 55 L 1 65 L 1 118 L -6 111 L -9 77Z','#ead2b2',ink,.76);
      patch(c,'M 11 55 L 4 64 L 1 84 L 10 71 L 16 67Z M -11 55 L -3 67 L 1 84 L -10 73 L -17 69Z','#7f98a0',ink,.8);
      patch(c,'M 4 82 L 2 104 L 3 130 M 7 101 L 16 99 M -5 125 L -13 125',null,'#bdd0c3',.65);
      oval(c,4,104,1.1,1.15,'#d9b992');oval(c,4,113,1.05,1.1,'#d9b992');
      patch(c,'M 8 80 L 16 79 L 17 87 L 9 88Z','#d9c1a1','#312a3b',.55);
      patch(c,'M 10 82 L 15 81 M 10 84 L 14 84',null,'#4b6677',.65);
    } else {
      patch(c,'M -11 54 Q -26 59 -29 70 L -26 94 L -21 111 L -25 132 Q -1 141 23 132 L 20 108 L 25 86 L 24 68 Q 22 61 12 56Z',s.shirt);
      patch(c,'M -28 70 Q -20 77 -14 94 L -15 117 L -18 134 L -23 132 L -21 111 L -26 94Z',s.shadow,null);
      patch(c,'M -12 55 L -5 66 L 3 72 L 10 58 L 13 57 L 16 66 Q 16 74 7 79 Q -2 79 -11 72 Q -18 68 -16 61Z',s.cuff,ink,.72);
      patch(c,'M -8 62 Q -2 67 3 71 L 8 62 M 5 81 L 5 96 M 4 94 L 8 94 M 10 112 L 18 107 M -15 124 L -1 126 M 7 126 L 16 124',null,'#a19868',.7);
      for(let i=0;i<6;i++) line(c,-16+i*5,132,-17+i*6,135,'#a89a70',.6);
      oval(c,5,84,1.15,1.3,'#bb9c77');oval(c,5.5,89,1.05,1.2,'#bb9c77');
    }
  }
  function eye(c,x,y,s,small,blink,focus,kind,look=0){
    c.save();c.translate(x,y);if(small)c.scale(.76,.86);
    if(blink>.87){patch(c,'M -6 0 Q 0 3 6 -1',null,ink,1.05);c.restore();return;}
    c.scale(1,Math.max(.14,1-blink));
    const isOld=kind==='grandpa';
    const Ey=(focus==='fix'?.74:focus==='sit'?.82:focus==='sitDown'?.89:focus==='study'?.71+.26*look:1)*(isOld?.75:kind==='mum'?.86:1);
    c.scale(1,Ey);
    const ey=focus==='fix'||focus==='present'?1.15:focus==='open'?-.24:focus==='listen'?1.05-1.85*look:focus==='study'?2.05-3.4*look:focus==='sitDown'?1.4-2.95*look:focus==='invite'?1.85:0;
    const ex=focus==='point'?1:focus==='fix'?.62:focus==='sit'?-.56:focus==='invite'?1.18:focus==='listen'?.12+.65*look:focus==='study'?1.28-1.72*look:focus==='sitDown'?-.12+1.52*look:0;
    const scl=isOld?.74:kind==='mum'?.89:1;
    const lid='M -7 0 Q -2 -5.5 4 -4.9 Q 8 -4 8.5 -.6 Q 5 2.8 -1 3 Q -5 2.7 -7 0Z';
    patch(c,lid,'#fff0d6','#644352',.56);
    c.save();c.clip(path(lid));c.translate(ex,ey);
    oval(c,2.5,-.85,3.45*scl,4.05*scl,s.eye,'#553345',.65);
    oval(c,3,-.9,1.6*scl,2.6*scl,'#382738');
    oval(c,1.4,-2.7,1.08*scl,1.3*scl,'#ffe9cf');
    if(!isOld)oval(c,4.25,1,.55,.62,'#f6b085');
    c.restore();
    patch(c,isOld?'M -7 0 Q -3 -4.6 3 -4.9 Q 7 -4.5 8.6 -.6':'M -7 0 Q -3 -4.7 3 -4.9 Q 7 -4.8 8.6 -.6 M 7 -3 L 8.3 -4.7 M -3 -3.4 L -4.4 -4.8',null,ink,isOld?.94:1.1);
    patch(c,isOld?'M -5 2.8 Q -1 4 2 3.2 M -5 5 Q -.5 7 4 5.3':'M -5 2.8 Q -1 4 2 3.2',null,s.shade,.59);c.restore();
  }
  function rim(c,light,darkPath,litPath,strength,wide=.75){
    if(!light)return;
    c.save();c.globalAlpha*=light.strength*strength;
    patch(c,light.side<0?darkPath:litPath,null,light.color,wide);
    c.restore();
  }
  function head(c,s,k,p,t,light){
    const blinkHz=(t+(k==='mum'?1.2:k==='grandpa'?2.1:0.2))%4.36;
    const rise=ease(.21,.82,t), warm=ease(.8,1.49,t), welcome=ease(.12,.94,t), release=ease(2.33,3.2,t), ask=ease(1.3,2.0,t), glance=ease(.43,.91,t);
    const blink=Math.max(p==='smile'?.46:p==='listen'?.23*warm:p==='invite'?.18*welcome:0,1-ease(0,.114,Math.abs(blinkHz-3.8)),p==='listen'?1-ease(0,.099,Math.abs(t-.38)):p==='study'?1-ease(0,.103,Math.abs(t-1.51)):0);
    const nod=(ease(.1,.6,t%5.41)-ease(1.1,1.7,t%5.41));
    let tilt=p==='fix'?.24+.1*nod:p==='open'?-.09-.038*nod:p==='point'?-.065+.038*nod:p==='sit'?.03+.062*nod:p==='sitDown'?.095-.193*glance:p==='smile'?-.103+.039*nod:p==='listen'?.14-.265*rise+.056*warm:p==='study'?.17+.13*ease(.04,.77,t)-.433*ask:p==='invite'?.05+.14*welcome-.18*release:p==='present'?.04+.14*ease(.08,.67,t):k==='grandpa'?.04:-.025;
    const profile=p==='listen'?.976+.10*rise:p==='study'?1-.10*ask:p==='sitDown'?1-.08*glance:1;
    const delay=p==='study'?1.1+1.85*ease(.06,1.13,t)-3.5*ask:p==='listen'?-1.7+2.6*rise:p==='sitDown'?-1.6+4.1*glance:0;
    c.save();c.translate(delay,45);c.rotate(tilt+sin(t*2.2)*.009);c.scale(profile,1);c.translate(0,-45);
    if(k==='teen'){
      patch(c,'M -22 14 Q -17 0 0 1 Q 17 -1 23 14 Q 27 21 20 42 Q 20 48 17 53 Q 11 50 6 51 L -13 51 Q -25 45 -25 30 Q -28 24 -22 14Z',s.hair);
      patch(c,'M -23 24 Q -22 38 -14 48 L -19 43 Q -27 42 -25 29Z',s.hairShade,null);
      c.save();c.translate(-22,43);c.rotate((sin(t*3.2)+.55*sin(t*6.5))*(p==='fix'?.027:.052));c.translate(22,-43);
      patch(c,'M -23 40 Q -23 44 -28 48 Q -33 52 -30 58 Q -27 55 -24 55 Q -22 58 -18 56 L -12 47 Z',s.hair);
      patch(c,'M -28 52 Q -24 49 -21 47 M -27 55 Q -24 53 -22 51',null,s.hairHi,.67);
      patch(c,'M -26 43 Q -21 43 -20 46 L -23 50 L -28 49Z','#d56d62',ink,.65);
      patch(c,'M -26 44.5 L -22 46',null,'#f39875',.62);
      c.restore();
    } else if(k==='mum'){
      patch(c,'M -18 10 Q -14 -2 6 2 Q 22 2 24 16 L 24 34 Q 23 45 10 46 L -9 49 Q -20 45 -23 34 Q -26 21 -18 10Z',s.hair);
      patch(c,'M -19 28 Q -28 24 -32 32 Q -37 44 -22 48 L -12 43Z',s.hair);
      patch(c,'M -29 33 Q -30 39 -23 43 L -24 45 M -21 44 L -15 41',null,s.hairHi,.9);
    } else {
      patch(c,'M -23 16 Q -22 7 -14 4 Q -10 -2 -5 2 Q 0 -1 6 2 Q 20 0 24 15 Q 26 24 22 38 L -15 45 Q -26 39 -25 29 Q -27 22 -23 16Z',s.hair);
    }
    patch(c,'M -18 21 Q -12 9 3 11 Q 18 11 20 25 L 22 30 L 25 34 Q 25 36 21 37 L 21 40 Q 21 48 16 52 Q 12 55 7 54 Q -3 53 -10 48 L -16 42 Q -22 37 -21 29Z',s.skin);
    patch(c,'M -18 21 Q -16 26 -16 32 Q -13 43 -4 49 Q 4 53 12 54 Q 6 56 -3 53 Q -16 49 -19 40 Q -22 33 -21 28Z',s.shade,null);
    patch(c,'M 13 21 Q 18 21 19 26 L 21 31 Q 18 30 16 27 M 17 43 Q 19 45 16 47 L 10 48 L 8 46Z',s.shine,null);
    patch(c,'M -18 31 Q -25 27 -25 34 Q -24 41 -17 41 L -15 38Z',s.skin);
    patch(c,'M -21 32 Q -25 32 -21 36 L -18 37',null,s.shade,.75);
    if(k==='teen'){
      patch(c,'M -23 31 Q -29 17 -18 7 Q -8 -2 7 1 Q 19 2 22 12 Q 25 18 22 23 Q 18 18 15 18 L 14 24 Q 10 24 6 15 Q 4 22 -3 25 L -2 20 Q -7 24 -12 32 L -13 27 Q -16 30 -17 35Z',s.hair);
      patch(c,'M -22 19 Q -14 5 1 4 Q 14 3 20 12 Q 8 8 2 13 Q -5 14 -8 18 Q -15 19 -21 25Z',s.hairHi,null);
      patch(c,'M -16 17 Q -10 12 -3 11 M 4 7 Q 11 7 16 10 M -21 25 L -22 29',null,'#9f8490',.54);
      patch(c,'M -15 22 L -10 21 M -14 24 L -9 23',null,'#f0b178',.8);
    } else if(k==='mum'){
      patch(c,'M -22 32 Q -25 25 -21 16 Q -17 1 -3 2 Q 0 2 2 5 Q 15 0 22 13 Q 24 18 22 25 Q 19 17 9 15 Q 3 15 0 10 Q -1 20 -13 25 Q -16 28 -17 35Z',s.hair);
      patch(c,'M -20 22 Q -14 13 -1 8 Q -8 5 -17 13Z M 4 7 Q 17 5 21 15 Q 14 10 7 11Z',s.hairHi,null);
      patch(c,'M -18 27 Q -12 24 -8 19 M 10 11 Q 16 11 19 13',null,'#99757c',.65);
      oval(c,-19,39,1.5,1.65,'#eed0a3',ink,.65);
    } else {
      patch(c,'M -25 30 Q -28 18 -20 13 Q -18 6 -12 6 Q -8 1 -2 4 Q 3 -1 10 4 Q 21 4 24 14 L 23 23 Q 20 18 19 15 Q 14 17 10 12 Q 8 16 3 16 L 6 11 Q 0 16 -6 17 L -4 12 Q -12 15 -14 25 L -17 33Z',s.hair);
      patch(c,'M -21 18 Q -15 9 -1 7 M 2 8 Q 10 5 19 10 M -10 15 L -15 19 M 12 12 L 20 14',null,s.hairHi,1.05);
      patch(c,'M -11 24 L -6 22 M 5 20 L 12 20 M -13 38 Q -11 41 -10 41 M 19 36 L 22 35 M 0 46 Q 2 49 3 49',null,s.shade,.57);
      patch(c,'M 1 40 Q 4 35 10 37 Q 11 37 12 39 Q 16 37 19 40 L 19 42 L 12 41 Q 7 42 2 42Z',s.hairHi,s.hairShade,.56);
    }
    oval(c,0,36,7,2.15,k==='grandpa'?'#cf8a75':'#eca08c',null,.7,-.15);
    for(let i=0;i<3;i++) line(c,-4+i*2.3,35.1,-4.9+i*2.3,36.8,s.shade,.48);
    if(k==='grandpa'){
      if(p==='study'){
        c.beginPath();c.moveTo(-10,26.3-2.1*ask);c.quadraticCurveTo(-5.4,23.7-1.3*ask,.1,26.8-4.1*ask);
        c.moveTo(8.9,24.8-4.2*ask);c.quadraticCurveTo(13.3,23.1-3.1*ask,19.1,24.2-.6*ask);
        c.lineWidth=1.6;c.strokeStyle=s.brow;c.stroke();
        c.beginPath();c.globalAlpha*=.42;c.moveTo(6.5,23.8);c.lineTo(5.6,20.2);c.lineTo(7.2,17.6);c.lineWidth=.53;c.strokeStyle=s.shade;c.stroke();c.globalAlpha/=.42;
      }else patch(c,'M -10 27 Q -6 23 0 25 M 9 24 Q 15 21 19 24',null,s.brow,1.75);
    }else{
      patch(c,p==='open'?'M -10 26 Q -6 23 1 24 M 10 23 Q 16 20 20 23':'M -10 25 Q -6 22 1 23 M 10 23 Q 15 20.5 20 23',null,s.brow,k==='mum'?1.18:.95);
    }
    const focus=p==='study'?ask:p==='sitDown'?glance:rise;
    eye(c,-3,k==='grandpa'?29.7:30,s,k==='grandpa',blink,p,k,focus);eye(c,14.5,28.5,s,true,blink,p,k,focus);
    if(k==='grandpa'){
      patch(c,'M -18 29 L -10 29 M -10 26 Q -2 24 4 27 L 4 32 Q 1 36 -6 34 Q -10 33 -10 26Z M 4 28 Q 6 26 9 28 M 9 26 Q 15 23 22 26 L 22 31 Q 20 34 14 34 Q 10 34 9 26Z',null,'#534452',.86);
      patch(c,'M -6 27 L -3 27 M 14 26 L 17 25.7',null,'#e7d4b0',.62);
    }
    patch(c,'M 14 29 Q 14 32 18 34 L 16 36 L 13 36.5',null,s.shade,.71);
    const smile=p==='open'?.77:p==='sit'?(k==='teen'?.79:.62):p==='sitDown'?ease(.10,.48,t)*.78:p==='walk'?.22:p==='smile'?.83:p==='invite'?.68+.14*welcome:p==='listen'?warm*.62:0;
    if(p==='study'){
      const speak=(ease(1.68,1.78,t)-ease(2.195,2.56,t))*(.59+.29*Math.sin((t-1.65)*25));
      if(speak>.14){
        c.beginPath();c.moveTo(9.5,43.5);c.quadraticCurveTo(14,41.0-speak,18.5,43.5);
        c.quadraticCurveTo(15.5,43.7+speak*6,12.9,44+speak*2.9);c.closePath();
        c.lineWidth=.64;c.strokeStyle='#76505a';c.fillStyle='#9e5d66';c.fill();c.stroke();
      }else patch(c,'M 10 44 Q 14 42.8 18.4 43.6',null,'#8c515a',.78);
    }else if(smile>.04){
      const old=k==='grandpa';
      c.beginPath();c.moveTo(10-smile,43);
      c.quadraticCurveTo(14,42.4+smile*2.9,18+(old?-.7:1.1)*smile,42.8-2*smile);
      c.quadraticCurveTo(16.6,43.5+smile*4.5,13.8,43.0+smile*3.3);
      c.quadraticCurveTo(11.2,43.0+smile*3,10-smile,43);c.closePath();
      c.fillStyle='#a95660';c.fill();c.strokeStyle='#70404d';c.lineWidth=.62;c.stroke();
      if(smile>.41){
        c.save();c.globalAlpha*=ease(.41,.76,smile);
        patch(c,'M 12 44 L 16.5 43.7',null,'#ffe5bf',.55);c.restore();
      }
    } else patch(c,p==='listen'?'M 11 43 Q 14 42 17 43':k==='teen'?'M 11 43 Q 15 41 18 42':'M 10 43 Q 14 44 18 42',null,'#8d4a56',.7);
    patch(c,'M 10 49 Q 13 50 15 48.5',null,s.shade,.65);
    rim(c,light,'M -23 13 Q -20 5 -10 2.8 M -22 31 Q -25 32 -23 36','M 14 3.3 Q 21 6 23 15 M 22 34 L 23 35 M 20.5 41 Q 19.6 47 16 50',.92,1.35);
    c.restore();
  }
  function arms(c,s,k,p,t,far,pin){
    const sway=sin(t*2.65+(k==='grandpa'?1:0)), beat=sin(t*4.1), size=k==='teen'?1:1.07;
    const fixPhase=t%3.35, effort=ease(.25,.63,fixPhase)-ease(1.92,2.3,fixPhase);
    const turn=sin(t*11)*effort;
    const reach=ease(.12,.68,t%5.7)-ease(4.2,5.55,t%5.7);
    let A=far?[14,66]:[-16,68],B,C,gesture=p;
    if(p==='listen'){
      const relax=ease(.35,1.38,t);
      B=far?[24,90+8*relax]:[-10-5*relax,99+4*relax];
      C=far?[24,112+10*relax]:[19-34*relax,97+35*relax+sway*.26];gesture='stand';
    } else if(p==='study'){
      const follow=ease(.21,.9,t), still=ease(1.18,1.45,t), rise=ease(1.39,2.16,t);
      if(!far)A=[-17+6*follow,70+4*follow];
      B=far?[26,108]:[-7+19*follow-3*rise,95+19*follow-2*rise];
      C=far?[22,132]:[16+24*follow-4.2*still,115+24*follow+1.7*still];
      gesture=far?'stand':'point';
    } else if(p==='invite'){
      const anticip=ease(.03,.27,t)-ease(.28,.54,t);
      const offer=ease(.35,.99,t), rest=ease(2.23,3.27,t)*.70;
      const pat=.85*(ease(1.03,1.42,t)-ease(1.45,1.64,t))+.62*(ease(1.65,1.94,t)-ease(1.96,2.17,t));
      if(!far) A=[-12+10*offer,69];
      B=far?[27,108]:[-8+33*(offer-rest)-5*anticip,104+9*offer-14*pat];
      C=far?[32,132]:[19+46*(offer-rest)-8*anticip,132+7*offer-18*pat];
      gesture=far?'stand':'pat';
    } else if(p==='present'){
      const show=ease(.10,.88,t), tap=.92*(ease(1.04,1.38,t)-ease(1.39,1.52,t))+.64*(ease(1.62,2.0,t)-ease(2.0,2.14,t));
      B=far?[23,100]:[-4+27*show,97-8*show-4*tap];
      C=far?[24,119]:[10+55*show,112-20*show-6*tap];
      gesture=far?'stand':'point';
    } else if(p==='fix'){
      B=far?[28,92]:[-4,104];
      C=far?[48,86+sway*1.7]:[56+effort*3.5,94+beat*1.18-2.4*effort+1.15*turn];
      if(far)gesture='stand'; // offhand steadies the housing, only one screwdriver
    } else if(p==='point'){
      B=far?[25,95]:[14+4*reach,88-2*reach];
      C=far?[27,109]:[54+8*reach,89-5*reach+sway*1.3];
      if(far)gesture='stand';
    } else if(p==='open'){
      B=far?[31,84]:[8,91];
      C=far?[53+7*reach,77-5*reach+beat*1.4]:[36+5*reach,95-4*reach+sway*2.1];
      gesture='open';
    } else if(p==='walk'){
      const step=gait(t,far?0:1)[0]*64;
      B=far?[22-step*.6,95]:[-19-step*.6,99];
      C=far?[22-step,120]:[-16-step,128-2*Math.abs(step/9)];gesture='stand';
    } else if(p==='sit'||p==='sitDown'){
      const a=p==='sitDown'?ease(.09,.47,t):1;
      B=far?[24+3*a,98+6*a]:[-18+9*a,99+5*a];
      C=far?[22+16*a,120+13*a]:[-16+39*a,127+8*a+sway*.7];gesture='stand';
    } else {
      B=far?[24,97]:[-19,99];
      C=far?[22,120]:[-16+sway*.8,129];gesture='stand';
    }
    const cuff=k==='teen' && (p==='fix'||p==='open')?.63:.83;
    const T=[B[0]+(C[0]-B[0])*cuff,B[1]+(C[1]-B[1])*cuff];
    const ribbon=far?s.shadow:s.shirt;
    if(cuff<.75){
      limb(c,B,[.44*B[0]+.56*C[0],.44*B[1]+.56*C[1]],C,4.3*size,3.8*size,2.75*size,far?s.shade:s.skin);
      limb(c,A,B,T,8.5,5,4.7,ribbon);
    } else {
      limb(c,B,[.44*B[0]+.56*C[0],.44*B[1]+.56*C[1]],C,4.8*size,4*size,2.8*size,s.skin);
      limb(c,A,B,T,9.05*size,6*size,4.25*size,ribbon);
    }
    const a=Math.atan2(C[1]-B[1],C[0]-B[0]);
    c.save();c.translate(...T);c.rotate(a);
    patch(c,'M -5 -4.5 L 1 -4 Q 3 -1 1 4 L -5 5Z',far?s.shadow:s.cuff,ink,.73);
    patch(c,'M -3 -4 L -3 4',null,s.shadow,.64);
    if(k!=='teen') oval(c,-1.3,2.05,.68,.76,s.shade);
    c.restore();
    if(!far){
      line(c,A[0]+.6,A[1]+3,(A[0]+B[0])*.5+2,(A[1]+B[1])*.5+2,s.cuff,.55);
      line(c,B[0]+1,B[1]-2,B[0]+(T[0]-B[0])*.32,B[1]+(T[1]-B[1])*.32-1.5,s.shadow,.62);
    }
    const handAngle=gesture==='pat'?.09+a*.23:a+(gesture==='point'?-.065:gesture==='fix'?sway*.05+turn*.14:0);
    if(pin){
      c.save();c.translate(...C);c.rotate(handAngle);
      pin(far?'farHand':'nearHand',3,0,c.getTransform());
      if(!far && gesture==='fix' && k==='teen')pin('toolTip',23,-23,c.getTransform());
      if(!far && gesture==='point')pin('indexTip',17,-3,c.getTransform());
      if(!far && gesture==='pat')pin('patContact',16.5,1.55,c.getTransform());
      c.restore();
    }
    palm(c,C[0],C[1],handAngle,s,gesture,k);
  }
  // Optional ninth arg: write exact draw-space hand anchors before drawing registered props.
  // Tenth arg is an optional cel palette grade; eleventh 'nearArm' repaints only
  // the arm if a desk or foreground prop needs to sit between actor and fingers.
  window.person=function(c,x,y,height,kind='teen',pose='stand',time=0,facing=1,anchors=null,grade='',pass='all'){
    if(!Object.hasOwn(S,kind))kind='teen';
    const key=Object.hasOwn(schemeAlias,grade)?schemeAlias[grade]:grade;
    const s=Object.hasOwn(grades,key)?grades[key][kind]:S[kind];
    const lamp=Object.hasOwn(edgeLight,grade)?edgeLight[grade]:null;
    const light=lamp?{color:lamp[0],strength:lamp[1],side:lamp[2]*(facing<0?-1:1)}:null;
    if(!Number.isFinite(height)||height<=0)return;
    const h=height/200,t=Number.isFinite(time)?Math.max(0,time):0,bob=sin(t*2.1+(kind==='mum'?1.4:0))*.51;
    if(!['fix','stand','point','sit','open','smile','listen','study','invite','present','walk','sitDown'].includes(pose))pose='stand';
    const seated=pose==='sit'||pose==='invite'?1:pose==='sitDown'?ease(.012,.5,t):0;
    const settle=ease(.19,1.16,t), offer=ease(.26,1.0,t)-.62*ease(2.67,3.28,t);
    const walking=pose==='walk'?walkStrength(t):0;
    const stepLift=-Math.abs(sin(t*1.12*pi*2))*2.6*walking;
    const trim=kind==='mum'?18:kind==='grandpa'?15:14;
    const sx=kind==='teen'?.87:kind==='mum'?.91:.97;
    const hs=kind==='teen'?.738:kind==='mum'?.66:.716;
    let pin;
    if(anchors&&typeof anchors==='object'){
      const base=c.getTransform().inverse();
      pin=(name,px,py,model)=>{
        const point=new DOMPoint(px,py).matrixTransform(model).matrixTransform(base);
        anchors[name]={x:point.x,y:point.y};
      };
    }
    c.save();c.translate(x,y-height);c.scale(h*(facing<0?-1:1),h);
    c.lineJoin='round';c.lineCap='round';
    const isolate=pass==='nearArm';
    if(!isolate)pants(c,s,kind,pose,t);
    const study=pose==='study'?1:0, reading=study*(ease(.08,.92,t)-.42*ease(1.4,2.2,t));
    const sideShift=pose==='listen'?-4.9*settle:pose==='invite'?2.8*offer:pose==='sitDown'?-3.8*seated:pose==='open'?2.1:0;
    c.save(); c.translate(sideShift+4.1*reading,bob-trim+10*seated+stepLift+2.1*reading); c.translate(0,126);
    const lean=pose==='fix'?.18+.032*sin(t*1.8):pose==='point'?.073:pose==='open'?.065:pose==='sit'?.048:pose==='invite'?.052+.108*offer:pose==='listen'?.095-.143*settle:pose==='study'?.072+.118*reading:pose==='present'?.035+.052*settle:pose==='walk'?.047+walking*(.046+sin(t*pi*2.24)*.012):pose==='sitDown'?.06+sin(seated*pi)*.19:kind==='teen'?-.018:0;
    c.rotate(lean);
    c.translate(0,-126);
    if(!isolate){
      c.save();c.scale(sx,1);
      if(pose==='fix'||pose==='point'||pose==='present')c.translate(0,3);
      arms(c,s,kind,pose,t,true,pin);c.restore();
      c.save();c.scale(sx,1);
      coat(c,s,kind);
      rim(c,light,'M -16 59 Q -23 62 -24 69 M -21 102 L -22 120','M 11 57 Q 19 60 22 67 M 19 103 L 20 126',.57,.95);
      c.restore();
      c.save();c.translate(0,52*(1-hs));c.scale(hs*1.045,hs);
      head(c,s,kind,pose,t,light);c.restore();
    }
    c.save();c.scale(sx,1);
    if(pose==='fix'||pose==='point'||pose==='present')c.translate(0,3);
    arms(c,s,kind,pose,t,false,pin);c.restore();
    c.restore();c.restore();
  };
})();

