// Close-lens backgrounds, angled shop-window light and the tactile map table.
(() => {
const {path:P,line:L,ell:E,grad:G,radial:D,rr:RR,text:T,R,TAU,clamp,ease}=Art;
let focus=new Map(),tables=new Map();
window.softShop=(g,w,h,t,mode='bench',amount=12,zoom=1.12)=>{
 let key=[w,h,mode,amount,zoom].join('/'),c=focus.get(key);
 if(!c){c=document.createElement('canvas');const k=.48;c.width=Math.round(w*k);c.height=Math.round(h*k);let q=c.getContext('2d');q.save();q.translate(c.width*.46,c.height*.44);q.scale(zoom,zoom);q.translate(-c.width*.46,-c.height*.44);shop(q,c.width,c.height,0,mode);q.restore();
 let src=document.createElement('canvas');src.width=c.width;src.height=c.height;let sc=src.getContext('2d');sc.filter='blur('+Math.max(1,amount*k)+'px)';sc.drawImage(c,-4,-4,c.width+8,c.height+8);c=src;focus.set(key,c)}
 g.drawImage(c,0,0,w,h);
 // Rounded defocus from real world light sources: a few faint beads, not glitter.
 let pt=h>w,seed=R(757);for(let i=0;i<14;i++){let x=w*(.08+.38*seed()),y=h*(.20+.44*seed()),r=(.004+.015*seed())*h,lum=seed();
 g.fillStyle=D(g,x,y,r*.40,r,[[0,'rgba(244,214,153,'+(.035+lum*.04)+')'],[.75,'rgba(244,214,153,'+(.04+lum*.045)+')'],[1,'rgba(255,225,170,0)']]);g.fillRect(x-r,y-r,2*r,2*r)}
};
window.slattedLight=(g,w,h,t,opt={})=>{
 let a=opt.alpha??.14,s=opt.slant??-.35,shift=w*(.017*Math.sin(t*.37)),start=opt.x??.42;g.save();g.globalCompositeOperation='multiply';
 for(let i=0;i<4;i++){let x=w*(start+.116*i)+shift,wd=w*(i===1?.025:.012);P(g,'M '+x+' 0 L '+(x+wd)+' 0 '+(x+wd+w*s)+' '+h+' '+(x+w*s)+' '+h+' Z','rgba(64,83,103,'+a+')')}
 g.restore()
};
window.tabletop=(g,w,h,t)=>{
 let key=w+'/'+h,c=tables.get(key);
 if(!c){c=document.createElement('canvas');c.width=w;c.height=h;let q=c.getContext('2d'),rng=R(202402),s=Math.min(w,h)/760;
 q.fillStyle=G(q,0,0,w,h,[[0,'#b89a79'],[.37,'#94715f'],[.67,'#795b50'],[1,'#5c4847']]);q.fillRect(0,0,w,h);
 q.save();q.translate(w*.5,h*.5);q.rotate(-.07);q.translate(-w*.5,-h*.5);
 for(let j=-1;j<=10;j++){let yy=j*h*.145+h*.036,hh=h*.145;q.fillStyle=['rgba(222,188,139,.09)','rgba(69,53,52,.08)','rgba(211,161,119,.08)'][(j+3)%3];q.fillRect(-.14*w,yy,1.28*w,hh);L(q,[[-w*.10,yy],[w*1.11,yy]],'rgba(72,48,43,.66)',2.4*s);L(q,[[-w*.10,yy+2*s],[w*1.1,yy+2*s]],'rgba(221,176,132,.56)',1.35*s);
 for(let j=0;j<34;j++){let y=yy+rng()*hh,x=-.12*w+rng()*w*1.3,len=w*(.06+.28*rng()),bend=(rng()-.5)*5*s;P(q,'M '+x+' '+y+' q '+(len*.41)+' '+bend+' '+len+' '+(bend*.25),null,rng()>.59?'rgba(221,178,133,.20)':'rgba(76,52,43,.18)',(.5+rng()*.7)*s)}}
 q.restore();tables.set(key,c)}
 g.drawImage(c,0,0);g.save();g.fillStyle=D(g,w*.12,h*.08,0,w*.99,[[0,'rgba(252,211,157,.22)'],[.54,'rgba(239,190,128,.08)'],[1,'rgba(119,95,80,0)']]);g.fillRect(0,0,w,h);g.restore()
};
window.coolingSign=(g,w,h,t)=>{
 const p=h>w,u=Math.min(w/1000,h/700),xx=w*(p?.098:.093),yy=h*.73,sw=w*(p?.133:.100),sh=sw*(p?1.27:1.11);
 g.save();g.translate(xx,yy);g.rotate(-.065);g.shadowColor='rgba(35,39,39,.20)';g.shadowBlur=4*u;g.shadowOffsetX=3*u;
 P(g,'M 0 '+(-sh)+' L '+sw+' '+(-sh)+' '+(sw+2*u)+' 0 '+(-u*2)+' '+(4*u)+' Z','#ad8868','#5c5350',2.2*u);g.shadowColor='transparent';RR(g,5*u,-sh+5*u,sw-10*u,sh-11*u,1*u,'#426062','#d2aa7b',u);
 g.save();g.translate(sw*.5,-sh*.59);T(g,'涼み処',0,0,Math.min(sw*.275,sh*.34),'#eee0b7','Noto Serif CJK JP',650,'center');g.restore();
 L(g,[[sw*.12,-sh*.44],[sw*.88,-sh*.44]],'#baab86',1*u);
 T(g,'COOLING',sw*.50,-sh*.30,sw*.106,'#e9d7b4','Noto Sans',650,'center');T(g,'ROOM',sw*.50,-sh*.16,sw*.106,'#e9d7b4','Noto Sans',650,'center');g.restore()
};
window.windBellLight=(g,w,h,t)=>{const q=(Math.sin(t*1.7)*.5+.5)**7;E(g,w*.886,h*.105,3+5*q,.6+q,'rgba(255,231,177,'+(.2+.4*q)+')')};
})();
