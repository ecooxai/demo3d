/* THE EMPTY STOP | Curbside insert, original vector paint and time-keyed motion.
   Time is shot local, normalized to a 0.97s editorial hold. This file has no assets. */
(() => {
'use strict';
const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x)), mix=(a,b,t)=>a+(b-a)*t;
const s=(a,b,t)=>{let q=clamp((t-a)/(b-a));return q*q*(3-2*q);};
const palette={ink:'#3b414e',mid:'#69605e', gold:'#efc483', skin:'#d3a383'};
const R=(seed)=>{let u=seed>>>0;return()=>((u=(Math.imul(u,1664525)+1013904223)>>>0)/4294967296);};
function p(g,xy,col,ed=null,k=1){g.beginPath();g.moveTo(xy[0],xy[1]);for(let i=2;i<xy.length;i+=2)g.lineTo(xy[i],xy[i+1]);g.closePath();if(col){g.fillStyle=col;g.fill();}if(ed){g.strokeStyle=ed;g.lineWidth=k;g.stroke();}}
function d(g,p,col,ed=null,k=1){let q=new Path2D(p);if(col){g.fillStyle=col;g.fill(q);}if(ed){g.strokeStyle=ed;g.lineWidth=k;g.stroke(q);}return q;}
function l(g,xy,ed,k=1){g.beginPath();g.moveTo(xy[0],xy[1]);for(let i=2;i<xy.length;i+=2)g.lineTo(xy[i],xy[i+1]);g.strokeStyle=ed;g.lineWidth=k;g.stroke();}
function e(g,x,y,rx,ry,f,ed=null,k=1,ang=0){g.beginPath();g.ellipse(x,y,rx,ry,ang,0,Math.PI*2);if(f){g.fillStyle=f;g.fill();}if(ed){g.strokeStyle=ed;g.lineWidth=k;g.stroke();}}
function rect(g,x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h);}
function grad(g,x,y,x1,y1,p){const a=g.createLinearGradient(x,y,x1,y1);for(let [u,c] of p)a.addColorStop(u,c);return a;}
function rad(g,x,y,r,p){let a=g.createRadialGradient(x,y,0,x,y,r);for(let [u,c] of p)a.addColorStop(u,c);return a;}
function text(g,str,x,y,sz,color){g.fillStyle=color;g.font='700 '+sz+'px sans-serif';g.textBaseline='middle';g.fillText(str,x,y);}
function road(g,W){
 rect(g,-W,-20,2*W,785,grad(g,0,330,0,720,[[0,'#797387'],[.46,'#827782'],[1,'#55596e']]));
 p(g,[-W,665,W,451,W,765,-W,765],grad(g,0,480,0,720,[[0,'#a69494'],[.48,'#7f7886'],[1,'#656474']]));
 l(g,[-W,665,W,451],'#485261',4.7);l(g,[-W,671,W,457],'#c6aa91',2.0);
 // Raking residual dusk light on the stone lip, sharply interrupted at the curb cut.
 const x0=-W*.80,x1=W*.98;
 p(g,[x0,721,x1,528,x1,544,x0,738],grad(g,x0,660,x1,525,[[0,'#af999400'],[.43,'#bfa09552'],[1,'#ecc39c37']]));
 for(let j=0;j<10;j++){let x=-W*.86+j*W*.212,y=613-x*.104;l(g,[x,y,x+56,732],'#4e58674c',1.05);l(g,[x+2,y+1,x+58,732],'#b7a39b37',.78);}
 // Painted lip and the shadow of the shelter post, grounded in the street scene.
 p(g,[-W,650,-W,749,64,749,-90,602,-173,612],grad(g,-302,622,207,696,[[0,'#333f555e'],[1,'#353c5050']]));
 const r=R(4219);for(let i=0;i<1100;i++){let x=(r()*2-1)*W,y=469+r()*270;rect(g,x,y,.5+r()*2.8,.38+r()*.9,i%3?'#3443531b':'#ffe4be32');}
}
function busBody(g,W){
 const ik=palette.ink;
 // Three visual planes: near-side enamel at left, thin front plane to the right, and the curb reflected underneath.
 let body=grad(g,-W,50,220,560,[[0,'#bbb0a0'],[.29,'#dec7a5'],[.69,'#e0c7a1'],[1,'#a39591']]);
 p(g,[-W,-49,168,-67,321,-52,388,14,433,335,395,460,216,518,-W,619],body,ik,3.5);
 p(g,[303,-51,357,-22,415,33,449,340,434,427,395,460,406,355,365,10],'#ab9990',ik,2.1);
 // Above the door, the windows are translucent grey-blue; warm reflected cloud bands run across.
 p(g,[-W,19,-112,-38,-93,-15,-88,188,-W,244],grad(g,0,24,0,260,[[0,'#516578'],[.35,'#627e86'],[.53,'#899893'],[.55,'#667c83'],[1,'#4b6472']]),ik,4);
 l(g,[-W,186,-87,143],'#526a75',3.5);l(g,[-W,191,-87,146],'#adb7a6',1.1);
 for(let i=0;i<6;i++){let x=-118-i*175,y=-28+i*8.6;p(g,[x-5,y,x+8,y-.9,x+12,y+226,x,y+230],'#a6a89c',ik,1.14);l(g,[x+5,y+3,x+9,y+227],'#c1b9a2',1.0);
 if(i<5){p(g,[x-17,y+3,x+2,y+1,x-115,y+207,x-135,y+208],'#d9bfa92b');p(g,[x-69,y+10,x-57,y+7,x-153,y+190,x-170,y+192],'#c7aeb328');}}
 p(g,[139,-20,324,3,393,76,420,185,211,228,138,221],grad(g,130,-20,323,226,[[0,'#5b6f83'],[.37,'#748c91'],[.73,'#5c7080'],[1,'#435967']]),ik,3.9);
 p(g,[146,12,248,15,153,181,141,190],'#c4b5a34a');p(g,[266,23,283,27,200,174,183,175],'#efc9a135');
 l(g,[154,216,217,213,348,185,415,168],'#384b59',3.6);
 // Wiper and glint are credible because they attach to deck under the front glass.
 l(g,[273,195,321,118,361,113],'#46515e',3.1);l(g,[322,118,370,109],'#b3a69a',1.2);
 // Terracotta band with narrow cream inset, the same asymmetric teal flourish as the earlier coach.
 p(g,[-W,293,142,226,419,184,423,235,143,278,-W,350],grad(g,0,210,0,350,[[0,'#af7968'],[.66,'#a87568'],[1,'#916663']]),'#88675f',1.05);
 l(g,[-W,296,141,230,418,189],'#ebd4ac',3.1);l(g,[-W,302,141,235,414,193],'#c99d80',.88);
 p(g,[-W,391,-301,355,-259,311,-147,301,-232,392,-W,424],grad(g,0,292,0,419,[[0,'#69908a'],[1,'#64847c']]));
 l(g,[-W,393,-301,358,-262,316,-148,305],'#a6ad92',1.13);
 // Gray reveals along engine panel; soft reflections of stop fixtures and the underside of the step.
 p(g,[-W,537,-101,501,41,480,304,458,418,430,399,461,216,522,-W,625],grad(g,0,465,0,625,[[0,'#6b7077'],[.43,'#96908d'],[1,'#5a626c']]),ik,2.2);
 l(g,[-W,545,-111,513,302,466,417,436],'#c9b7a1',2.05);
 p(g,[-255,394,-153,378,-150,481,-262,497],'#b7a78e','#8e8479',1.04);l(g,[-242,406,-222,402,-219,408,-241,411],'#7a746e',1.35);
 p(g,[171,360,248,345,251,400,172,413],'#baae97','#93877d',1.05);l(g,[181,354,244,342],'#ead0a7',1.45);
 // Only the edge of the front wheel is left in this tight lens; arc aligns to livery and curb.
 g.save();g.translate(266,487);g.scale(.95,.83);
 e(g,0,0,72,75,'#5a5f66',ik,2.4);e(g,0,0,55,57,'#445561');e(g,0,0,41,43,'#80908a',ik,1.4);e(g,0,0,29,30,'#aca592','#66756f',1.7);
 for(let i=0;i<8;i++){let a=i*.785;e(g,18*Math.cos(a),19*Math.sin(a),2.7,2.7,'#57686a','#a59e8d',.65);}e(g,0,0,10,11,'#697979','#b8ae98',1.3);
 g.restore();
 d(g,'M 194 491 C 191 455 217 422 262 413 C 303 406 325 434 329 463',null,'#c2b09b',3.5);
 d(g,'M 190 493 C 184 452 217 419 262 410 C 303 404 332 431 332 465',null,ik,1.3);
 // Pinhole textures and naturally scuffed paint. Keep the main value areas clean.
 let r=R(9577);for(let i=0;i<720;i++){let x=-W+r()*(W+391),y=235+r()*297;if(x>-117&&x<150&&y>102)continue;rect(g,x,y,.25+r()*2.35,.31+r()*.8,(i%3?'#e6d2b11c':'#5f596031'));}
 text(g,'07',158,303,16,'#68615e');e(g,-182,279,12,12,'#e6c19b');l(g,[-193,277,-171,275,-172,279,-191,281],'#b48870',1.1);l(g,[-191,283,-174,282],'#b48870',1.0);
}
function jamb(g,W,t,glass=false){
 let ik='#3c404d',open=s(0,.205,t),jpL=-107,jpR=131;
 if(!glass){
  d(g,'M -121 95 Q -120 63 -98 58 L 108 44 Q 131 43 132 65 L 144 475 Q 137 491 130 499 L -112 530 Q -123 528 -124 508 Z','#846d69',ik,3.0);
  d(g,'M -111 90 Q -110 70 -93 69 L 108 55 Q 121 54 122 71 L 132 470 L 124 482 L -108 512 Z',grad(g,5,80,13,528,[[0,'#785450'],[.20,'#af755a'],[.45,'#a06b56'],[.71,'#795356'],[1,'#957062']]),ik,2.8);
  g.save();let aperture=new Path2D('M -108 95 Q -109 73 -93 71 L 107 57 Q 119 55 120 71 L 132 474 L 122 481 L -108 510 Z');g.clip(aperture);
  // Inside: warm luminous ceiling, deep bronze left reveal, amber handrail and blue cloth seat end.
  p(g,[-109,54,122,46,97,120,-109,137],grad(g,0,54,0,137,[[0,'#9f725f'],[.54,'#c99468'],[1,'#d8a873']]));
  p(g,[-109,104,-69,134,-62,407,-104,455],grad(g,-110,137,-58,411,[[0,'#b88465'],[.43,'#d6a676'],[1,'#aa7e66']]),'#996e63',1.0);
  p(g,[77,109,123,79,133,471,85,399],grad(g,94,120,121,472,[[0,'#9e7060'],[.49,'#7d5a58'],[1,'#6c575d']]),'#694e58',1.1);
  p(g,[-65,142,78,126,79,352,-62,369],grad(g,-12,138,27,378,[[0,'#c2956a'],[.30,'#a36f5a'],[.68,'#845b57'],[1,'#846661']]));
  p(g,[-59,170,39,160,42,275,-56,291],grad(g,-40,165,-15,290,[[0,'#c5aa86'],[.42,'#ccaf82'],[.45,'#a8927f'],[1,'#8f8479']]),'#805f5c',1.8);
  p(g,[-58,171,14,165,-37,240,-56,242],'#e0be8e63');
  l(g,[-53,214,40,202],'#8d776b',1.3);
  p(g,[29,298,65,290,69,358,27,360],grad(g,28,292,64,365,[[0,'#718580'],[.68,'#536e78'],[1,'#585f6c']]),'#5e565b',1.6);
  l(g,[34,307,63,301],'#96a090',1.05);
  p(g,[-29,326,78,309,78,389,-21,399],grad(g,0,323,22,400,[[0,'#9a7771'],[.55,'#806264'],[1,'#715963']]),'#765660',1.24);
  l(g,[-26,334,74,318],'#abb592',1.35);
  // Ceiling strip and gradient shadows radiate downward without flattening the doorway.
  p(g,[-65,94,58,81,75,92,-56,104],'#f8d898','#d0a775',1.0);
  p(g,[-51,95,60,84,65,88,-51,100],'#fff2c8');
  rect(g,-130,45,274,505,rad(g,-3,107,282,[[0,'#ffe0a467'],[.29,'#ffd19a40'],[.79,'#efad7212'],[1,'#f3ba8000']]));
  // Handrail: two sides maintain clear silhouettes at the toe-crossing moment.
  d(g,'M -81 141 Q -78 125 -67 125 L -44 122 Q -37 123 -36 132 L -30 322 C -30 345 -37 366 -49 374',null,'#70505a',8);
  d(g,'M -80 140 Q -76 127 -67 127 L -43 123 Q -39 124 -38 133 L -31 322 Q -30 349 -50 374',null,'#d9a875',4.8);
  d(g,'M -80 140 Q -77 128 -66 127 L -44 124 Q -39 125 -38 134 L -32 317',null,'#f8d09c',1.54);
  d(g,'M 101 166 L 102 339 Q 101 366 93 379 L 86 391',null,'#4c4b56',8);
  d(g,'M 101 166 L 102 338 Q 101 365 93 378 L 86 391',null,'#ddb086',4.1);
  for(let j=0;j<3;j++){e(g,-41,127+j*85,2.5,3,'#ffe2b5','#71626a',.6);}
  g.restore();
 } else {
  // Scale of each active leaf shrinks as it stacks against its jamb, exposing the real opening.
  const lw=mix(115,15,open),rw=mix(110,18,open);
  const l0=-111,l1=l0+lw,r0=125,r1=r0-rw;
  const glassCol=grad(g,0,120,0,430,[[0,'#577384'],[.28,'#95988f'],[.55,'#788682'],[.83,'#5e7277'],[1,'#718581']]);
  p(g,[l0,92,l1,85,l1,490,l0,508],'#465762',ik,2.8);
  p(g,[l0+4,100,l1-3,93,l1-3,362,l0+4,378],glassCol,'#253f52',1.48);
  p(g,[l0+5,382,l1-3,365,l1-3,486,l0+5,501],grad(g,0,355,0,503,[[0,'#a79c86'],[1,'#8d8b82']]),ik,1.17);
  p(g,[r1,82,r0,69,r0+5,465,r1+3,490],'#465762',ik,2.8);
  p(g,[r1+4,88,r0-4,77,r0+1,345,r1+5,359],glassCol,'#2e4453',1.46);
  p(g,[r1+5,363,r0+1,349,r0+2,459,r1+6,482],grad(g,0,350,0,486,[[0,'#aaa18a'],[1,'#8b8980']]),ik,1.18);
  if(open<.75){
    p(g,[l0+6,104,l1-5,97,l1-5,108,l0+6,243],'#edccac3b');
    p(g,[r1+6,91,r0-6,82,r0-6,91,r1+6,156],'#edccac38');
  }
  l(g,[l1-1,100,l1-1,481],'#b9b19a',.8);l(g,[r1+1,87,r1+3,481],'#bbac96',.8);
  e(g,l0+Math.min(8,lw*.35),500,2.5,2.8,'#e0c499',ik,.55);
 }
}
function steps(g,t){
 const open=s(0,.205,t),ik='#4c4751';
 // Lower nose, top landing, and two staggered treads. Warm top surfaces have crisp riser edges.
 p(g,[-111,414,110,386,122,416,-120,447],grad(g,0,380,15,450,[[0,'#785d61'],[1,'#bb8f71']]),ik,1.75);
 p(g,[-120,447,122,416,123,433,-120,464],grad(g,0,418,0,460,[[0,'#594d59'],[1,'#785b60']]),ik,1.2);
 p(g,[-120,464,123,433,134,460,-128,494],grad(g,0,425,3,497,[[0,'#bc9175'],[.38,'#c29c7b'],[1,'#d7aa80']]),ik,1.25);
 p(g,[-128,494,134,460,134,477,-128,511],grad(g,0,456,0,510,[[0,'#69565b'],[.37,'#725c5d'],[1,'#735e63']]),ik,1.2);
 p(g,[-128,511,134,477,151,505,-136,542],grad(g,-18,473,25,546,[[0,'#cda67c'],[.45,'#dcb588'],[1,'#efa96f']]),ik,1.36);
 p(g,[-136,542,151,505,148,516,-137,551],grad(g,0,502,0,554,[[0,'#7b6964'],[1,'#554e5a']]),ik,1.25);
 p(g,[-139,550,149,514,150,519,-141,556],'#bb9b81',ik,.95);
 l(g,[-128,493,132,460],'#f5d8a6',1.75);l(g,[-134,540,147,504],'#fff0bc',2.45);l(g,[-139,547,149,513],'#a49486',1.26);
 // Fine inset ribs in the walking treads. Random micro-paint wear is locked to the geometry.
 for(let j=0;j<5;j++){let b=j*3.4;l(g,[-120+b*.18,519+b,140+b*.35,486+b],'#745e626a',.98);l(g,[-113+b*.11,474+b,126+b*.23,443+b],'#7d645f71',.86);}
 for(let j=0;j<12;j++){let f=j/11,xx=-127+(260*f),yy=537+(503-537)*f;l(g,[xx,yy,xx+4,yy-.48],'#fdf0bd79',.66);}
 e(g,-130,543,2.8,1.44,'#5a5963','#f3d9a9',.54);e(g,136,512,2.8,1.45,'#5a5963','#f3d9a9',.54);
 if(open>.05){
 let g1=grad(g,0,489,17,633,[[0,'#fdd69b65'],[.48,'#f6c88b41'],[.91,'#f4c58708'],[1,'#f4c58700']]);
 g.save();g.globalAlpha=open;p(g,[-137,552,149,516,199,628,-201,666],g1);g.restore();}
}
function knee(H,A,len1,len2,sign){
 let dx=A.x-H.x,dy=A.y-H.y,v=Math.max(.01,Math.hypot(dx,dy)),dist=Math.min(v,len1+len2-.025),a=(len1*len1-len2*len2+dist*dist)/(2*dist),b=Math.sqrt(Math.max(0,len1*len1-a*a));
 return {x:H.x+dx/v*a+sign*dy/v*b,y:H.y+dy/v*a-sign*dx/v*b};
}
function cloth(g,hip,K,A,near,hit){
 const ink=palette.ink;
 const a=near?28:24,b=near?25:22,c=near?15:13;
 let clothGrad=grad(g,hip.x-19,hip.y,hip.x+56,K.y,[[0,near?'#627771':'#526268'],[.55,near?'#677c74':'#586a6c'],[1,near?'#54686b':'#4b5c65']]);
 let cut='M '+(hip.x-a)+' '+(hip.y-7)+' Q '+(hip.x-a-8)+' '+(hip.y+48)+' '+(K.x-b)+' '+(K.y-26)+' C '+(K.x-b-4)+' '+(K.y-7)+' '+(K.x-b-4)+' '+(K.y+12)+' '+(K.x-b)+' '+(K.y+24)+' L '+(A.x-c)+' '+(A.y-11)+' Q '+A.x+' '+(A.y-6)+' '+(A.x+c)+' '+(A.y-11)+' Q '+(A.x+c-2)+' '+(A.y-57)+' '+(K.x+b)+' '+(K.y+14)+' C '+(K.x+b+6)+' '+(K.y-4)+' '+(K.x+b+2)+' '+(K.y-18)+' '+(K.x+b-2)+' '+(K.y-33)+' Q '+(hip.x+a+4)+' '+(hip.y+11)+' '+(hip.x+a-1)+' '+(hip.y-10)+' Z';
 d(g,cut,clothGrad,ink,near?1.8:1.52);
 let crease='M '+(hip.x-a+8)+' '+(hip.y+5)+' Q '+(hip.x-a+14)+' '+(hip.y+44)+' '+(K.x-b*.61)+' '+(K.y-15)+' Q '+(K.x-b*.51)+' '+(K.y+4)+' '+(K.x-b*.69)+' '+(K.y+13)+' L '+(A.x-c+4)+' '+(A.y-16);
 d(g,crease,null,near?'#a4a98d':'#748c83',near?1.27:1.0);
 d(g,'M '+(K.x-15)+' '+(K.y+10+2*hit)+' Q '+(K.x+1)+' '+(K.y+14+3*hit)+' '+(K.x+19)+' '+(K.y+4+3*hit),null,near?'#4d6269':'#485a64',1.15);
 d(g,'M '+(A.x-c+1)+' '+(A.y-15)+' Q '+A.x+' '+(A.y-9)+' '+(A.x+c-2)+' '+(A.y-15),null,near?'#99a38d':'#708781',1.05);
}
function boot(g,x,y,angle,near,hit){
 g.save();g.translate(x,y);g.rotate(angle);
 const light=near?'#bd9281':'#968080',shade=near?'#775f65':'#665960',ink='#454553';
 p(g,[-13,-15,11,-16,15,-9,14,-3,-13,-4],near?'#bac19f':'#9ea58e',ink,1.15);
 let path='M -15 -7 C -9 -10 7 -10 14 -7 Q 17 -4 19 0 Q 24 4 37 5 C '+(47-1.1*hit)+' 4 '+(51-1.5*hit)+' '+(10-1.8*hit)+' '+(49-2.5*hit)+' 14 C 37 17 -11 21 -18 15 Q -20 10 -18 3 Z';
 d(g,path,grad(g,0,-14,22,20,[[0,light],[.54,near?'#987264':'#836a69'],[1,shade]]),ink,1.7);
 d(g,'M -18 13 C -6 16 35 12 48 11 L 49 16 C 37 19 -7 22 -18 17 Z',near?'#7a6263':'#665961',ink,1.05);
 d(g,'M 17 0 Q 28 1 33 7 M 9 -6 Q 9 -2 11 4 M -13 -6 Q -12 1 -12 9',null,near?'#d4a18c':'#9c8280',.95);
 d(g,'M 22 4 Q 29 3 32 7 M 19 2 L 24 3 M -14 14 Q 0 17 12 15 L 46 12',null,near?'#d7ac90':'#ab9283',.88);
 g.restore();
}
function bag(g,x,y,a,W){
 g.save();g.translate(x,y);g.rotate(a);
 const ink='#48535d';
 // Worn dusty teal tote with a sand-colored folded ticket; heavy rim and seam.
 d(g,'M -22 -28 C -25 -50 -18 -82 -7 -86 C 5 -91 15 -68 19 -43 L 16 -28 L 10 -28 C 10 -45 3 -77 -6 -79 C -12 -79 -16 -49 -16 -22 Z','#a19684',ink,1.2);
 d(g,'M -11 -38 L 12 -82 L 44 -74 L 44 -26 Z','#ddd0a8','#73695f',1.03);
 l(g,[14,-67,19,-62,38,-57],'#9b8f76',.85);l(g,[9,-61,16,-55,35,-52],'#a39070',.8);l(g,[7,-55,13,-50,31,-47],'#bb9e7e',.8);
 d(g,'M -45 -40 C -28 -30 16 -30 43 -43 L 50 45 Q 48 55 38 60 C 10 68 -32 63 -43 54 L -49 15 Z',grad(g,-41,-42,29,61,[[0,'#8d9a8d'],[.46,'#7a9087'],[1,'#657a7d']]),ink,1.85);
 d(g,'M 41 -41 L 52 -43 L 60 46 L 49 52 L 42 26 Z','#5c747b',ink,1.0);
 d(g,'M -43 -35 Q -14 -24 43 -38 M -42 52 C -27 59 13 63 38 55 M -36 -31 L -33 55',null,'#b4ad8d',1.34);
 p(g,[-23,23,-13,13,2,22,3,35,-22,38],'#b5a081','#788778',.80);
 for(let j=0;j<28;j++){let u=(j*2)%55,yy=-20+j*2.58;l(g,[-29+u*.74,yy,-24+u*.74,yy-.38],j%4?'#70877c55':'#cbb79747',.71);}
 g.restore();
}
function rider(g,W,t){
 const ink=palette.ink,step=s(.19,.724,t),swing=s(.22,.69,t),push=s(.18,.58,t);
 const load=s(.679,.96,t),hit=s(.685,.748,t)*(1-s(.752,.945,t)),follow=s(.743,.963,t);
 const clothLag=s(.704,.785,t)*(1-s(.788,.967,t));
 // At the same .69s shoe lock, the forward knee accepts weight: the pelvis goes over the foot,
 // dips once into compression, then rises. The rear toe remains a fixed pivot throughout.
 const hip={x:-232+77*step+62*load,y:370-21*step+14.8*hit-22*follow};
 const A={x:-173+119*swing,y:598-84*swing-50*Math.sin(Math.PI*swing)};
 const footA=-(.14*Math.sin(Math.PI*swing))+.035*s(.65,.69,t)-.125*s(.69,.765,t);
 const farA=.04+.47*push-.22*s(.78,.97,t);
 const far={x:-179-(47*Math.cos(farA)-15*Math.sin(farA)),y:623-(47*Math.sin(farA)+15*Math.cos(farA))};
 let Q={x:hip.x-15,y:hip.y-1},F=knee(Q,far,121,118,1);
 let N={x:hip.x+9,y:hip.y+1},K=knee(N,A,117,114,1);
 // Shadows split while the toe rises. At contact a new soft shoe shadow forms directly on the lit tread.
 e(g,-206+22*step,628-1.5*push,75,10,'#3b3b4d4d',null,1,-.087);
 e(g,-173+66*swing,611-50*swing,38,mix(7.5,3.2,swing),'#48405140',null,1,-.11);
 if(swing>.82)e(g,A.x+18,519-(A.x+17)*.114,35,3.4,'rgba(89,65,64,'+(.47*s(.82,1,swing))+')',null,1,-.134);
 cloth(g,Q,F,far,false,hit);boot(g,far.x,far.y,farA,false,0);
 cloth(g,N,K,A,true,hit);boot(g,A.x,A.y,footA,true,hit);
 // A glazed reflected brush edge brightens the forward ankle as it passes the threshold.
 if(swing>.62){g.save();g.globalAlpha=.7*s(.62,1,swing);d(g,'M '+(A.x+13)+' '+(A.y-21)+' L '+(A.x+15)+' '+(A.y-12)+' Q '+(A.x+17)+' '+(A.y-7)+' '+(A.x+24)+' '+(A.y-4),null,'#dfbc91',1.06);g.restore();}
 // Torso cropped at upper edge; dust-brown overshirt and soft drape follow the knee weight shift.
 g.save();g.translate(hip.x,hip.y);g.rotate(.04+.095*step+.105*load-.109*follow+.036*hit);g.scale(1+.052*clothLag,1-.043*clothLag);
 d(g,'M -83 -424 Q -9 -445 48 -411 C 44 -270 51 -212 43 -180 L 29 -128 Q 28 -74 40 -24 C 23 -9 3 -7 -9 -2 Q -32 -9 -52 -7 C -66 -50 -62 -113 -71 -159 C -87 -212 -83 -285 -83 -424 Z',grad(g,-74,-313,51,-13,[[0,'#9f8179'],[.48,'#a88577'],[.88,'#8c706c'],[1,'#775e65']]),ink,2.25);
 d(g,'M -75 -167 Q -67 -136 -59 -123 Q -56 -67 -47 -17 L -54 -8 Q -67 -55 -67 -88 Q -75 -127 -75 -167 Z','#755c62',null);
 d(g,'M -41 -12 Q -25 -13 -9 -4 Q 9 -10 20 -12 Q 32 -11 39 -23 M 33 -118 C 23 -86 27 -66 34 -42 M -45 -112 Q -32 -88 -38 -50',null,'#c19b82',1.09);
 // Loose sleeve and visible forearm remain understated. Framing is intentionally below the eyes.
 d(g,'M -52 -265 C -33 -286 -5 -271 8 -234 Q 24 -187 32 -160 L 6 -137 Q -11 -145 -23 -171 L -47 -203 Q -61 -231 -52 -265 Z',grad(g,-49,-269,24,-144,[[0,'#b08b7b'],[.62,'#9e7c71'],[1,'#896b69']]),ink,1.8);
 d(g,'M -23 -174 Q 2 -162 20 -176 M -35 -197 Q -21 -178 -8 -178',null,'#c49c85',1.13);
 d(g,'M 7 -148 C 14 -143 25 -147 30 -157 Q 42 -142 41 -121 L 39 -114 Q 33 -103 30 -108 Q 28 -112 29 -122 L 25 -124 Q 15 -125 8 -137 Z',grad(g,12,-151,39,-109,[[0,'#d3a382'],[1,'#b58679']]),ink,1.53);
 const lag=s(.698,.807,t)*(1-s(.808,.964,t)),sway=.12*Math.sin(t*5.15-.55)-.18*step+.17*lag-.043*follow;
 // The paper and handle arrive a beat after the hip. Bag shape and grip stay intact.
 bag(g,-30-9*step-9.4*lag+4.2*follow,-80-15*push+14.2*lag-3.7*follow,sway,W);
 g.restore();
}
const plate=new Map();
function paintStatic(g,W){road(g,W);busBody(g,W);jamb(g,W,1,false);}
function makePlate(w,h,W){
  const o=typeof OffscreenCanvas==='undefined'?document.createElement('canvas'):new OffscreenCanvas(w,h);o.width=w;o.height=h;
  const f=o.getContext('2d');f.scale(w/W,h/720);f.translate(W*.582,0);f.lineCap='round';f.lineJoin='round';paintStatic(f,W);return o;
}
window.boardingClose=function boardingClose(g,w,h,t=0){
 if(!g||!(w>0&&h>0))return;t=clamp(Number(t)||0,0,1.0);
 const W=720*w/h,rw=Math.round(w),rh=Math.round(h),key=rw+'x'+rh,F=(i)=>i/720*h;
 let a=plate.get(key);if(!a){a=makePlate(rw,rh,W);if(plate.size>=4)plate.delete(plate.keys().next().value);plate.set(key,a);}
 g.save();g.beginPath();g.rect(0,0,w,h);g.clip();
 // Very small lens settling. Reframe once, progressively, not an animated software zoom.
 let q=s(.08,.91,t),z=1.022+.014*q;
 g.translate(w*.60+F(-6*q),h*.56);g.scale(z,z);g.translate(-w*.60,-h*.56);
 g.drawImage(a,0,0,w,h);
 g.scale(h/720,h/720);g.translate(W*.582,0);
 steps(g,t);jamb(g,W,t,true);rider(g,W,t);
 // Delicate peripheral and caption-zone falloff, not a hard hybrid frame.
 rect(g,-W,0,2*W,720,rad(g,W*.055,315,Math.max(W*.80,485),[[0,'#23293900'],[.65,'#23293906'],[1,'#1f283d35']]));
 g.restore();
};
})();

