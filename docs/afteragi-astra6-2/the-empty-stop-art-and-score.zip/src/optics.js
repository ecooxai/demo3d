// Directional cel light and depth effects. These are quiet finishing layers, not fast glitch stock.
(() => {
const {path:P,line:L,ell:E,grad:G,radial:D,R,TAU,clamp,ease}=Art;
const dust=Array.from({length:66},(_,i)=>{let r=R(i*4571+28);return[r(),r(),r(),r(),r()]});
let grains=[];
function grain(frame){
 if(grains[frame])return grains[frame];let c=document.createElement('canvas');c.width=184;c.height=181;
 const k=c.getContext('2d'),im=k.createImageData(c.width,c.height),r=R(9783+frame*633);
 for(let i=0;i<im.data.length;i+=4){let v=(r()+r()+r())/3*230;im.data[i]=v;im.data[i+1]=v;im.data[i+2]=v;im.data[i+3]=68}k.putImageData(im,0,0);return grains[frame]=c
}
window.shafts=(g,w,h,t,opt={})=>{
 let from=opt.from??.16,slant=opt.slant??.38,a=opt.a??.16;
 g.save();g.globalCompositeOperation='screen';
 for(let [q,off,ww] of [[1,0,.095],[.43,.135,.022],[.52,-.124,.038],[.28,.173,.016]]){
 const left=w*(from+off),a1=left+w*.025*Math.sin(t*.13),right=a1+w*ww;
 const p='M '+a1+' 0 L '+right+' 0 '+(right+w*slant+w*.075)+' '+h+' '+(a1+w*slant)+' '+h+' Z';
 P(g,p,G(g,a1,0,a1+w*slant,h,[[0,'rgba(255,204,131,'+(a*q)+')'],[.55,'rgba(253,206,145,'+(a*q*.50)+')'],[1,'rgba(255,208,146,0)']]));
 }g.restore();
};
window.dust=(g,w,h,t,power=.7,wind=.005)=>{
 g.save();for(let i=0;i<dust.length;i++){let [u,v,s,a,f]=dust[i];let x=((u+t*wind*(.35+s)+Math.sin(t*.25*f+i)*.007+3)%1)*w,y=((v+t*.0026*(.3+f)+Math.sin(t*.27+i)*.004+2)%1)*h;
 let sz=(.45+s*.92)*Math.max(1,w/1180),aa=power*(.12+a*.32);E(g,x,y,sz*(1+f*.4),sz,'rgba(244,220,174,'+aa+')');if(s>.92)L(g,[[x,y],[x+sz*3,y+sz*.2]],'rgba(246,221,177,'+aa*.55+')',sz*.6)}
 g.restore()
};
window.finish=(g,w,h,t,style='warm')=>{
 let cosmic=style==='space',cool=style==='cool',shade=style==='night';
 g.save();
 if(cosmic){}else{
  g.fillStyle=G(g,0,0,w,h,[[0,cool?'rgba(134,188,178,.050)':'rgba(255,206,148,.065)'],[.56,'rgba(240,213,167,0)'],[1,cool?'rgba(22,43,66,.095)':'rgba(63,53,72,.11)']]);g.fillRect(0,0,w,h);
 }
 const v=g.createRadialGradient(w*.49,h*.45,Math.min(w,h)*.18,w*.49,h*.47,Math.hypot(w*.55,h*.60));
 v.addColorStop(0,'rgba(24,27,36,0)');v.addColorStop(.65,'rgba(27,30,40,.018)');v.addColorStop(1,'rgba(22,27,38,'+(cosmic?.34:shade?.30:.22)+')');g.fillStyle=v;g.fillRect(0,0,w,h);
 g.globalCompositeOperation='soft-light';g.globalAlpha=cosmic?.19:.24;g.fillStyle=g.createPattern(grain(Math.floor(t*8)%5),'repeat');g.fillRect(0,0,w,h);g.restore()
};
window.shadow=(g,x,y,rx,ry,k=.32)=>{g.save();g.translate(x,y);g.scale(1,ry/rx);g.fillStyle=D(g,0,0,0,rx,[[0,'rgba(38,36,43,'+k+')'],[.47,'rgba(42,39,44,'+(k*.72)+')'],[1,'rgba(46,42,44,0)']]);g.fillRect(-rx,-rx,2*rx,2*rx);g.restore()};
window.breeze=(g,w,h,t)=>{
 let p=ease(t/.52);if(p<=0)return;g.save();g.lineCap='round';
 for(let j=0;j<8;j++){let u=(t*(.48+j*.025)+j*.154)%1,xx=w*(.03+1.02*u),yy=h*(.34+.045*j+.018*Math.sin(t+j));g.strokeStyle='rgba(232,238,209,'+p*Math.sin(Math.PI*u)*.22+')';g.lineWidth=Math.max(1,w*.0009);g.beginPath();g.moveTo(xx-w*.12,yy+h*.014);g.quadraticCurveTo(xx-w*.05,yy-h*.004,xx,yy);g.stroke()}
 g.restore()
};
})();
