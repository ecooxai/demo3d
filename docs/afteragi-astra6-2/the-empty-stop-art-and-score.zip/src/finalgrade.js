// Camera-space cel lighting. Keep warm rims attached to the character alpha, not painted over the scene.
(() => {
const {path:P,line:L,ell:E,grad:G,radial:D,rr:RR,text:T,clamp,ease}=Art;
let c,e;
function buffers(w,h){if(c?.width===w&&c.height===h)return;c=document.createElement('canvas');e=document.createElement('canvas');for(let q of [c,e]){q.width=w;q.height=h}}
window.cast=(ctx,x,y,hh,k,pose,t,facing=1,pins=null,grade='neutral',part=null)=>{
 if(grade==='neutral'||!grade){person(ctx,x,y,hh,k,pose,t,facing,pins,grade,part);return}
 const w=ctx.canvas.width,h=ctx.canvas.height;buffers(w,h);const q=c.getContext('2d'),r=e.getContext('2d'),mat=ctx.getTransform();const dusk=grade==='dusk-rim',office=grade==='cool-office',warm=grade==='warm-left';
 q.setTransform(1,0,0,1,0,0);q.globalCompositeOperation='source-over';q.globalAlpha=1;q.clearRect(0,0,w,h);q.setTransform(mat);
 person(q,x,y,hh,k,pose,t,facing,pins,grade,part);
 const top=y-hh,bottom=y+hh*.05,ww=hh*.95,xx=x-hh*.48;
 r.setTransform(1,0,0,1,0,0);r.globalCompositeOperation='source-over';r.globalAlpha=1;r.clearRect(0,0,w,h);r.drawImage(c,0,0);
 r.globalCompositeOperation='source-in';r.fillStyle=dusk?'#ffd596':office?'#b9e1d7':'#f3cc93';r.fillRect(0,0,w,h);
 r.globalCompositeOperation='destination-out';let disp=Math.max(1.1,Math.min(4.3,hh*(dusk?.0047:.0027)));r.drawImage(c,(dusk?-1:1)*disp,disp*.42);
 q.save();q.globalCompositeOperation='source-atop';
 const shade=G(q,x+(dusk?-.26:.27)*hh,top-hh*.07,x+(dusk?.18:-.18)*hh,bottom,[[0,dusk?'rgba(64,83,112,.205)':office?'rgba(48,73,95,.135)':'rgba(66,78,93,.145)'],[.52,'rgba(76,85,95,.045)'],[1,'rgba(83,82,91,0)']]);
 q.fillStyle=shade;q.fillRect(xx,top-hh*.16,ww,hh*1.28);
 let light=G(q,x+(dusk?.25:-.22)*hh,top+hh*.13,x+(dusk?-.16:.18)*hh,bottom,[[0,dusk?'rgba(255,199,125,.172)':office?'rgba(157,210,199,.067)':'rgba(246,192,123,.130)'],[.57,'rgba(239,196,142,.015)'],[1,'rgba(244,201,147,0)']]);q.fillStyle=light;q.fillRect(xx,top-hh*.16,ww,hh*1.28);
 // Shadow from the overhang falls across the far shoulder, not both eyes.
 if(dusk){P(q,'M '+(x-hh*.39)+' '+(top+hh*.24)+' L '+(x+hh*.18)+' '+(top+hh*.55)+' '+(x+hh*.35)+' '+bottom+' '+(x-hh*.43)+' '+bottom+' Z','rgba(42,65,84,.075)')}
 q.restore();q.setTransform(1,0,0,1,0,0);q.globalCompositeOperation='source-over';q.globalAlpha=dusk?.79:office?.34:.52;q.drawImage(e,0,0);
 ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(c,0,0);ctx.restore();q.globalAlpha=1;
};
})();
