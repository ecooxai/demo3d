// One fictional district. The same geometry appears as a dispatcher screen, a paper map,
// and a verified return stop, making the human correction visually explicit.
(() => {
const {path:P,line:L,ell:E,grad:G,rr:RR,text:T,R,TAU,clamp,ease}=Art;
const cache=new Map(),SW=900,SH=560;
const stops=[[60,397],[181,315],[317,340],[446,238],[581,259],[707,152],[829,174]],missing=[575,410];
const riv='M -40 72 Q 78 118 143 91 T 291 117 Q 363 141 430 115 T 595 129 Q 662 163 738 125 T 924 144';
function atlas(paper){
 const key=paper?'paper':'desk';if(cache.has(key))return cache.get(key);
 const c=document.createElement('canvas');c.width=SW;c.height=SH;const g=c.getContext('2d'),rng=R(paper?1009:1008);
 const land=paper?'#dfcfaa':'#233a43',street=paper?'#efdfbf':'#304851',minor=paper?'#bbaf91':'#46606a',type=paper?'#665f55':'#8aa7a6';
 g.fillStyle=land;g.fillRect(0,0,SW,SH);g.save();g.translate(410,245);g.rotate(-.215);g.translate(-410,-245);
 for(let j=-5;j<19;j++){
  for(let i=-5;i<25;i++){let xx=i*53+7*Math.sin(j*.42),yy=j*43+4*Math.sin(i*.53);
   if((i*7+j*13)%12===0)continue;
   g.fillStyle=paper?['#c4b69a','#cfc1a3','#c6b89d','#d0c1a1','#b6b59a'][Math.floor(rng()*5)]:['#2c444b','#35505a','#344c52','#29454b','#394f50'][Math.floor(rng()*5)];
   g.fillRect(xx+3+rng()*3,yy+3,38+rng()*7,27+rng()*6);
   for(let k=0;k<4;k++){let bx=xx+6+(k%2)*19,by=yy+6+Math.floor(k/2)*13;g.strokeStyle=minor;g.lineWidth=.7;g.strokeRect(bx,by,7+rng()*7,4+rng()*6)}
  }
 }
 g.restore();
 P(g,riv,null,paper?'#92a8a0':'#325e6b',34);P(g,riv,null,paper?'#a3bdb5':'#31535e',27);
 P(g,'M 43 559 Q 96 487 178 429 T 364 306 L 497 241 Q 602 168 664 104 L 791 -15',null,minor,7);
 P(g,'M 43 559 Q 96 487 178 429 T 364 306 L 497 241 Q 602 168 664 104 L 791 -15',null,street,4);
 for(let k=0;k<5;k++){let y=162+77*k;P(g,'M -25 '+y+' Q 173 '+(y-38)+' 324 '+(y+12)+' T 656 '+(y+3)+' Q 799 '+(y-14)+' 932 '+(y+13),null,minor,3.2);P(g,'M -25 '+y+' Q 173 '+(y-38)+' 324 '+(y+12)+' T 656 '+(y+3)+' Q 799 '+(y-14)+' 932 '+(y+13),null,street,1.7)}
 for(let [x,y,s] of [[155,219,'EAST YARD'],[370,174,'CANAL'],[570,352,'FERRY STEPS'],[706,444,'LOWER WARD'],[85,499,'DEPOT']]){T(g,s,x,y,paper?11:10,type,'Noto Sans',680)}
 T(g,'N',848,55,14,type,'Noto Serif',700,'center');P(g,'M 848 65 l -5 18 5 -4 5 4 Z',type);
 L(g,[[659,515],[762,515],[817,515]],type,1.4);for(let x of [659,762,817])L(g,[[x,510],[x,519]],type,1.2);T(g,'200 m',838,519,10,type);
 if(paper){
   g.globalAlpha=.36;
   for(let k=0;k<4800;k++){let x=rng()*SW,y=rng()*SH;g.fillStyle=rng()>.55?'#a58d6d':'#fff0ce';g.fillRect(x,y,.5+rng()*1.3,.6+rng()*1.8)}
   g.globalAlpha=1;
   for(let [x0,y0,x1,y1] of [[290,0,302,SH],[607,0,588,SH],[0,267,900,291]]){L(g,[[x0+2,y0],[x1+2,y1]],'#f5e6bf',1.8);L(g,[[x0,y0],[x1,y1]],'rgba(102,88,70,.25)',2.2)}
   g.strokeStyle='#af9c7f';g.lineWidth=1;g.strokeRect(13.5,13.5,873,533);
 }else{g.fillStyle='rgba(154,209,202,.04)';for(let y=0;y<SH;y+=4)g.fillRect(0,y,SW,1)}
 cache.set(key,c);return c;
}
window.atlasGeom={stops,missing};
window.atlas=(g,x,y,w,h,t,opt={})=>{
 const paper=opt.paper??false,selected=opt.selected??0,mark=opt.mark??0,ang=opt.angle??0,blank=opt.blank??false;
 g.save();g.translate(x,y);g.rotate(ang);g.scale(w/SW,h/SH);
 const ink=paper?'#755947':'#1b2b32',light=paper?'#faf0d3':'#9dd8cd',route=paper?'#628277':'#88cbb6',rust=paper?'#ac4b3e':'#f7ad77';
 if(paper){P(g,'M 0 3 L 902 5 905 560 3 564 Z','rgba(49,39,39,.32)');}
 else {RR(g,-14,-14,928,588,20,'#34494b','#273537',3);RR(g,-5,-5,910,570,13,'#172831','#9baa92',1.1)}
 g.save();g.beginPath();g.rect(0,0,SW,SH);g.clip();g.drawImage(atlas(paper),0,0);
 const points=stops;
 // A quiet hatched census gap around the actual ferry landing. No person is removed from the map.
 if(!paper&&selected<.97){let gap=new Path2D('M 473 353 L 550 318 644 348 656 427 615 473 528 462 471 421 Z');g.save();g.clip(gap);g.fillStyle='rgba(15,30,38,'+(.37*(1-selected))+')';g.fillRect(461,312,208,169);for(let j=0;j<29;j++)L(g,[[429+j*11,474],[535+j*11,305]],'rgba(139,156,148,'+(.14*(1-selected))+')',1.1);g.restore();g.save();g.globalAlpha=.69*(1-selected);g.setLineDash([4.6,4]);g.strokeStyle='#80908c';g.lineWidth=1.3;g.stroke(gap);g.restore()}
 const routeDraw=(pts,c,k)=>{g.lineJoin='round';g.lineCap='round';L(g,pts,c,k)};
 let visible=points;
 if(!paper && opt.drawRoute!==undefined){let at=clamp(opt.drawRoute)*(points.length-1),k=Math.min(Math.floor(at),points.length-2),u=at-k,A=points[k],B=points[k+1];visible=points.slice(0,k+1);visible.push([A[0]*(1-u)+B[0]*u,A[1]*(1-u)+B[1]*u])}
 routeDraw(points,paper?'#e4d5b2':'#1b333a',paper?7:10);routeDraw(visible,route,paper?3.4:4.5);
 for(let k=0;k<points.length;k++){let [sx,sy]=points[k];E(g,sx,sy,5.4,5.4,paper?'#e5dbc0':'#243c42',route,2.0);if(!paper&&k===3){let ping=(t*.29)%1;E(g,sx,sy,6+11*ping,6+11*ping,null,'rgba(150,224,203,'+(.38*(1-ping))+')',.9)}}
 if(!paper&&!blank){const seg=((t*.32+1.5)%(points.length-1)+points.length-1)%(points.length-1),i=Math.floor(seg),q=seg-i,xx=points[i][0]*(1-q)+points[i+1][0]*q,yy=points[i][1]*(1-q)+points[i+1][1]*q;E(g,xx,yy,8,8,'#23393b','#b9dfc8',2);E(g,xx,yy,3,3,'#f4d5a3')}
 const [mx,my]=missing;
 if(paper){g.save();g.strokeStyle='#796e60';g.lineWidth=1.7;g.setLineDash([4,4]);g.beginPath();g.moveTo(447,237);g.lineTo(492,305);g.lineTo(mx,my);g.stroke();g.restore();E(g,mx,my,4.5,4.5,'#e8dbbb','#796857',1.4)}
 if(selected>0){let q=clamp(selected),a=[points[3],[484,324],missing,[632,333],points[4]],end=q*(a.length-1),idx=Math.min(Math.floor(end),a.length-2),parts=a.slice(0,idx+1),aa=a[idx],b=a[idx+1],r=end-idx;parts.push([aa[0]*(1-r)+b[0]*r,aa[1]*(1-r)+b[1]*r]);routeDraw(parts,'#364949',8);routeDraw(parts,rust,4);if(end>1.95){E(g,mx,my,7,7,'#424843',rust,2.4);E(g,mx,my,2,2,'#fbe6b3')}}
 if(mark>0){g.save();g.translate(mx,my);g.rotate(-.24);g.strokeStyle=rust;g.lineWidth=paper?3.1:1.9;g.lineCap='round';g.beginPath();g.ellipse(0,0,42,24,0,-2.45,-2.45+TAU*clamp(mark));g.stroke();g.restore()}
 if(!paper&&opt.focus){
   if(selected<.45){T(g,'NO REPORTS',mx,my+7,15,'#9aada4','Noto Sans',620,'center')}
   else {T(g,'STOP RESTORED',mx,my+32,15,'#f4c495','Noto Sans',650,'center')}
 }
 const title=paper?'WATERFRONT DISTRICT   /   SHEET 04':'MIZUHAMA    /    COOLING TRANSIT';
 if(paper){g.fillStyle='#dfcfad';g.fillRect(22,20,335,49);T(g,title,31,38,14,ink,'Noto Sans',700);T(g,'水浜街区図    •    LOCAL ROUTE ATLAS',32,57,11,'#79725f','Noto Sans CJK JP',500)}
 else{g.fillStyle='rgba(24,42,49,.88)';g.fillRect(0,0,SW,65);T(g,title,opt.titleInset??23,27,16,'#c1d1c2','Noto Sans',650);T(g,selected>.6?'MANUAL STOP ADDED  /  FERRY STEPS':'SUGGESTED ROUTE  /  12 MIN SAVED',opt.titleInset??23,50,14,selected>.5?rust:light,'Noto Sans',560);E(g,858,31,4,4,light);E(g,871,31,4,4,'#6f8885')}
 g.restore();g.restore()
};
})();
