/* The Empty Stop — optional native dusk two-shot, original character cels only.
   No backdrop, subtitles or side-bars are painted here. The actor painter owns
   profile, eyelid, cheek and breathing keys; this shot owns blocking and overlap. */
(()=>{
  const clamp=x=>Math.max(0,Math.min(1,x));
  const ease=(a,b,x)=>{const t=clamp((x-a)/(b-a));return t*t*(3-2*t);};
  window.familyClose=function(g,w,h,t=0){
    if(!(w>0)||!(h>0)||typeof window.closeCastAt!=='function')return;
    const frame=Number.isFinite(t)?Math.max(0,t):0, portrait=h>w, lift=ease(.11,.76,frame);
    const s=Math.min(h*(portrait?.00183:.0021),w*.0033);
    // Teen's eye axis lifts toward grandfather while his chin and shoulders settle.
    // Keep those motions independent so the pause does not feel like a single moving plate.
    let teenX=w*(portrait?.301:.36), elderX=w*(portrait?.68:.638);
    let teenY=h*(portrait?.538:.54), elderY=h*(portrait?.443:.431);
    const lean=Math.sin(frame*2.63)*.38, nod=ease(.28,.81,frame);
    g.save();g.beginPath();g.rect(0,0,w,h);g.clip();
    closeCastAt(g,teenX+s*lift*1.95,teenY-s*(1.79*lift+lean),s*.967,frame,'teen',-1,'shared');
    closeCastAt(g,elderX-s*.9*nod,elderY+s*1.38*nod,s*1.012,frame,'grandpa',1,'shared');
    g.restore();
  };
})();

