// A graphite stop circle becomes an orbital observing site, then a block in the model,
// then the selected transit stop. The same address anchors all three scales.
(() => {
const {path:P,line:L,ell:E,grad:G,radial:D,rr:RR,text:T,R,TAU,ease,clamp,lerp}=Art;
window.locator=(g,x,y,r,t,label='',alpha=1,tilt=.52,color='#e5ae80')=>{
 g.save();g.globalAlpha=alpha;g.lineCap='round';
 // Interrupted strokes: drawn by a human first, measured by a machine next.
 g.strokeStyle=color;g.lineWidth=Math.max(1,r*.053);g.beginPath();g.ellipse(x,y,r,r*tilt,-.17,t*.10+.18,t*.10+4.6);g.stroke();
 g.beginPath();g.ellipse(x,y,r*.86,r*tilt*.85,-.17,5,6.51);g.stroke();E(g,x,y,r*.082,r*.082,'#f1c98c');
 if(label){let s=Math.max(11,r*.27);L(g,[[x+r*.82,y-r*.04],[x+r*1.27,y-r*.44],[x+r*2.1,y-r*.44]],color,Math.max(1,r*.02));T(g,label,x+r*1.32,y-r*.54,s,'#e8d7b4','Noto Sans',570)}
 g.restore()
};
// Each ray belongs to the original observatory, and the last pin is registered to the exact
// first forecast frame, not to a generic grid. This is a fictional observation pass.
window.spaceOptics=(w,h,t)=>{
 const p=h>w,sc=Math.min(w/(p?12.6:18),h/(p?12:9.1))*.94;
 const turn=ease((t-1.72)/1.38),z=1.028+.065*ease(t/3.33)+(p?.315:.258)*turn;
 const target0=[w*(p?.574:.583),h*.705],target1=[w*(p?.51:.54),h*(p?.58:.60)+.32*.89*sc];
 const dx=turn*(target1[0]-(w*.5+(target0[0]-w*.5)*z)),dy=turn*(target1[1]-(h*.49+(target0[1]-h*.49)*z));
 const tr=(x,y)=>[w*.5+(x-w*.5)*z+dx,h*.49+(y-h*.49)*z+dy];
 return {z,dx,dy,target:tr(...target0),eye:tr(w*.27,h*259/720),local:sc}
};
window.orbitMatch=(g,w,h,t)=>{
 const p=h>w,q=ease((t-.05)/1.13),end=ease((t-2.26)/.87),op=spaceOptics(w,h,t);
 let x=lerp(w*(p?.48:.54),op.target[0],q),y=lerp(h*(p?.54:.55),op.target[1],q);
 let r=Math.min(w,h)*lerp(.076,.023,q)*(1+end*.35),a=(1-end*.12);
 if(t<.82){g.save();g.globalAlpha=(1-ease(t/.82))*.36;g.fillStyle=G(g,0,0,w,h,[[0,'#b29874'],[1,'#785d56']]);g.fillRect(0,0,w,h);g.restore()}
 g.save();g.globalCompositeOperation='screen';let glow=D(g,x,y,0,r*3.5,[[0,'rgba(250,173,111,.28)'],[.42,'rgba(243,143,91,.09)'],[1,'rgba(246,166,99,0)']]);g.fillStyle=glow;g.fillRect(x-r*3.6,y-r*3.6,r*7.2,r*7.2);g.restore();
 const scan=ease((t-.66)/.46)*(1-ease((t-2.52)/.69)),pick=ease((t-.92)/.97);
 if(scan>.005){
   const [ex,ey]=op.eye,sx=op.target[0],sy=op.target[1],s=Math.min(w,h),sw=s*.071,sh=s*.022;
   const corners=[[sx-sw,sy-sh*.2],[sx+sw*.14,sy-sh*1.18],[sx+sw,sy+sh*.11],[sx-sw*.08,sy+sh*1.24]];
   const hit=[lerp(corners[0][0],corners[2][0],pick),lerp(corners[0][1],corners[2][1],pick)];
   g.save();g.globalAlpha=scan;g.globalCompositeOperation='screen';
   P(g,'M '+ex+' '+ey+' L '+corners[0].join(' ')+' '+corners[2].join(' ')+' Z',G(g,ex,ey,sx,sy,[[0,'rgba(150,192,207,.006)'],[.8,'rgba(163,208,198,.015)'],[1,'rgba(190,221,184,.065)']]));
   L(g,[[ex,ey],hit],'rgba(187,220,204,.31)',Math.max(1,s*.0010));
   for(let j=0;j<4;j++)L(g,[corners[j],corners[(j+1)%4]],'rgba(225,207,153,.62)',s*.0013);
   for(let f of [.25,.50,.75]){
    let A=corners[0],B=corners[1],C=corners[2],D0=corners[3];
    L(g,[[lerp(A[0],B[0],f),lerp(A[1],B[1],f)],[lerp(D0[0],C[0],f),lerp(D0[1],C[1],f)]],'rgba(205,224,191,.28)',s*.00084);
    L(g,[[lerp(A[0],D0[0],f),lerp(A[1],D0[1],f)],[lerp(B[0],C[0],f),lerp(B[1],C[1],f)]],'rgba(205,224,191,.24)',s*.00084);
   }g.restore();
 }
 locator(g,x,y,r,t,'',a,lerp(.50,.41,q),'#efbf88');
 const lab=ease((t-.96)/.40)*(1-.30*end);
 if(lab>0){g.save();g.globalAlpha=lab;let fs=Math.min(w,h)*(p?.0250:.0265),lx=x+r*1.8,ly=y-r*1.30;
  g.font='640 '+fs+'px "Noto Sans",sans-serif';let tw=g.measureText('FERRY STEPS').width,pad=fs*.44;
  L(g,[[x+r*.8,y-r*.15],[lx-fs*.32,ly],[lx+fs*.1,ly]],'#e8ba89',Math.max(1.2,fs*.063));
  RR(g,lx,ly-fs*.74,tw+2*pad,fs*1.36,fs*.15,'rgba(30,47,57,.79)');T(g,'FERRY STEPS',lx+pad,ly+fs*.25,fs,'#f3ddad','Noto Sans',640);
  g.restore()}
};
window.sceneJoin=(g,w,h,t)=>{
 // Keep the grade gentle so the cut itself carries the heat/route relation.
 let dt=Math.abs(t-26.30);if(dt<.22){let q=1-dt/.22;g.save();g.globalAlpha=q*.12;g.fillStyle='#f3d5a5';g.fillRect(0,0,w,h);g.restore()}
};
})();
