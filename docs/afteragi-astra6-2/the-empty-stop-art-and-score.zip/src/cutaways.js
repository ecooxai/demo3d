// A human-sized cutaway for the film's closing line. The same teal stool is visible in the wide.
(() => {
const {path:P,line:L,ell:E,grad:G,radial:D,rr:RR,text:T,R,TAU,ease,clamp,lerp}=Art;
function palm(g,x,y,s,ang,t){
 const outline='#70564e',skin='#c99e80',lo='#a77e6c',hi='#e2bf98';g.save();g.translate(x,y);g.rotate(ang);g.scale(s,s);g.lineJoin='round';g.lineCap='round';
 // Forearm and cuff continue beyond the photographic edge. The four nails share one plane.
 P(g,'M 100 -27 Q 137 -36 162 -39 L 700 -202 753 -56 153 23 113 25 Z','#87876a','#605c50',1.8);
 P(g,'M 140 4 Q 195 -1 234 -17 L 760 -119 753 -56 153 23 125 22 Z','#676d58');
 P(g,'M 111 -25 L 130 -30 150 19 133 29 117 26 Z','#a29d79','#6b6757',1.2);
 for(let i=0;i<4;i++){let a=119+i*4;P(g,'M '+a+' -22 q 6 21 12 43',null,'#8b8969',.9)}
 let col=G(g,14,-20,67,37,[[0,'#dfbb96'],[.43,skin],[1,'#b08773']]);
 // Forefinger is the furthest finger from camera. Each subsequent finger overlaps its base.
 P(g,'M 62 -17 Q 54 -22 44 -20 L 22 -15 1 -11 Q -4 -10 -4 -6 Q -3 -2 3 -3 L 31 -7 49 -6 63 -4 Z',col,outline,1.3);
 P(g,'M 68 -11 Q 58 -16 50 -15 L 27 -10 4 -6 -7 -4 Q -12 -2 -11 2 Q -10 5 -4 5 L 18 3 45 -1 64 2 Z',col,outline,1.4);
 P(g,'M 68 -4 Q 60 -10 52 -9 L 31 -3 8 2 -4 4 Q -8 6 -7 10 Q -6 13 -1 12 L 21 10 43 7 68 8 Z',col,outline,1.35);
 P(g,'M 73 4 Q 65 -2 55 1 L 36 8 17 14 6 16 Q 1 17 2 20 Q 2 24 8 23 L 26 20 47 16 69 17 Z',col,outline,1.3);
 P(g,'M 44 -15 Q 48 -20 55 -22 Q 62 -29 75 -29 L 94 -28 Q 104 -28 116 -25 L 130 18 Q 117 27 104 27 L 84 31 Q 71 31 62 25 L 47 16 Q 52 9 44 6 L 43 -2 Q 48 -6 44 -15 Z',col,null);
 // Thumb stays on the near side of the palm, distinct from the four fingertips.
 P(g,'M 95 9 Q 85 14 77 17 Q 66 20 56 27 L 38 37 Q 32 40 33 44 Q 35 48 43 46 L 68 36 88 30 Q 97 28 106 24',col,outline,1.5);
 P(g,'M 53 -19 Q 65 -28 76 -26 L 97 -24 98 -21 Q 79 -18 70 -16 L 59 -11 Z',hi);
 P(g,'M 90 12 Q 82 21 69 23 L 53 32 66 29 86 24 96 18 Z',lo);
 P(g,'M 35 42 Q 39 37 44 37 L 46 40 40 44 35 45 Z','#dfc5ac',outline,.55);
 for(let [nx,ny] of [[-2,-8],[-9,-1],[-5,6],[4,17]])P(g,'M '+nx+' '+ny+' q 5 -1 9 -2 l 2 3 q -5 3 -10 3 Z','#e3c8ad',outline,.45);
 for(let [a,b] of [[12,-11],[19,-5],[17,3],[35,10],[53,-17],[65,-19],[76,-23],[82,12],[102,8],[94,-10],[104,-16],[47,2]])P(g,'M '+a+' '+b+' q 4 0 6 3',null,'rgba(112,82,68,.57)',.64);
 for(let i=0;i<10;i++){let xx=63+(i*23%49),yy=-17+(i*19%35);E(g,xx,yy,.8,.58,'rgba(142,100,73,.42)')}
 g.restore()
}
window.seatInsert=(g,w,h,t)=>{
 const p=h>w,unit=Math.min(w/770,h/510),rng=R(5720),q=ease(t/1.38);
 // Out-of-focus warm stone and shutter striations establish the open threshold without signage.
 let b=G(g,0,0,w,h,[[0,'#7d7774'],[.34,'#b6a58b'],[.59,'#d7b791'],[.82,'#9f7765'],[1,'#75615d']]);g.fillStyle=b;g.fillRect(0,0,w,h);
 g.save();g.filter='blur('+Math.max(4,Math.round(h*.006))+'px)';
 for(let k=0;k<8;k++){let y=h*(.11+k*.075);P(g,'M 0 '+y+' L '+w+' '+(y-h*.15)+' '+w+' '+(y-h*.13)+' 0 '+(y+h*.017)+' Z',k%2?'rgba(243,203,151,.24)':'rgba(66,67,74,.13)')}
 // A glimpse of her red apron and his slacks puts the stool physically between them.
 let ax=w*(p?.028:.055);
 P(g,'M 0 0 L '+ax+' 0 '+(ax+w*.055)+' '+(h*.68)+' '+(ax+w*.014)+' '+(h*.95)+' 0 '+h+' Z','#9e6356');
 P(g,'M '+(w*.91)+' 0 L '+w+' 0 '+w+' '+h+' '+(w*.85)+' '+h+' '+(w*.81)+' '+(h*.68)+' '+(w*.87)+' '+(h*.48)+' Z','#6a666e');
 g.restore();
 let cx=w*(p?.45:.45),cy=h*.63,ww=Math.min(w*(p?.85:.64),h*1.07),hh=ww*.29;
 g.save();g.translate(cx,cy);g.rotate(-.064);
 // Back legs, front legs, curved apron and blue paint worn to maple at each corner.
 for(let [a,b,drag] of [[-.34,-.04,-.075],[.35,-.04,.080],[-.40,.29,-.094],[.40,.25,.11]]){
  P(g,'M '+(ww*(a-.024))+' '+(hh*b)+' l '+(ww*.056)+' 0 '+(ww*drag)+' '+(hh*1.99)+' '+(-ww*.061)+' '+(hh*.020)+' Z','#526d68','#425650',2.0*unit);
  L(g,[[ww*(a-.014),hh*(b+.09)],[ww*(a+drag+.004),hh*(b+1.92)]],'#a4aaa0',1.5*unit)}
 const face='M '+(-ww*.50)+' '+(-hh*.08)+' Q '+(-ww*.48)+' '+(-hh*.18)+' '+(-ww*.38)+' '+(-hh*.35)+' L '+(ww*.35)+' '+(-hh*.42)+' Q '+(ww*.39)+' '+(-hh*.42)+' '+(ww*.405)+' '+(-hh*.37)+' L '+(ww*.51)+' '+(-hh*.12)+' Q '+(ww*.53)+' '+(-hh*.04)+' '+(ww*.49)+' '+(hh*.02)+' L '+(-ww*.44)+' '+(hh*.17)+' Q '+(-ww*.505)+' '+(hh*.17)+' '+(-ww*.50)+' '+(-hh*.08)+' Z';
 P(g,'M '+(-ww*.50)+' '+(-hh*.01)+' L '+(ww*.51)+' '+(-hh*.12)+' '+(ww*.50)+' '+(hh*.23)+' '+(-ww*.45)+' '+(hh*.39)+' Q '+(-ww*.5)+' '+(hh*.38)+' '+(-ww*.50)+' '+(hh*.28)+' Z','#52726e','#4b5b56',2*unit);
 P(g,face,G(g,-ww*.4,-hh*.3,ww*.3,hh*.15,[[0,'#c9b58f'],[.22,'#bec0a9'],[.55,'#96b1a5'],[.79,'#aabab0'],[1,'#c5b79b']]),'#607771',1.6*unit);
 g.save();g.clip(new Path2D(face));
 for(let k=0;k<85;k++){let xx=ww*(rng()-.5),yy=hh*(rng()*.67-.45),ll=ww*(.015+rng()*.19);P(g,'M '+xx+' '+yy+' q '+(ll*.58)+' '+(-unit*1.1)+' '+ll+' '+(-ll*.07),null,rng()>.51?'rgba(116,107,85,.24)':'rgba(231,215,179,.43)',unit*(.37+rng()*.56))}
 g.fillStyle=G(g,-ww*.1,0,ww*.18,hh*.65,[[0,'rgba(254,215,150,.34)'],[1,'rgba(255,210,141,0)']]);g.fillRect(-ww*.55,-hh*.47,ww*1.1,hh*.7);g.restore();
 L(g,[[-ww*.443,hh*.177],[ww*.486,hh*.025]],'#d1c2a0',1.65*unit);
 for(let k=0;k<29;k++){let xx=ww*(-.43+.9*rng()),yy=hh*(.105-.14*(xx/ww)+rng()*.05);L(g,[[xx,yy],[xx+ww*(.004+rng()*.018),yy-unit*.4]],'#bda88a',unit*.76)}
 for(let [sx,sy] of [[-.37,-.24],[.36,-.28],[-.39,.04],[.40,-.04]]){E(g,ww*sx,hh*sy,unit*2.5,unit*1.3,'#8a8c79','#666e62',unit*.56);L(g,[[ww*sx-unit*1.2,hh*sy],[ww*sx+unit,hh*sy]],'#6b6b5c',unit*.56)}
 g.restore();
 // Double pat: descend, rebound, settle, release. Contact shadow tightens before the second touch.
 let tap=ease((t-.06)/.30)-.75*ease((t-.39)/.19)+.72*ease((t-.63)/.20)-.85*ease((t-1.02)/.36),handS=Math.min(h*.0042,w*.0035);
 let hx=cx+ww*.046,hy=cy-hh*.105-h*(.14-.135*tap);
 shadow(g,hx+handS*34,cy-hh*.065,ww*(.20-.054*tap),hh*(.11-.035*tap),.13+.24*tap);
 palm(g,hx,hy,handS,-.22+.077*tap,t);
 shafts(g,w,h,t,{from:.57,slant:-.34,a:.115});dust(g,w,h,t,.40,.008)
};
})();
