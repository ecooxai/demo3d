import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import os from 'node:os';
import {pathToFileURL} from 'node:url';
const [input,out,sw,sh,sstart='0',sduration='2',fpsarg='24',flavor='final']=process.argv.slice(2);
if(!input||!out)throw Error('capture <html> <out.mp4|png> W H t0 duration fps [variant]');
const w=+sw,h=+sh,fps=+fpsarg,t0=+sstart,frames=Math.round(+sduration*fps),series=process.env.FRAME_TIMES?.split(',').map(Number),image=!!series||/\.(png|jpg)$/.test(out);
let browser,enc,profile,sock;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
try{
const tmp=path.resolve(process.env.FILM_RENDER_TMP||'.cache/render-tmp');if(Buffer.byteLength(tmp)>61)throw Error('Chromium Unix socket directory is too deep; set FILM_RENDER_TMP to a short dedicated writable folder on your project volume.');fs.mkdirSync(tmp,{recursive:true,mode:0o700});fs.mkdirSync(path.resolve('.cache'),{recursive:true,mode:0o700});profile=fs.mkdtempSync(path.resolve('.cache/chrome-')); let clog='';
browser=spawn('chromium',['--headless=new','--disable-gpu','--disable-background-networking','--disable-component-update','--no-first-run','--no-default-browser-check','--disable-breakpad','--mute-audio','--renderer-process-limit=1','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{env:{...process.env,TMPDIR:tmp,TMP:tmp,TEMP:tmp},stdio:['ignore','ignore','pipe']});
browser.stderr.on('data',b=>clog=(clog+b).slice(-1200));
let port;
for(let i=0;i<200;i++){if(fs.existsSync(profile+'/DevToolsActivePort')){port=fs.readFileSync(profile+'/DevToolsActivePort','utf8').split('\n')[0];break} if(browser.exitCode!=null||browser.signalCode)throw Error('Chromium terminated '+(browser.signalCode||browser.exitCode)+' '+clog);await wait(100)}
if(!port)throw Error('No Chromium debugger '+clog);
let tabs=await(await fetch('http://127.0.0.1:'+port+'/json/list')).json();let tab=tabs.find(x=>x.type==='page');
sock=new WebSocket(tab.webSocketDebuggerUrl);
await new Promise((r,j)=>{sock.onopen=r;sock.onerror=j});
const req=new Map();let id=0;
sock.onmessage=e=>{let msg=JSON.parse(e.data);if(msg.id&&req.has(msg.id)){let [r,j]=req.get(msg.id);req.delete(msg.id);msg.error?j(Error(JSON.stringify(msg.error))):r(msg.result)}};
sock.onclose=e=>{for(const [k,[r,j]] of req)j(Error('Chromium transport closed '+e.code+' '+e.reason+'; browser='+browser.exitCode+' '+clog));req.clear()};
function call(method,params={}){let index=++id;return new Promise((r,j)=>{const timer=setTimeout(()=>{req.delete(index);j(Error('CDP timed out: '+method+' '+String(params.expression||'').slice(0,90)))},22000);req.set(index,[v=>{clearTimeout(timer);r(v)},e=>{clearTimeout(timer);j(e)}]);sock.send(JSON.stringify({id:index,method,params}))})}
async function run(expression){let res=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(res.exceptionDetails)throw Error(res.exceptionDetails.exception?.description||res.exceptionDetails.text);return res.result.value;}
await call('Page.enable');await call('Page.navigate',{url:pathToFileURL(path.resolve(input)).href});
for(let i=0;i<100&&!(await run('typeof draw === "function"'));i++)await wait(60);
await run('document.fonts.ready.then(()=>true)');
await run('window.prepare?.('+[w,h,JSON.stringify(flavor)].join(',')+')');
let tbegin=Date.now();
if(!image){enc=spawn('ffmpeg',['-y','-hide_banner','-loglevel','error','-f','image2pipe','-c:v','mjpeg','-framerate',''+fps,'-i','pipe:0','-c:v','libx264','-preset','veryfast','-crf','17','-vf','scale=in_color_matrix=bt601:out_color_matrix=bt709:in_range=full:out_range=tv','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-pix_fmt','yuv420p','-threads','3','-movflags','+faststart',out],{stdio:['pipe','ignore','inherit']});enc.stdin.on('error',()=>{});}
for(let i=0;i<(series?series.length:image?1:frames);i++){
 if(!image&&i%24===0)console.log(out,'drawing',i,'at',new Date().toISOString());
 const data=await run('draw('+[w,h,(series?series[i]:t0+i/fps).toFixed(8),JSON.stringify(flavor)].join(',')+');document.querySelector("canvas").toDataURL('+JSON.stringify(image&&out.endsWith('.png')?'image/png':'image/jpeg')+',0.94).split(",")[1]');
 const b=Buffer.from(data,'base64');
 if(image){if(series){fs.mkdirSync(out,{recursive:true});fs.writeFileSync(out+'/'+String(i).padStart(3,'0')+'.jpg',b);continue}fs.writeFileSync(out,b);break}
 if(enc.exitCode!==null)throw Error('encoder ended '+enc.exitCode);
 if(!enc.stdin.write(b))await new Promise((r,j)=>{const timer=setTimeout(()=>j(Error('ffmpeg input backpressure timeout '+i)),22000);const err=e=>{clearTimeout(timer);enc.stdin.off('drain',done);j(e)};const done=()=>{clearTimeout(timer);enc.stdin.off('error',err);r()};enc.stdin.once('drain',done);enc.stdin.once('error',err)});
 if(i&&i%(fps*6)===0)console.log(out,i+'/'+frames,((Date.now()-tbegin)/1000).toFixed(1)+'s');
}
if(enc){const ec=new Promise(r=>enc.once('exit',r));enc.stdin.end();if(await ec!==0)throw Error('ffmpeg failed')}
console.log(out,'OK',((Date.now()-tbegin)/1000).toFixed(2)+'s',new Date().toISOString());
}finally{sock?.close();if(enc&&enc.exitCode===null)enc.kill('SIGTERM');if(browser){browser.kill('SIGTERM');await wait(350)}if(profile){try{fs.rmSync(profile,{recursive:true,force:true})}catch{}}}
