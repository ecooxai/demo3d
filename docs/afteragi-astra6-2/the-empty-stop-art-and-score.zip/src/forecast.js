// A three-dimensional thermal model, rendered from an original procedural miniature city.
// Painter-ordered blocks and projected flow lines place competing forecasts in one shared space.
(() => {
const {path:P,line:L,ell:E,grad:G,radial:D,rr:RR,text:T,R,TAU,ease,clamp}=Art;
const b=[],rng=R(41851);for(let j=-8;j<=8;j++)for(let i=-10;i<=10;i++){
 let river=Math.sin(i*.28)*1.8-.7;if(Math.abs(j-river)<1.0)continue;
 let mid=Math.exp(-((i-2)**2/37+(j-1)**2/33)),ht=.08+rng()*.38+mid*(.12+rng()*1.3);
 if(rng()<.07)continue;
 let X=i+(rng()-.5)*.25,Z=j+(rng()-.5)*.24;
 b.push({X,Z,w:.37+rng()*.32,d:.37+rng()*.32,ht,seed:rng(),therm:Math.exp(-((X-4)**2/38+(Z-5)**2/18))})
}
function color(a,b,k){return 'rgb('+a.map((x,i)=>Math.round(x+(b[i]-x)*k)).join(',')+')'}
function polygon(g,p,c,ed,lw=.7){g.beginPath();g.moveTo(...p[0]);for(let i=1;i<p.length;i++)g.lineTo(...p[i]);g.closePath();if(c){g.fillStyle=c;g.fill()}if(ed){g.strokeStyle=ed;g.lineWidth=lw;g.stroke()}}
window.forecast=(g,w,h,t)=>{
 const pt=h>w,approach=ease(t/3.45),shade=ease((t-1.08)/1.37),sc=Math.min(w/(pt?12.6:18),h/(pt?12:9.1))*(.94+.39*approach),ang=-.67+.205*approach,cs=Math.cos(ang),sn=Math.sin(ang),focusX=4,focusZ=5,cx=w*(pt?.51:.54)-(focusX*cs-focusZ*sn)*sc,cy=h*(pt?.58:.60)-((focusX*sn+focusZ*cs)*.43-.61*.89)*sc;
 const depth=(x,z)=>x*sn+z*cs;
 const pr=(x,y,z)=>[cx+(x*cs-z*sn)*sc,cy+(depth(x,z)*.43-y*.89)*sc];
 const bg=G(g,0,0,w*.6,h,[[0,'#151e33'],[.53,'#24394b'],[1,'#152b37']]);g.fillStyle=bg;g.fillRect(0,0,w,h);
 g.fillStyle=D(g,w*.55,h*.62,0,w*.63,[[0,'rgba(113,177,169,.22)'],[.58,'rgba(73,139,148,.09)'],[1,'rgba(58,125,141,0)']]);g.fillRect(0,0,w,h);
 // Far lattice continues past the model and fades toward the horizon.
 for(let i=-18;i<=18;i++){L(g,[pr(i,0,-17),pr(i,0,17)],'rgba(150,198,181,.095)',.8);L(g,[pr(-18,0,i),pr(18,0,i)],'rgba(150,198,181,.095)',.8)}
 let river=[];for(let x=-14;x<=14;x+=.25)river.push(pr(x,0,Math.sin(x*.28)*1.8-.7));L(g,river,'rgba(128,184,198,.34)',sc*.38);L(g,river,'rgba(87,144,161,.80)',sc*.27);
 const blocks=b.filter(o=>Math.abs(o.X-focusX)>1.43||Math.abs(o.Z-focusZ)>1.15).sort((a,b)=>depth(a.X,a.Z)-depth(b.X,b.Z));
 // A real 3D shadow plane and the cooling envelope distinguish vulnerable blocks from generic cubes.
 for(const o of blocks){let {X,Z,w:ww,d,ht}=o,k=ht*.55;polygon(g,[pr(X-ww*.5,.004,Z+d*.5),pr(X+ww*.5,.004,Z+d*.5),pr(X+ww*.5+k,.004,Z+d*.5+k*.36),pr(X-ww*.5+k,.004,Z+d*.5+k*.36)],'rgba(5,22,31,.30)')}
 let hot=pr(focusX,.12,focusZ);g.save();g.translate(...hot);g.scale(1,.43);const hg=g.createRadialGradient(0,0,0,0,0,sc*4.6);hg.addColorStop(0,'rgba('+Math.round(232-127*shade)+','+Math.round(129+69*shade)+','+Math.round(80+90*shade)+',.38)');hg.addColorStop(.70,'rgba(211,145,99,.06)');hg.addColorStop(1,'rgba(224,165,112,0)');g.fillStyle=hg;g.fillRect(-5*sc,-5*sc,10*sc,10*sc);g.restore();
 for(let tr=0;tr<44;tr++){let tx=-11+tr*.55,tz=Math.sin(tx*.28)*1.8+.42+(tr%2)*.21,ground=pr(tx,.02,tz),cap=pr(tx,.37+(tr%3)*.04,tz);L(g,[ground,cap],'#55726f',sc*.02);E(g,...cap,sc*.11,sc*.15,'#7b9b88',null)}
 const layer=blocks.concat({X:focusX,Z:focusZ,plaza:true}).sort((a,b)=>depth(a.X,a.Z)-depth(b.X,b.Z));
 for(const o of layer){
 if(o.plaza){
   // A virtual civic square replaces the abstract target cube. The shade sail visibly unfurls.
   let x0=focusX-1.38,x1=focusX+1.38,z0=focusZ-1.08,z1=focusZ+1.08;
   polygon(g,[pr(x0,.025,z0),pr(x1,.025,z0),pr(x1,.025,z1),pr(x0,.025,z1)],color([187,123,91],[86,153,151],shade),'#7c9e98',1.15);
   for(let i=1;i<7;i++)L(g,[pr(x0+(x1-x0)*i/7,.032,z0),pr(x0+(x1-x0)*i/7,.032,z1)],'rgba(232,205,166,.27)',.8);
   for(let i=1;i<5;i++)L(g,[pr(x0,.035,z0+(z1-z0)*i/5),pr(x1,.035,z0+(z1-z0)*i/5)],'rgba(232,205,166,.23)',.8);
   let corners=[[x0+.10,1.33,z0+.13],[x1-.12,1.68,z0+.21],[x1-.19,1.16,z1-.16],[x0+.15,1.37,z1-.05]];
   for(const [px,py,pz] of corners){L(g,[pr(px,.045,pz),pr(px,py,pz)],'#8baca9',Math.max(1.5,sc*.025));E(g,...pr(px,py,pz),sc*.026,sc*.026,'#deceae')}
   // Two long benches and the little bus-stop standard make the site human-scaled.
   for(let j=0;j<2;j++){
    let bx=x0+.38+j*.86,bz=z1-.23;polygon(g,[pr(bx,.27,bz),pr(bx+.59,.27,bz),pr(bx+.59,.27,bz+.16),pr(bx,.27,bz+.16)],'#d7b48d','#7c9288',.8);
    L(g,[pr(bx+.08,.23,bz+.12),pr(bx+.08,.04,bz+.12)],'#617f7f',sc*.02);L(g,[pr(bx+.52,.23,bz+.12),pr(bx+.52,.04,bz+.12)],'#617f7f',sc*.02)
   }
   let ps=pr(x1-.12,.85,z1+.08);L(g,[pr(x1-.12,.03,z1+.08),ps],'#bfd1b1',sc*.025);E(g,...ps,sc*.084,sc*.064,'#e2ac80','#c9c49d',.9);
   if(shade>.02){
    const A=corners[0],B=corners[1],C=corners[2],F=corners[3];
    const interpolate=(a,b,q)=>a.map((v,i)=>v+(b[i]-v)*q),BB=interpolate(A,B,shade),CC=interpolate(F,C,shade);
    const sa=pr(...A),sb=pr(...BB),sf=pr(...F),scn=pr(...CC),mid=pr((A[0]+BB[0]+CC[0]+F[0])/4,1.08+(1-shade)*.20,(A[2]+BB[2]+CC[2]+F[2])/4);
    polygon(g,[pr(A[0]+.22,.04,A[2]+.15),pr(BB[0]+.22,.04,BB[2]+.15),pr(CC[0]+.22,.04,CC[2]+.15),pr(F[0]+.22,.04,F[2]+.15)],'rgba(38,76,90,.40)');
    polygon(g,[sa,sb,mid],G(g,sa[0],sa[1],mid[0],mid[1],[[0,'#f2c690'],[1,'#cad3b1']]),'#b7c6ac',1.2);
    polygon(g,[sb,scn,mid],'#94bdb4','#a9c7b7',.85);polygon(g,[scn,sf,mid],'#bed2b7','#adc6b4',.75);polygon(g,[sf,sa,mid],'#dcc599','#b8bc9c',.85);
    L(g,[sa,mid,scn],'rgba(248,227,181,.77)',1.04);
   }
   continue
 }
 let {X,Z,w:ww,d,ht,seed,therm}=o;let x=X-ww*.5,X2=X+ww*.5,z=Z-d*.5,Z2=Z+d*.5;
 let within=Math.exp(-((X-focusX)**2/3.4+(Z-focusZ)**2/3.0)),k=clamp(therm*(.95+.08*Math.sin(t*.7+Z*.5))*(1-.96*within*shade)),scale=clamp((depth(X,Z)+6)/15);
 let A=pr(x,0,z),B=pr(X2,0,z),C=pr(X2,0,Z2),F=pr(x,0,Z2),aa=pr(x,ht,z),bb=pr(X2,ht,z),cc=pr(X2,ht,Z2),ff=pr(x,ht,Z2);
 polygon(g,[A,B,C,F],'rgba(9,24,32,.20)');
 polygon(g,[F,C,cc,ff],color([65,105,112],[170,119,98],k),'rgba(24,43,55,.65)',.7);
 polygon(g,[A,F,ff,aa],color([48,78,91],[117,83,82],k),'rgba(23,43,53,.52)',.7);
 polygon(g,[aa,bb,cc,ff],color([108+seed*17,160+seed*14,161+seed*12],[248,148,98],k),'rgba(193,214,177,.42)',.85);
 // Ordinary pitched roofs and equipment survive even in the abstract forecast.
 if(seed<.38&&ht<1.0){let rr=ht+.14+seed*.12;polygon(g,[aa,bb,pr(X2,rr,Z),pr(x,rr,Z)],color([126,174,173],[249,161,110],k),'rgba(134,165,157,.59)',.68);polygon(g,[cc,ff,pr(x,rr,Z),pr(X2,rr,Z)],color([82,127,137],[177,112,86],k),'rgba(32,67,77,.5)',.55)}
 if(within>.20&&shade>.1){let k2=within*shade;let pp=pr(X,ht+.028,Z);E(g,...pp,.18*sc,.083*sc,'rgba(128,223,207,'+(.12+.55*k2)+')')}
 
 if(ht>.62&&seed>.23){for(let y=.17;y<ht-.08;y+=.21){L(g,[pr(x+.035,y,Z2),pr(X2-.035,y,Z2)],'rgba(207,236,199,.51)',.85)}}
 if(seed>.65&&ht>.48){let ry=ht+.11;polygon(g,[pr(x+.10,ry,z+.13),pr(X2-.10,ry,z+.13),pr(X2-.10,ry,Z2-.18),pr(x+.10,ry,Z2-.18)],'rgba(58,90,99,.61)')}
 }
 // Seven modeled wind fields, never presented as a certainty.
 for(let k=0;k<9;k++){let pts=[];for(let n=0;n<135;n++){let x=-13+n*.195,z=-7+k*1.12+Math.sin(x*.39+k*.33+t*.11)*.77,y=1.9+1.3*Math.exp(-((x-1.6)*(x-1.6)/22+(z-2)*(z-2)/16))+.18*Math.cos(x*.55+k*.7);pts.push(pr(x,y,z))}
 L(g,pts,'rgba(128,209,201,'+(.20+.10*Math.cos(k))+')',Math.max(1.2,w/930));let q=Math.floor((t*12+k*17)%114);L(g,pts.slice(q,q+11),'rgba(196,233,200,.75)',Math.max(1.4,w/715))}
 // Visible, evolving convection at the vulnerable plaza, not just an arbitrary color change.
 for(let u=0;u<3;u++){let pts=[];for(let i=0;i<47;i++){let f=i/46,y=.28+f*(2.2-shade*.65),a=f*4+u*2.1+t*.56,rad=.12+.3*f,x=focusX+Math.cos(a)*rad+f*(.31+.43*shade),z=focusZ+Math.sin(a)*rad+f*.23;pts.push(pr(x,y,z))}
 let A=(.22+.16*(1-shade));L(g,pts,shade>.5?'rgba(167,221,208,'+A+')':'rgba(251,179,109,'+A+')',Math.max(1.1,sc*.016));
 let j=Math.floor((t*10+u*13)%34);L(g,pts.slice(j,j+7),'rgba(246,222,166,.69)',Math.max(1.3,sc*.020))}
 let pin=pr(focusX,.29,focusZ);
 locator(g,...pin,sc*(1.28+.043*Math.sin(t*1.8)),t,'FERRY STEPS',1,.42,shade>.50?'#bdddc2':'#edbb86');
 for(let j=0;j<2;j++){let q=(t*.46+j*.5)%1;E(g,...pin,sc*(.34+q*.79),sc*(.16+q*.31),null,'rgba(244,192,139,'+(1-q)*.58+')',1.4)}
 
 // Sparse projection border has no UI buttons, keeping the model tactile.
 const tx=w*.060,ty=h*(pt?.075:.074),tw=w*(pt?.46:.28),th=h*(pt?.115:.112),state=shade>.5?'WITH SHADE':'NO SHADE';
 Rbox: {g.fillStyle='rgba(17,35,45,.77)';g.fillRect(tx,ty,tw,th);g.fillStyle=shade>.5?'#97c7b7':'#d39b74';g.fillRect(tx,ty,Math.max(3,w*.003),th);
 const pad=w*(pt?.016:.012);T(g,'BLOCK HEAT SIMULATION',tx+pad,ty+th*.30,Math.max(13,Math.min(w*.019,h*.023)),'#bfd4c2','Noto Sans',560);
 T(g,state,tx+pad,ty+th*.79,Math.max(26,Math.min(w*.043,h*.048)),'#f2e7c9','Noto Sans',690);}
 
}
})();
