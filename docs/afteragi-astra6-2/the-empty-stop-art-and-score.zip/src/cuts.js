// Edit decision list. Every story frame 0..959 belongs to exactly one shot.
// Nominal seconds preserve cue intent; native 24fps firstFrame is the actual cut used by stage and QA.
window.FILM_CUTS=[
 ['heat',0,'warm'],['stopped-fan',2.82,'warm'],['repair-wide',5.15,'warm'],['tutor-lens',6.77,'cool'],
 ['latch',8.04,'warm'],['ribbon-lifts',9.72,'warm'],['first-breeze',10.36,'warm'],['missed-stop',12.25,'warm'],['dispatcher',15.40,'cool'],
 ['suggestion',17.81,'cool'],['paper-at-home',19.90,'warm'],['grandpa-asks',21.49,'warm'],['blank-spot',22.78,'warm'],
 ['possible-orbit',26.30,'space'],['shade-scenario',28.64,'space'],['human-decision',31.90,'cool'],['manual-stop',32.76,'cool'],
 ['bus-returns',34.02,'night'],['on-the-step',34.60,'night'],['saved-stool',35.57,'night'],['shared-room',37.00,'night']
].map(([id,nominal,grade])=>({id,nominal,frame:Math.ceil(nominal*24-1e-7),grade}));
