/* First Light — The returning breeze. Transparent, analytic, frame-order independent. */
(()=>{
'use strict';
let c;
function G(x,y,u,v,stops){let q=c.createLinearGradient(x,y,u,v);for(let i=0;i<stops.length;i++)if(Array.isArray(stops[i]))q.addColorStop(stops[i][0],stops[i][1]);else q.addColorStop(i/(stops.length-1),stops[i]);return q}
function S(path,f,s,n=1){const p=new Path2D(path);if(f){c.fillStyle=f;c.fill(p)}if(s){c.strokeStyle=s;c.lineWidth=n;c.lineCap='round';c.lineJoin='round';c.stroke(p)}return p}
function E(x,y,rx,ry,f,s,n=1){c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);if(f){c.fillStyle=f;c.fill()}if(s){c.lineWidth=n;c.strokeStyle=s;c.stroke()}}
function L(a,s,n=1){c.beginPath();c.moveTo(a[0],a[1]);for(let i=2;i<a.length;i+=2)c.lineTo(a[i],a[i+1]);c.lineWidth=n;c.strokeStyle=s;c.lineCap='round';c.lineJoin='round';c.stroke()}
function textGrain(j){return Math.sin(j*127.1+14.87)*43758.5453%1+.5}
function cnoise(i){let v=textGrain(i);return v-Math.floor(v)}
function smooth(a,b,t){let u=Math.max(0,Math.min(1,(t-a)/(b-a)));return u*u*(3-2*u)}
function key(t,rows){let j=0;for(;j+1<rows.length&&t>rows[j+1][0];j++);if(j===rows.length-1)return rows[j][1];let a=rows[j],b=rows[j+1],u=smooth(a[0],b[0],t);return a[1]+(b[1]-a[1])*u}
const dome='M -74 111 C -67 103 -63 83 -60 66 C -54 39 -44 21 -28 11 C -22 7 -13 5 -9 3 C -5 -2 7 -2 12 3 C 18 7 30 10 39 20 C 53 36 59 59 61 79 C 64 94 66 101 75 110 C 84 120 65 130 6 131 C -42 132 -83 126 -74 111 Z';
function glow(x,y,rx,ry,col){c.save();c.translate(x,y);c.scale(rx,ry);let g=c.createRadialGradient(0,0,0,0,0,1);g.addColorStop(0,col);g.addColorStop(1,'rgba(0,0,0,0)');c.beginPath();c.ellipse(0,0,1,1,0,0,7);c.fillStyle=g;c.fill();c.restore()}
function glassFar(t,twist){
 // The original casing's concave turquoise lip is split into its far and near surfaces.
 S(dome,G(-75,18,82,111,[[0,'#254e6366'],[.23,'#699faaa1'],[.49,'#babd902b'],[.73,'#e9c99943'],[1,'#9dc9b1a4']]),'#537587',1.15);
 c.save();c.clip(new Path2D(dome));
 E(6,106,75,15,'#374f5b36','#93b6a6b6',.85);
 E(6,105,66,10,'#9dc2ad1f','#b08b64a0',.5);
 // A bowed image of the bakery plaster, slate windows and sunset reverses in the blown lens.
 S('M -62 55 C -47 51 -42 48 -36 43 C -27 38 -32 38 -24 31 C -19 28 -14 31 -11 25 C -6 24 2 29 7 24 C 18 25 25 31 34 30 C 50 33 59 40 62 49 L 70 88 C 60 80 55 78 49 73 C 39 73 27 66 19 69 C 12 64 6 67 -4 59 C -10 64 -16 58 -23 63 C -32 68 -42 64 -51 76 L -68 89 Z',G(12,32,-9,82,['#ffd59a34','#edaa7852','#d5a99428','#cbc4a942']));
 S('M -69 79 C -56 73 -54 71 -45 64 C -34 58 -22 65 -14 60 C -1 55 8 60 14 61 C 22 62 25 61 34 65 C 38 66 43 72 55 70 C 58 71 68 83 70 84 L 73 91 C 69 90 60 82 56 80 C 43 82 39 75 30 75 C 20 72 14 74 10 69 C -2 70 -10 62 -16 66 C -28 68 -33 64 -43 72 C -49 72 -57 80 -69 84 Z','#fece8c82');
 S('M -65 88 C -55 82 -48 79 -36 79 C -23 69 -12 76 -6 74 C 3 71 8 77 16 76 C 24 76 40 88 49 88 C 60 91 64 96 76 100 L 76 103 C 59 102 51 95 47 95 C 36 97 22 85 15 87 C 4 82 -8 86 -16 83 C -26 84 -40 85 -51 92 L -68 100 Z','#5e829d7b');
 S('M -63 98 C -45 92 -32 91 -22 93 C -11 88 -3 83 7 85 C 16 92 22 89 31 94 C 45 103 61 100 76 109 L 76 119 C 32 118 -20 123 -68 118 Z','#7bb1ab48');
 for(let j=0;j<9;j++){let x=-48+11.8*j,yy=78+7*Math.sin(j/2.2)+cnoise(j+224)*3;
 S('M '+x+' '+yy+' Q '+(x*1.08-1)+' '+(yy+9)+' '+(x*1.10+2)+' '+(yy+17),null,j%3?'#8d9d9b70':'#e7ca9278',.52)}
 let pd=1.9*Math.sin(t*.65+1)+twist*15;
 S('M '+(-45+pd)+' 105 C '+(-39+pd)+' 82 '+(-45+pd)+' 77 '+(-39+pd)+' 52 C '+(-36+pd)+' 32 '+(-24+pd)+' 18 '+(-14+pd)+' 13 C '+(-20+pd)+' 25 '+(-20+pd)+' 46 '+(-24+pd)+' 53 C '+(-30+pd)+' 71 '+(-17+pd)+' 99 '+(-28+pd)+' 109 C '+(-36+pd)+' 115 '+(-41+pd)+' 109 '+(-45+pd)+' 105 Z',G(-40,35,-21,103,['#ebefbf6e','#f9f0c89c','#cae6be20','#d9e3b974']));
 S('M -54 104 C -49 94 -46 86 -46 76 C -44 85 -45 96 -37 104 L -34 114 C -45 122 -61 115 -54 104 Z','#45658284');
 S('M -30 101 C -26 93 -22 86 -27 78 C -31 64 -21 56 -20 47 C -20 36 -14 27 -7 20 C -7 34 -12 38 -10 51 C -13 67 -12 83 -7 89 L -9 108 C -12 112 -23 110 -30 101 Z','#5079945e');
 S('M 18 13 C 37 25 46 34 50 53 C 53 71 54 92 65 106 C 60 109 55 111 49 110 C 40 87 38 83 41 67 C 43 56 35 34 29 28 C 23 20 22 19 18 13 Z',G(20,21,62,108,['#e8dcbf7e','#faedc17d','#c6ddd857','#f3dbab94']));
 for(let i=0;i<55;i++){let x=-54+cnoise(i+40)*113,y=22+cnoise(i+817)*91,sz=cnoise(i+41),a=i%3;E(x,y,.28+sz*1.14,.23+cnoise(i+198)*.78,a===2?'#517b926f':'#e9e9bd73');if(sz>.81)E(x+.17,y-.28,.41,.29,'#faf1d0a4')}
 for(let i=0;i<10;i++){let y=65+i*4.6;S('M -45 '+y+' Q -26 '+(y+6.2)+' -15 '+(y+3),null,'#fbe5b625',.58)}
 c.restore();
}
function copper(ax,ay,ang){
 c.save();c.translate(ax,ay);c.rotate(ang);
 S('M -2.8 -12 C -3.4 -10 -4 -8 -1 -7 L 2 -8 C 4 -13 -1 -15 -2.8 -12 Z',null,'#c8a985',.85);
 S('M -2.4 -9 L 2.3 -9 L 2 2 C 5 2 8.6 4.5 9 8 C 10.5 13.5 6.5 17 -2 16 C -10.2 15 -9.4 11 -8.7 7.8 C -8 3.3 -4 3 -3 1 Z',G(-8,1,9,14,['#815f53','#baa789','#9a7768','#514c50']),'#6a6155',.8);
 S('M -6.9 8 Q -4 3.8 -1 3 M -6.4 13 Q -4.1 15.3 1 14.4',null,'#ead4aa93',.83);
 E(-4.1,8.1,1.8,2.1,'#d8baa080'); E(4.8,10.9,2.2,2.4,'#745d57');
 c.restore()
}
function glassNear(t,tilt){
 // Broken white along the irregular handmade edge. Various widths read as glass, not chrome.
 S('M -67 106 C -62 98 -61 87 -59 78 C -55 60 -53 40 -42 28 C -34 17 -28 15 -20 11',null,'#e5efd1ce',1.4);
 S('M -57 81 C -54 63 -50 41 -45 35 C -40 25 -35 23 -32 22',null,'#f4f2cbd9',.75);
 S('M 18 9 C 30 13 38 20 44 28 C 50 37 55 53 57 74 C 58 85 62 98 70 107',null,'#f7ebc7b9',1.26);
 S('M 46 38 C 52 48 50 49 54 62 M 60 86 Q 61 97 65 101',null,'#ffefc4d7',.73);
 S('M -12 6 Q -5 1 0 3 Q 6 1 12 5',null,'#edeec5d9',1.55);
 S('M -69 110 C -46 101 -25 105 4 102 C 34 101 60 104 72 110 C 86 120 61 127 8 129 C -41 130 -76 126 -75 118 Q -76 114 -69 110 Z',G(-62,107,68,127,['#4e889c71','#85a7a768','#bfb78b4a','#b8a97a63']),'#8ab2aec4',1.15);
 E(2,116,75,13.1,null,'#d0dcbe90',.84);
 S('M -75 118 Q -69 128 -17 129 C 21 132 63 127 74 120',null,'#eeedd1df',1.3);
 S('M -64 122 Q -38 130 -4 128 M 8 128 Q 34 128 59 124',null,'#f4dfb6d9',.72);
 S('M -57 113 Q -12 105 15 108 M 43 107 Q 63 107 75 116',null,'#d7ecd1b1',1.05);
 S('M -65 125 Q -52 130 -45 129 M 54 126 Q 61 126 67 123',null,'#395e768b',.9);
 // One small glint migrates with the pane; broad caustic stays softly integrated.
 const glint=15+4*Math.sin(t*1.1)+tilt*12;
 glow(glint,11,9,9,'rgba(250,219,167,.32)');E(glint,11,1.3,.95,'#f3ebc9');
 S('M -37 118 Q -28 120 -20 120',null,'#f7f1c9c2',.66);
}
function latheGrain(t){ // tiny glass-bubble lenses and joined-tool marks survive the bright rim
 const ghosts=[[-39,55,1.61],[-30,70,1.2],[-25,90,.89],[23,46,1.51],[38,73,2.01],[46,89,.75],[17,80,1.18],[-38,94,1.16],[50,96,1.2],[-48,90,.81]];
 for(let [x,y,s] of ghosts){E(x,y,s,s*.82,'#d5e3b62b','#729c9a6d',.42);S('M '+(x-s*.56)+' '+(y+.23)+' Q '+(x-s*.4)+' '+(y-s*.63)+' '+(x+.26)+' '+(y-s*.53),null,'#f1efc599',.40)}
 S('M -46 33 Q -50 41 -51 47 M -54 63 L -55 66 M 38 27 Q 39 29 39 30 M 55 78 Q 55 81 56 83',null,'#fbf4cdc0',.44);
 S('M -60 119 Q -57 121 -52 122 M -6 132 Q 1 131 7 131 M 27 130 Q 36 129 42 128 M 64 117 Q 66 115 70 117',null,'#90a99ca0',.54);
 const vx=36+.49*Math.sin(t*2.15);
 S('M '+vx+' 53 Q '+(vx+3)+' 61 '+(vx+2)+' 68',null,'#eedcb8a3',.52);
}
function hangingTag(px,py,length,angle,twist,ripple){
 c.save();c.translate(px,py);c.rotate(angle);c.scale(Math.max(.35,1-Math.abs(twist)*.52),1);
 const bend=ripple*8,wx=13.6,cy=length*.50,yy=length;
 const rim='M -10 -2 C -4 1 0 -1 5 -2 Q 10 -3 14 1 Q '+(13+bend*.12)+' '+(cy*.60)+' '+(10+bend*.43)+' '+(cy*.97)+' C '+(10+bend*.82)+' '+(yy*.74)+' '+(16+bend*.88)+' '+(yy*.86)+' '+(16+bend)+' '+(yy*.96)+' C '+(11+bend)+' '+(yy*1.019)+' '+(2+bend*.90)+' '+(yy*1.008)+' '+(-10+bend*.85)+' '+(yy*.99)+' Q '+(-14+bend*.43)+' '+(yy*.83)+' '+(-11+bend*.30)+' '+(yy*.59)+' C -10 '+(cy*.81)+' -8 '+(cy*.40)+' -10 -2 Z';
 S(rim,G(-wx,0,16+bend,yy,[[0,'#a26557'],[.3,'#d49a76'],[.53,'#e3b682'],[.77,'#c48a6c'],[1,'#af7665']]),'#765f59',.95);
 c.save();c.clip(new Path2D(rim));
 S('M -9 2 Q -5 '+(cy*.46)+' '+(-8+bend*.20)+' '+(cy*.89)+' Q '+(-10+bend*.39)+' '+(yy*.78)+' '+(-2+bend*.62)+' '+(yy+4)+' L '+(5+bend*.70)+' '+(yy+4)+' Q '+(-4+bend*.52)+' '+(yy*.78)+' '+(-4+bend*.30)+' '+cy+' Q '+(-2+bend*.19)+' '+(cy*.35)+' -5 2 Z','#f2ca997d');
 S('M 8 0 C '+(11+bend*.23)+' '+(cy*.62)+' '+(5+bend*.43)+' '+(cy*.94)+' '+(5+bend*.53)+' '+(yy*.65)+' Q '+(6+bend*.52)+' '+(yy*.89)+' '+(9+bend*.93)+' '+(yy+3)+' L '+(18+bend)+' '+(yy+4)+' L '+(21+bend)+' 0 Z','#985d543f');
 S('M -1 '+(cy*.40)+' Q '+(-4+bend*.16)+' '+(cy*.68)+' '+(-2+bend*.23)+' '+cy+' Q '+(-2+bend*.27)+' '+(yy*.61)+' '+(1+bend*.40)+' '+(yy*.735),null,'#a8685966',.65);
 for(let i=0;i<43;i++){const y=3+cnoise(i+924)*(yy-3),x=-12+cnoise(i+15)*28+(y/yy)**1.8*bend,sz=.30+cnoise(i+617)*2.9;L([x,y,x+sz,y+cnoise(i+54)*.58],i%3?'#794e402f':'#f4d7a77d',.39+cnoise(i+73)*.25)}
 c.restore();
 E(1,3.3,2.3,2.5,'#785b58','#e3ba88',.62);S('M 1 1.4 Q 2.5 1.8 2.2 3.6',null,'#bcaa88',.77);
 S('M '+(-9+bend*.85)+' '+(yy*.985)+' Q '+(3+bend*.90)+' '+(yy*1.015)+' '+(15+bend)+' '+(yy*.967),null,'#ecc190',.8);
 c.restore()
}
window.bellClose=function(ctx,w,h,t){
 if(!(w>0&&h>0))return;t=Math.max(0,Math.min(2.2,Number(t)||0));const tall=w<h,s=Math.min(w*(tall?.34:.22)/152,h*.00250),ax=w*(tall?.728:.735),top=h*(tall?.241:.228);
 // A single offscreen gust first moves the paper. The heavier glass and the striker lag, then settle.
 const lean=key(t,[[0,-.009],[.19,-.013],[.33,.015],[.56,.081],[.80,.061],[1.01,-.029],[1.22,-.052],[1.47,.018],[1.69,.022],[1.89,-.011],[2.2,.002]]);
 const tail=key(t,[[0,-.014],[.12,-.015],[.29,-.105],[.53,-.37],[.66,-.27],[.88,.11],[1.10,.22],[1.27,.10],[1.51,-.13],[1.68,-.081],[1.91,.028],[2.2,-.012]]);
 const yaw=key(t,[[0,.016],[.22,.014],[.43,.125],[.59,.38],[.73,.11],[.91,-.31],[1.09,-.34],[1.30,.20],[1.46,.17],[1.69,-.15],[1.91,.06],[2.2,.015]]);
 const strike=key(t,[[0,-.026],[.3,-.026],[.50,-.169],[.68,-.19],[.90,.146],[1.09,.154],[1.33,-.10],[1.5,-.056],[1.69,.061],[1.91,-.024],[2.2,.005]]);
 const endX=ax-s*lean*63,endY=top-s*1.8+Math.abs(lean)*s*10;
 const midY=endY*.45, mountX=ax+2.0*s;
 c=ctx;c.save();
 // Long, non-stretch cotton and a dark knot, warm bevel exposed to the sunset.
 const rope='M '+mountX+' -3 Q '+(mountX-lean*s*9)+' '+midY+' '+endX+' '+endY;
 S(rope,null,'#384e56b9',s*1.54);
 S('M '+(mountX+.62*s)+' -3 Q '+(mountX-lean*s*9+.65*s)+' '+midY+' '+(endX+.57*s)+' '+endY,null,'#c5ab87be',s*.60);
 c.save();c.translate(endX,endY);c.rotate(lean);c.scale(s*(1-lean*.30),s);
 S('M -2 -10 Q -6 -7 -2 -4 Q -5 -2 -1 1 Q 1 5 4 1 Q 4 -4 1 -5 L 1 -8 Q 1 -11 -2 -10 Z','#705d54','#c1a58c',.55);
 S('M -2.3 -6 L 1.5 -5 M -2.8 -3 L 2.2 -2',null,'#ead1a3a6',.48);
 glassFar(t,lean);
 const bx=3+strike*56,by=100+Math.abs(strike)*4,tx=bx+(tail*.29+strike*.2)*31,ty=149;
 S('M 0 4 Q '+(bx*.66)+' 52 '+bx+' '+(by-3),null,'#575e5cbe',1.1);
 S('M 1 6 Q '+(bx*.68+.67)+' 44 '+(bx+.67)+' '+(by-5),null,'#b3a481af',.54);
 copper(bx,by,strike*.50);
 S('M '+(bx-.1)+' '+(by+14)+' Q '+(tx-.9)+' 130 '+tx+' '+ty,null,'#77715fc6',1.15);
 S('M '+(bx+.7)+' '+(by+14)+' Q '+(tx-.2)+' 131 '+(tx+.65)+' '+ty,null,'#c6ad8bb9',.47);
 hangingTag(tx,ty,tall?108:62,tail,yaw,Math.sin(t*7.2+.49)*(.03+.23*smooth(.12,.36,t)*(1-smooth(1.1,2.18,t)))+yaw*.43);
 glassNear(t,lean);latheGrain(t);
 c.restore();c.restore();
};
})();

