// Native-pixel type design and libass editorial finishing. Nothing here changes frame timing.
import fs from 'node:fs';
export const subtitles=[
 [.32,4.64,'The first summer after AGI, our old fan stopped.'],
 [5.17,7.93,'I’d never fixed one. My AI tutor watched my hands.'],
 [8.05,10.25,'“Close the latch. Then try it.”'],
 [10.44,12.14,'Cold air. On my face.'],
 [12.38,15.36,'The same system planned the city’s cooling buses.'],
 [15.62,19.72,'Mum’s new route would save twelve minutes.'],
 [20.02,22.71,'Grandpa asked, “Where’s my stop?”'],
 [22.96,26.14,'His street had no sensor. It still had people.'],
 [26.47,29.28,'One day, a superintelligence might model every street.'],
 [29.43,32.63,'The city would still have to choose whom to serve.'],
 [32.84,35.45,'Mum restored our stop. We opened a cooling room.'],
 [35.69,39.82,'Grandpa saved me a seat.']
];
const ct=t=>{let n=Math.round(t*100);return Math.floor(n/360000)+':'+String(Math.floor(n/6000)%60).padStart(2,'0')+':'+String(Math.floor(n/100)%60).padStart(2,'0')+'.'+String(n%100).padStart(2,'0')};
const esc=s=>s.replaceAll('{','(').replaceAll('}',')').replaceAll('\n','\\N');
const rows=s=>s.split('\n').length;
const wrap=(s,l)=>{let words=s.split(' '),a=[''];for(let w of words){let i=a.length-1;if(a[i]&&a[i].length+w.length+1>l)a.push(w);else a[i]+=((a[i]?' ':'')+w)}return a.join('\n')};
export function makeASS(w,h,opts={}){
 const p=h>w,band=p?118:105,H=h-band,hr=opts.hours||'0.00',passes=opts.passes||[],finalPass=opts.finalPass||passes.at(-1)||{n:'04',min:'0.0',name:'FINAL FRAME'};
 let txt='[Script Info]\nScriptType: v4.00+\nWrapStyle: 2\nScaledBorderAndShadow: yes\nPlayResX: '+w+'\nPlayResY: '+h+'\nYCbCr Matrix: TV.709\n\n[V4+ Styles]\nFormat: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\n';
 const style=(n,font,sz,color,outline='&H001C1A1A',lw=0,shadow=0,b=false,align=7,space=0)=>{txt+='Style: '+[n,font,sz,color,'&H00FFFFFF',outline,'&H58101116',b?-1:0,0,0,0,100,100,space,0,1,lw,shadow,align,0,0,0,1].join(',')+'\n'};
 style('Brand','Noto Sans',50,'&H00FFFFFF','&H00000000',0,0,true,7);
 style('Credit','Noto Sans',p?28:25,'&H00D2D5D2','&H00000000',0,0,false,7,0.20);
 style('Hours','Noto Sans',p?28:25,'&H00FFFFFF','&H00000000',0,0,false,9,.14);
 style('Caption','Noto Sans',p?44:44,'&H00FAF7EF','&H00221D1B',2.5,1,false,2,0);
 style('Process','Noto Sans',p?33:34,'&H00FFF2DA','&H00201E1C',1.2,.5,true,7);
 style('Number','Noto Sans',p?60:61,'&H00FFFFFF','&H00201E1C',1.55,1,true,7);
 style('Panel','Noto Sans',12,'&H00000000');txt+='\n[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n';
 const ev=(a,b,sty,t,l=0)=>{txt+='Dialogue: '+[l,ct(a),ct(b),sty,'',0,0,0,'',t].join(',')+'\n'};
 const pos=(x,y)=>'\\pos('+Math.round(x)+','+Math.round(y)+')';
 const rect=(x,y,ww,hh,color,alpha='00')=>'{\\an7'+pos(x,y)+'\\p1\\bord0\\shad0\\1c&H'+color+'&\\1a&H'+alpha+'&}m 0 0 l '+Math.round(ww)+' 0 '+Math.round(ww)+' '+Math.round(hh)+' 0 '+Math.round(hh)+'{\\p0}';
 ev(0,60,'Panel',rect(0,H,w,band,'000000'),0);
 const pad=p?42:55;
 ev(0,60,'Brand','{'+pos(pad,H+(p?6:3))+'}GPT-6.2 Astra',4);
 ev(0,60,'Credit','{'+pos(pad,H+(p?63:59))+'}OpenAI Dot  /  Wtruby  /  Canvas 2D + FFmpeg',4);
 ev(0,60,'Hours','{'+pos(w-pad,H+(p?63:59))+'}'+esc(hr)+' h',4);
 for(let [a,b,s] of subtitles){
  const lines={
 'The first summer after AGI, our old fan stopped.':'The first summer after AGI,\nour old fan stopped.',
 'I’d never fixed one. My AI tutor watched my hands.':'I’d never fixed one.\nMy AI tutor watched my hands.',
 'The same system planned the city’s cooling buses.':'The same system planned\nthe city’s cooling buses.',
 'His street had no sensor. It still had people.':'His street had no sensor.\nIt still had people.',
 'One day, a superintelligence might model every street.':'One day, a superintelligence\nmight model every street.',
 'The city would still have to choose whom to serve.':'The city would still have to choose\nwhom to serve.',
 'Mum restored our stop. We opened a cooling room.':'Mum restored our stop.\nWe opened a cooling room.'};
 let st=p?(lines[s]||wrap(s,40)):s;const y=H-(p?55:39);
  ev(a,b,'Caption','{'+pos(w*.5,y)+'\\fad(90,85)}'+esc(st),4)
 }
 const iteration=(a,b,item,descriptor)=>{
  if(!item)return;
  const ix=w*(p?.055:.048),iy=H*(p?.061:.069),ph=p?129:126,pw=Math.min(w*.79,p?780:770);
  ev(a,b,'Panel',rect(ix-12,iy-7,pw,ph,'251E19','48'),2);
  ev(a,b,'Panel',rect(ix-12,iy-7,4,ph,'81B4E8','06'),3);
  ev(a,b,'Process','{'+pos(ix+14,iy+1)+'}'+esc(descriptor),4);
  ev(a,b,'Number','{'+pos(ix+14,iy+(p?44:40))+'}ITERATION '+esc(String(item.n).padStart(2,'0'))+'    /    '+esc(item.min)+' MIN',4)
 };
 if(passes.length){
  iteration(40,42,passes[0],'FIRST ITERATION   /   '+passes[0].name);
  const clips=opts.process||[];for(const c of clips)iteration(c.from,c.to,c.pass,'EVOLUTION   /   '+c.pass.name);
  // Keep the last landing clear after its identity has been stated.
  iteration(55,56.8,finalPass,'LAST ITERATION   /   FINISHED FILM')
 }
 return txt
}
if(import.meta.url===('file://'+process.argv[1])){let[w,h,file,opt]=process.argv.slice(2);fs.writeFileSync(file,makeASS(+w,+h,opt?JSON.parse(fs.readFileSync(opt)):{}))}
