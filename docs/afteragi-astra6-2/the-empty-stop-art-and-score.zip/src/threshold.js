// Close-view architecture of the repair shop, viewed from inside its newly opened doorway.
(() => {
const {path:P,line:L,ell:E,grad:G,radial:D,rr:RR,text:T,R,TAU,ease,clamp}=Art;
window.stool=(g,x,y,s,opt={})=>{
g.save();g.translate(x,y);g.scale(s,s);const wood=opt.blue?'#5b7a76':'#ae7957',edge='#594642';
E(g,3,23,52,8,'rgba(44,37,43,.25)');
for(let [a,b,c,d] of [[-33,-51,-44,22],[31,-51,43,22],[-20,-54,-28,11],[22,-54,28,11]]){
 P(g,'M '+(a-2)+' '+b+' L '+(a+4)+' '+b+' '+(c+3)+' '+d+' '+(c-3)+' '+d+' Z',wood,edge,1.6);
 L(g,[[a-1,b+1],[c-1,d-2]],'#c69c71',1)}
L(g,[[-37,-6],[37,-6]],edge,5);L(g,[[-37,-7],[37,-7]],'#a27c65',2);
P(g,'M -43 -55 L -35 -62 33 -61 44 -55 44 -48 Q 6 -43 -42 -50 Z',wood,edge,2);
P(g,'M -43 -55 L -35 -62 33 -61 44 -55 31 -52 -31 -53 Z','#d2a77a',edge,1.2);
L(g,[[-26,-57],[23,-56]],'#ba8d66',.8);g.restore()
};
window.threshold=(g,w,h,t,layer='back',opening=1,hideBell=false)=>{
 const pt=h>w,off=pt?.095:.12,unit=Math.min(w/1050,h/720),u=unit,open=ease(opening),rng=R(7103);
 if(layer==='back'){
 // Dark wooden floor gives the family a stage inside the room, not in the road.
 const fy=h*(pt?.735:.712);g.fillStyle=G(g,0,fy,w*.28,h,[[0,'#937662'],[.11,'#c5a17d'],[.33,'#92745f'],[1,'#624e48']]);g.fillRect(0,fy,w,h-fy);
 P(g,'M 0 '+(fy+h*.009)+' L '+w+' '+(fy-h*.002)+' '+w+' '+(fy+h*.011)+' 0 '+(fy+h*.029)+' Z','#d7b789');
 // Parallel grain, nail heads and seams converge on the open street.
 let vanX=w*.43,vanY=h*.53;
 for(let j=-11;j<16;j++){let xx=w*(j*.14+.03),xy=(xx-vanX)*(fy-vanY)/(h-vanY)+vanX;L(g,[[xy,fy+h*.008],[xx,h]],'rgba(68,50,48,.52)',2*u);L(g,[[xy+u,fy+h*.010],[xx+3*u,h]],'rgba(238,193,142,.48)',1.35*u)}
 for(let j=0;j<105;j++){let yy=fy+(h-fy)*rng(),xx=w*rng(),l=(.01+rng()*.045)*w;L(g,[[xx,yy],[xx+l,yy-u*.2]],rng()>.55?'rgba(244,208,160,.15)':'rgba(72,54,54,.19)',u*.72)}
 for(let j=0;j<6;j++){let yy=fy+((j*.237+.09)%1)*(h-fy);let sx=(j*.42%1)*w;L(g,[[sx,yy],[sx+w*.13,yy]],'rgba(61,48,47,.45)',u*1.3);E(g,sx+4*u,yy+3*u,1*u,.6*u,'rgba(55,47,48,.53)')}
 // Open inner jamb on left. Its warm lamp and quiet repair tools belong to the same shop.
 let l=w*(pt?.148:.205);
 g.fillStyle=G(g,0,0,l,h,[[0,'#434749'],[.45,'#4d4d49'],[.73,'#6c5a4a'],[1,'#7c674e']]);g.fillRect(0,0,l,fy);
 for(let k=0;k<7;k++){let yy=h*(.21+.075*k);L(g,[[0,yy],[l*.92,yy+5*u]],'rgba(34,45,51,.40)',2*u)}
 g.save();g.fillStyle=D(g,l*.48,h*.36,0,l*1.07,[[0,'rgba(253,182,104,.64)'],[.46,'rgba(226,150,88,.24)'],[1,'rgba(231,155,78,0)']]);g.fillRect(0,h*.13,l,h*.57);g.restore();
 let shelfX=l*.10,shelfW=l*.74;for(let k=0;k<3;k++){let yy=h*(.46+.083*k);g.fillStyle=k===0?'#a17c57':'#8b6d52';g.fillRect(shelfX,yy,shelfW,4.5*u);g.fillStyle='#434343';g.fillRect(shelfX,yy+5*u,shelfW,4*u);for(let i=0;i<4;i++){let xx=shelfX+(i+.15)*shelfW/4,hh=(9+rng()*13)*u;RR(g,xx,yy-hh,shelfW*.13,hh,1.5*u,['#887461','#9b9381','#8c6d5e','#ad9c79'][i]);L(g,[[xx,yy-hh+3*u],[xx+shelfW*.12,yy-hh+3*u]],'#d8b988',u*.65)}}
 // Hinge jamb with brass latch, warm light slit, exact foreground contact.
 g.fillStyle='#3e4142';g.fillRect(l-u*13,0,13*u,fy+8*u);g.fillStyle='#8e7157';g.fillRect(l-9*u,0,4*u,fy);g.fillStyle='#d6ac77';g.fillRect(l-4*u,0,2*u,fy);
 RR(g,l-12*u,h*.57,10*u,25*u,2*u,'#977b57','#4b4c48',1*u);
 // Cool mat; woven diamond lines, edge fray. Keep free seat distinctly visible.
 let mx=w*(pt?.20:.29),my=h*.81,mw=w*(pt?.62:.42),mh=h*.075;
 P(g,'M '+mx+' '+my+' l '+mw+' '+(-mh*.14)+' '+(mw*.04)+' '+mh+' '+(-mw*1.10)+' '+(mh*.19)+' Z','#687970','#605f53',u);
 for(let j=0;j<19;j++){let a=j/18;L(g,[[mx+mw*a,my],[mx+mw*a+mw*.025,my+mh*.85]],'rgba(190,177,137,.23)',u*.7)}
 } else if(layer==='front'){
 // Close hanging fabric and a handmade glass wind bell; different arc lengths and phases.
 const roof=h*(pt?.105:.11),jamb=w*(pt?.038:.043);
 P(g,'M 0 0 L '+w+' 0 '+w+' '+(roof*.76)+' '+(w*.58)+' '+(roof*1.04)+' 0 '+(roof*.96)+' Z','#303b43');
 P(g,'M 0 '+(roof*.76)+' L '+w+' '+(roof*.57)+' '+w+' '+(roof*.75)+' 0 '+roof+' Z','#715e50');
 L(g,[[0,roof*.84],[w,roof*.66]],'#b48d66',1.6*u);
 g.fillStyle='#41484b';g.fillRect(w-jamb,0,jamb,h*.77);g.fillStyle='#ab8460';g.fillRect(w-jamb,roof*.6,2.2*u,h*.68);
 // Partial sunlit split noren, opening preserves center focal area.
 let n=w*(pt?.27:.25);for(let j=0;j<3;j++){let xx=j*n*.325,ww=n*.32,fly=(.045+.045*ease((t-.48)/1.53))*ww*Math.sin(t*1.58+j*.83),drop=h*(.13+.019*Math.cos(t*.82+j*.75)),yy=roof*.73,lp=xx+fly,rp=xx+ww+fly*.66,by=yy+drop;
 P(g,'M '+xx+' '+yy+' L '+(xx+ww)+' '+(yy-2*u)+' Q '+(xx+ww+fly*.06)+' '+(yy+drop*.48)+' '+rp+' '+(by-2*u)+' Q '+(xx+ww*.50+fly*.78)+' '+(by+4*u)+' '+lp+' '+(by-4*u)+' Q '+(xx+fly*.18)+' '+(yy+drop*.45)+' '+xx+' '+yy+' Z',G(g,xx,yy,xx+ww,by,[[0,j===1?'#435a64':'#536974'],[.32,'#526c75'],[.61,'#6a8081'],[1,'#526870']]),'#384b55',1.2*u);
 for(let i=0;i<6;i++){let a=.10+i*.151;P(g,'M '+(xx+ww*a)+' '+(yy+3*u)+' Q '+(xx+ww*a+fly*.10)+' '+(yy+drop*.47)+' '+(xx+ww*a+fly*(1-.24*a))+' '+(by-5*u),null,'rgba(225,207,165,.18)',.62*u)}
 let px=xx+ww*.48+fly*.68,py=yy+drop*.66,markW=ww*.26;
 for(let k=0;k<2;k++)P(g,'M '+(px-markW)+' '+(py+k*4*u)+' q '+(markW*.45)+' '+(8*u)+' '+markW+' 0 q '+(markW*.44)+' '+(7*u)+' '+markW+' '+(-2*u),null,'rgba(232,220,183,.66)',1.16*u);
 L(g,[[lp+3*u,by-7*u],[rp-3*u,by-5*u]],'rgba(211,195,160,.29)',.70*u)
 }
 // Thin visible lift of lower shutter before the family is revealed.
 if(open<.995){let bottom=roof+(1-open)*h*.56;g.fillStyle=G(g,0,roof,0,bottom,[[0,'#555b59'],[1,'#647070']]);g.fillRect(n,roof,w-n-jamb,bottom-roof);for(let yy=roof;yy<bottom;yy+=17*u){L(g,[[n,yy],[w-jamb,yy]],'#46545a',1.4*u);L(g,[[n,yy+2*u],[w-jamb,yy+2*u]],'#929b8f',.8*u)}}
 if(hideBell)return;let bx=w*(pt?.856:.884),by=roof*.71;g.save();g.translate(bx,by);g.rotate(.068*Math.sin(t*1.72)+.014*Math.sin(t*3.3));L(g,[[0,0],[1*u,31*u]],'#5c5e5b',1.45*u);
 P(g,'M -12 45 Q -11 33 0 32 Q 12 32 14 45 L 16 49 Q 2 56 -15 49 Z'.replace(/-?\d+(?:\.\d+)?/g,m=>''+(+m*u)),'rgba(188,213,198,.34)','#849c99',1.5*u);E(g,1*u,49*u,14.5*u,3.6*u,null,'#e6ddb0',1.1*u);
 L(g,[[1*u,37*u],[2*u,62*u]],'#c3ac85',u);E(g,2*u,53*u,2.5*u,3*u,'#c6966c');
 g.save();g.translate(2*u,61*u);g.rotate(.13*Math.sin(t*1.72+.8));P(g,'M 0 0 L '+(6*u)+' '+(-u)+' '+(8*u)+' '+(23*u)+' '+(u)+' '+(27*u)+' Z','#c59579','#746b62',.75*u);g.restore();g.restore();
 }
};
})();
