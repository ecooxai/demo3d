/* The Empty Stop — original close-up cels. No photography, external textures or mid-shot rig.
   The camera frames head and shoulder only; all marks remain relative to the native aperture. */
(()=>{
  'use strict';
  const paths=new Map(), PI=Math.PI;
  const clamp=x=>Math.max(0,Math.min(1,x));
  const ease=(a,b,t)=>{const s=clamp((t-a)/(b-a));return s*s*(3-2*s);};
  const path=d=>{if(!paths.has(d))paths.set(d,new Path2D(d));return paths.get(d);};
  const paint=(c,d,f,s,w=1)=>{const p=path(d);if(f){c.fillStyle=f;c.fill(p);}if(s){c.lineWidth=w;c.strokeStyle=s;c.stroke(p);}};
  const lin=(c,x,y,X,Y,stops)=>{const g=c.createLinearGradient(x,y,X,Y);stops.forEach(([p,k])=>g.addColorStop(p,k));return g;};
  const rad=(c,x,y,r,stops)=>{const g=c.createRadialGradient(x,y,0,x,y,r);stops.forEach(([p,k])=>g.addColorStop(p,k));return g;};
  const oval=(c,x,y,r,R,f,s,w=.75,tilt=0)=>{c.beginPath();c.ellipse(x,y,r,R,tilt,0,PI*2);if(f){c.fillStyle=f;c.fill()}if(s){c.strokeStyle=s;c.lineWidth=w;c.stroke()}};
  const stroke=(c,d,col,w=1)=>paint(c,d,null,col,w);
  const ink='#342736', sepia='#764c53', deepest='#212135';

  function coatTeen(c){
    const cloth=lin(c,-126,88,104,230,[[0,'#fff0cd'],[.28,'#f0dfbc'],[.62,'#cfba9f'],[1,'#948492']]);
    const bib=lin(c,-62,102,109,247,[[0,'#e29475'],[.37,'#b75c50'],[.72,'#9a4745'],[1,'#713c49']]);
    paint(c,'M -45 72 Q -54 77 -74 83 Q -101 90 -113 115 Q -132 155 -151 304 L 160 304 Q 144 186 121 123 Q 105 97 71 89 L 45 75Z',cloth,ink,2.15);
    paint(c,'M 50 86 Q 75 92 97 107 Q 110 117 117 143 L 146 302 L 160 303 Q 144 185 124 137 Q 113 101 79 95Z','#948795');
    paint(c,'M -103 112 Q -103 136 -90 160 Q -88 188 -103 231 L -122 303 L -151 303 Q -132 208 -121 156Z','#c5a891');
    paint(c,'M -51 89 L -38 96 L -43 170 L 55 176 L 49 94 L 65 89 L 75 143 Q 88 182 107 306 L -97 306 Q -63 184 -57 132Z',bib,'#79494e',1.65);
    paint(c,'M 45 173 L 60 175 Q 71 189 75 230 L 73 305 L 61 305 Q 56 229 49 201Z','#cc7961');
    paint(c,'M -51 154 L -56 189 L -83 305 L -97 305 L -65 181Z','#8a4048');
    stroke(c,'M -48 174 L -54 191 L -65 247 M 53 181 Q 65 211 69 251','#ea9a73',.95);
    stroke(c,'M -57 198 Q 3 212 69 204 M -58 202 Q 2 216 70 208','#783d45',.9);
    stroke(c,'M -58 197 Q 1 209 70 202','#f2ab86',1.25);
    paint(c,'M -50 222 Q -16 228 17 222 L 18 255 Q -15 268 -42 254Z','#ad554e','#84484c',1.3);
    stroke(c,'M -48 225 Q -18 232 15 225 M -44 231 L -39 250 Q -21 259 12 253','#df9976',1);
    for(let i=0;i<10;i++) {
      c.beginPath();const X=-44+i*6.15,Y=226+.003*(X+17)**2;c.moveTo(X,Y);c.lineTo(X+3,Y+.2);c.lineWidth=.58;c.strokeStyle='#f4ba8a';c.stroke();
    }
    paint(c,'M -53 80 Q -37 102 -11 114 L -28 133 L -55 115 L -66 93Z','#f8e8c7','#9b7a77',1.25);
    paint(c,'M 48 83 Q 29 107 -11 114 L 13 139 L 49 118 L 59 95Z','#f8e2bf','#9b7975',1.3);
    paint(c,'M 48 91 L 61 96 L 49 122 L 15 140 L 28 125Z','#c9af9c');
    stroke(c,'M -51 90 Q -37 111 -20 118 M 43 93 Q 24 111 3 117 M 2 132 L 12 138','#fff3cd',1.13);
    stroke(c,'M 77 98 Q 102 110 111 127 M 89 127 Q 98 147 100 171 M 94 149 Q 113 176 113 204 M 105 205 Q 109 227 119 249 M -91 123 Q -95 141 -87 153 M -106 189 Q -104 207 -111 225','#a78f8b',1.35);
    stroke(c,'M -111 112 Q -118 127 -123 145 M -114 151 Q -117 165 -115 180 M 83 104 Q 101 112 107 123','#fff3c3',1.4);
    oval(c,-48,171,5.75,6.2,'#f0b96d','#8b544a',1,-.16);
    oval(c,-50,168,1.7,1.3,'#fff0b0');
    oval(c,53,174,6.2,6.2,'#efb76b','#824a43',1);
    oval(c,51.1,172,1.6,1.15,'#ffecad');
    stroke(c,'M -140 252 L -126 249 M 131 231 L 138 244','#d3b69d',.85);
  }
  function coatElder(c){
    const wool=lin(c,-130,92,133,251,[[0,'#adab7f'],[.38,'#84845d'],[.73,'#656a54'],[1,'#4d5150']]);
    paint(c,'M -37 76 Q -63 79 -97 91 Q -133 104 -146 155 L -173 304 L 165 304 Q 152 186 135 135 Q 125 95 86 87 L 54 76Z',wool,'#4b3e40',2);
    paint(c,'M -117 114 Q -123 149 -112 170 Q -107 208 -134 302 L -163 303 Q -151 221 -146 172 Q -143 138 -117 114Z','#62664d');
    paint(c,'M 85 98 Q 111 110 125 132 Q 139 181 147 268 L 164 304 L 155 229 Q 146 167 132 139 Q 120 104 93 96Z','#57574c');
    paint(c,'M -49 75 L -27 89 Q 0 116 15 126 L 46 88 L 60 82 L 76 92 Q 65 128 35 151 Q 1 152 -27 127 Q -48 108 -61 90Z','#d6bd91','#73634d',1.65);
    paint(c,'M -38 87 Q -17 96 15 126 L 47 90 L 38 112 L 17 137 L -17 117Z','#ac9177');
    paint(c,'M -36 81 Q -13 92 13 120 L 48 83 Q 36 82 20 68 L -17 73Z','#7e8059','#594e42',1);
    stroke(c,'M -48 82 Q -41 104 -16 121 M 66 94 Q 52 119 26 141 M 16 151 L 16 185 M 14 184 Q 18 189 22 184','#b0a177',1.25);
    stroke(c,'M -103 113 Q -114 159 -105 178 M -115 171 Q -116 185 -123 191 M 80 101 Q 112 113 116 131 M 108 125 Q 121 153 118 181 M 108 193 Q 115 213 115 244 M -92 233 Q -70 238 -46 229','#9b916f',1.13);
    stroke(c,'M -124 120 Q -133 139 -137 151 M -132 152 Q -140 178 -140 190 M 88 96 L 101 103','#e2bb83',1.15);
    for(let i=0;i<20;i++){
      const X=-127+i*13.4,Y=247+2.4*Math.sin(i*.71);
      c.beginPath();c.moveTo(X,Y);c.quadraticCurveTo(X+1,Y+6,X-2,Y+10);c.lineWidth=.64;c.strokeStyle=i%3===0?'#c2ab7b':'#555744';c.stroke();
    }
    oval(c,18,165,3.2,4.3,'#bba17d','#685641',.7);oval(c,19.7,179,3.1,3.8,'#b79e77','#6d5846',.7);
  }
  function iris(c,x,y,w,h,p){
    const old=p.old, head=p.head, open=p.open, glint=p.glint;
    c.save();c.translate(x,y);c.scale(w/39,h/18);
    const lid='M -20 -1 C -13 -12 5 -13 14 -7 Q 20 -4 19 1 C 11 9 -5 11 -20 -1Z';
    if(open<.11){
      stroke(c,'M -20 -1 Q -7 5 5 4 Q 15 2 19 -1',old?'#6c4d50':'#3d2738',2.1);
      stroke(c,'M -17 2 Q -4 8 10 4',old?'#c38975':'#b87c73',.7);c.restore();return;
    }
    c.scale(1,open);
    paint(c,lid,old?'#ffeac9':'#ffebd1',old?'#754f52':'#7b5058',.83);
    c.save();c.clip(path(lid));
    const off=p.off,dy=p.look;
    let rg=lin(c,off,-11,off+1,9,old?[[0,'#493039'],[.58,'#82705b'],[1,'#d9a274']]:[[0,'#412b37'],[.5,'#7b4a45'],[.82,'#ae6552'],[1,'#e5a573']]);
    oval(c,off,dy,old?8:10,old?10:11,rg,'#4d303c',1.15);
    oval(c,off-.6,dy-.35,old?3.25:4.1,old?5:6.2,'#2d2434');
    c.save();c.globalAlpha*=.65;
    for(let i=0;i<9;i++){
      const a=.29+(i/8)*2.52,r=old?6.1:7.4;
      c.beginPath();c.moveTo(off+Math.cos(a)*r*.68,dy+Math.sin(a)*(r*.79));c.lineTo(off+Math.cos(a)*r,dy+Math.sin(a)*(r*1.22));c.strokeStyle=i%2===0?'#edb47f':'#a16c60';c.lineWidth=.61;c.stroke();
    }
    c.restore();
    if(glint>.2){
      oval(c,off-3.7,dy-4,2.45,2.1,'#fff8de',null,.8,-.33);
      oval(c,off+3.5,dy+4,.95,.75,'#ffe3ad');
      if(!old)oval(c,off-6,dy-1.5,.85,.64,'#ffe8ae');
    }
    c.restore();
    stroke(c,old?'M -20 -1 C -12 -11 5 -13 14 -7 Q 19 -4 19 1':'M -21 -1 C -13 -12 5 -14 14 -7 Q 19 -5 20 1',old?'#60434c':'#332438',old?1.75:2.75);
    if(!old)stroke(c,'M -18 -4 L -23 -9 M -13 -8 L -16 -12 M 13 -8 L 16 -11',deepest,1.25);
    stroke(c,'M -18 1 Q -7 9 5 6 Q 13 5 17 2',old?'#ae7668':'#bd7e75',.77);
    c.restore();
  }
  const teenOutline='M -62 -46 Q -62 -67 -41 -78 Q -1 -95 37 -74 Q 53 -65 58 -44 Q 65 -16 58 2 Q 63 15 56 29 Q 46 43 30 47 Q 5 66 -13 73 Q -30 78 -42 64 Q -47 55 -49 45 L -53 40 Q -59 37 -56 31 L -57 23 Q -66 22 -68 16 Q -67 11 -63 8 L -57 -3 Q -64 -18 -62 -46Z';
  function teen(c,t,beat='main'){
    const shared=beat==='shared', glance=ease(.05,.56,t);
    const recognize=shared?.69+.24*glance:ease(.29,.91,t), smile=shared?.46+.22*ease(.22,.85,t):ease(.79,1.55,t);
    const lean=shared?.24+.28*glance:ease(.25,1.25,t), wind=shared?.30:ease(.21,.59,t);
    const gust=wind*(.62*Math.sin(t*11.13)+.29*Math.sin(t*20.85));
    const headTil=shared?.012+.085*glance:-.085+.205*recognize-.037*smile;
    const blinkA=.98*(1-ease(.008,.109,Math.abs(t-(shared?.16:.42))));
    const blinkB=shared?0:.99*(1-ease(.004,.10,Math.abs(t-2.33)));
    const eyeOpen=Math.max(.065,1-Math.max(blinkA,blinkB)-.09*smile);
    c.save();c.translate(-3*lean,Math.sin(t*2.3)*.48);
    coatTeen(c);
    c.translate(0,70);c.rotate(headTil);c.translate(0,-70);
    const face=lin(c,-80,-35,59,63,[[0,'#ffdbad'],[.23,'#ffd3aa'],[.60,'#f0ad93'],[.87,'#d69086'],[1,'#c4807c']]);
    const hair=lin(c,-76,-116,90,49,[[0,'#534259'],[.23,'#353048'],[.61,'#23263c'],[1,'#292238']]);
    const under=lin(c,-38,-5,86,83,[[0,'#41354a'],[.47,'#28283f'],[1,'#1e2136']]);
    // Ponytail is attached to the tape at the back, not oscillating with the whole head.
    c.save();c.translate(61,19);c.rotate(gust*.092);c.translate(-61,-19);
    paint(c,'M 61 5 Q 76 -1 87 15 Q 94 28 93 45 Q 97 56 110 69 Q 95 76 88 68 Q 91 76 82 83 Q 74 72 69 64 Q 58 56 58 35Z',under,deepest,2.1);
    paint(c,'M 77 26 Q 84 35 84 47 Q 92 66 101 67 Q 90 70 81 60 Q 71 48 69 33Z','#514359');
    stroke(c,'M 77 31 Q 78 46 89 58 Q 93 64 99 65 M 74 44 Q 77 61 86 67 M 67 37 Q 67 51 72 58','#746176',.84);
    stroke(c,'M 88 39 Q 100 59 112 62 Q 114 63 116 65','#5d485c',.94);
    paint(c,'M 57 10 Q 67 7 77 16 L 80 29 Q 71 36 62 29 L 55 21Z',lin(c,55,10,80,33,[[0,'#f4a07c'],[.53,'#c3605a'],[1,'#943d50']]),'#673847',1.5);
    stroke(c,'M 57 16 Q 66 15 75 20 M 62 25 Q 68 26 76 24','#ee8e6b',1);
    c.restore();
    paint(c,'M -42 59 Q -36 65 -28 66 Q -23 81 -43 98 Q -20 106 -4 119 Q 27 111 45 83 Q 30 59 34 37 L 5 41Z',face,'#704853',1.55);
    paint(c,'M -29 62 L 31 44 Q 35 53 34 68 Q 14 103 -13 105 Q -21 99 -30 97 Q -18 78 -29 62Z','#bf7d78');
    stroke(c,'M -39 96 Q -28 101 -20 108','#ffe0ae',1.25);
    paint(c,'M -78 -29 Q -88 -55 -74 -80 Q -52 -114 -10 -121 Q 24 -126 56 -105 Q 88 -89 91 -56 Q 99 -28 77 -6 Q 72 10 69 22 Q 49 32 35 18 Q -5 14 -42 20 Q -70 9 -78 -29Z',hair,deepest,2.2);
    paint(c,teenOutline,face,ink,1.95);
    c.save();c.clip(path(teenOutline));
    const cheek=rad(c,-9,18,40,[[0,'rgba(211,106,103,.40)'],[.56,'rgba(225,133,116,.16)'],[1,'rgba(233,159,133,0)']]);
    paint(c,'M -34 -85 Q -25 -67 -4 -61 Q 24 -57 35 -39 Q 42 -26 45 -12 Q 38 6 29 17 Q 34 40 13 50 Q -13 66 -35 60 Q -30 75 -9 76 Q 22 69 50 46 L 64 17 L 57 -42 L 30 -79Z','#cd8a82');
    paint(c,'M -63 -41 Q -62 -27 -55 -18 Q -51 -12 -48 -5 Q -42 -20 -36 -33 Q -29 -50 -14 -59 Q -38 -59 -56 -53Z','#d89b84');
    paint(c,'M -66 13 Q -61 8 -57 3 Q -52 8 -54 14 Q -55 19 -50 21 Q -53 22 -66 20Z','#fff0b8');
    paint(c,'M -67 22 Q -62 23 -58 21 Q -52 23 -48 22 Q -46 25 -51 27 L -58 28Z','#c88a7b');
    paint(c,'M -51 47 Q -44 50 -37 48 Q -31 49 -27 53 Q -36 57 -42 52Z','#ffd6ab');
    paint(c,'M -41 60 Q -31 69 -21 68 Q -12 67 -6 64 Q -19 74 -32 69Z','#ffd9aa');
    oval(c,-13,17,40,25,cheek,null,.9,-.20);
    oval(c,-54,9,16,12,rad(c,-54,9,15,[[0,'rgba(210,108,102,.28)'],[1,'rgba(214,126,112,0)']]));
    c.restore();
    // Near ear, winding helix and bounced red from apron.
    {
      paint(c,'M 41 -11 Q 54 -22 62 -13 Q 69 -5 61 8 Q 53 19 43 18 Q 38 15 38 9Z',lin(c,42,-12,65,18,[[0,'#f9bb91'],[.66,'#e6a28b'],[1,'#c47e80']]),'#734b56',1.32);
      paint(c,'M 45 -6 Q 54 -13 57 -7 Q 57 -.4 48 3 L 43 10 L 43 4 Q 48 -.4 45 -6Z','#c17c79');
      stroke(c,'M 43 -6 Q 53 -15 59 -9 Q 63 -4 57 1 M 48 5 Q 54 6 50 12','#975d69',.75);
      stroke(c,'M 55 -11 Q 61 -10 61 -6','#ffcd9f',1.1);
    }
    // Fringe paint — four separate planes plus grouped comb lines that react to the breeze.
    paint(c,'M -77 -24 Q -84 -52 -66 -77 Q -45 -114 -8 -118 Q 29 -121 63 -102 Q 81 -92 88 -69 Q 91 -38 74 -12 L 66 -13 Q 66 -23 58 -28 Q 58 -12 52 -10 Q 51 -21 41 -26 Q 42 -17 36 -13 Q 26 -29 15 -34 Q 18 -25 12 -20 Q 2 -31 -8 -43 Q -11 -47 -18 -47 Q -13 -35 -21 -25 Q -23 -35 -30 -44 Q -46 -36 -51 -22 Q -54 -28 -54 -35 Q -64 -27 -63 -17 Q -71 -23 -72 -30 L -72 -18Z',hair,ink,1.95);
    paint(c,'M -71 -58 Q -61 -92 -29 -104 Q 0 -115 34 -104 Q 61 -97 72 -76 Q 44 -92 29 -86 Q 3 -99 -20 -91 Q -44 -86 -62 -66Z',lin(c,-52,-98,40,-68,[[0,'#8f6b75'],[.38,'#61526d'],[.64,'#565475'],[1,'#41445f']]));
    paint(c,'M -63 -75 Q -52 -93 -34 -98 Q -26 -101 -17 -100 Q -34 -92 -37 -89 Q -48 -87 -55 -80Z','#ac8185');
    paint(c,'M -42 -60 Q -22 -78 -11 -72 Q -17 -60 -18 -47 Q -26 -50 -30 -44 Q -40 -38 -45 -29 Q -45 -40 -39 -53Z','#38324b');
    paint(c,'M -10 -78 Q 5 -77 17 -63 Q 26 -53 29 -39 Q 14 -56 8 -58 Q -3 -52 -8 -43 Q -16 -53 -18 -51Z','#4f435f');
    paint(c,'M 33 -78 Q 65 -80 75 -58 Q 72 -33 66 -23 Q 63 -37 54 -43 L 56 -30 Q 42 -46 31 -48 Q 37 -45 38 -42 Q 29 -53 31 -64Z','#373750');
    paint(c,'M 49 -92 Q 80 -78 82 -55 Q 82 -36 74 -21 L 71 -33 Q 75 -46 70 -59 Q 63 -73 49 -78Z','#282b43');
    stroke(c,'M -73 -46 Q -76 -63 -60 -82 Q -53 -90 -45 -95 M -63 -69 Q -55 -83 -43 -88 M -36 -94 Q -22 -101 -9 -101','#d2a892',1.3);
    stroke(c,'M -68 -38 Q -62 -52 -53 -60 M -56 -45 Q -52 -49 -49 -53 M -44 -53 Q -37 -60 -31 -61 M -26 -51 L -25 -61','#a5848c',1.02);
    stroke(c,'M -4 -90 Q 5 -95 22 -89 M 35 -91 Q 54 -88 65 -76 M 24 -76 Q 35 -72 41 -61 M 25 -63 Q 31 -58 34 -52 M 61 -73 Q 68 -65 70 -55','#87809b',.97);
    stroke(c,'M 52 -51 Q 53 -44 57 -39 M 61 -32 Q 66 -27 66 -21 M 72 -41 Q 73 -34 70 -29','#655e77',.75);
    c.save();c.translate(-5,-85);c.rotate(gust*.048);c.translate(5,85);
    stroke(c,'M -8 -116 Q -27 -123 -47 -114 Q -65 -105 -70 -92 M -29 -115 Q -47 -121 -56 -110 M 34 -107 Q 58 -105 73 -86','#7d6176',.74);
    stroke(c,'M -57 -63 Q -71 -50 -72 -29 Q -74 -18 -79 -10 M -40 -48 Q -48 -40 -49 -24 Q -50 -13 -56 -8','#46374f',.93);
    stroke(c,'M 54 -27 Q 54 -14 48 -4 M 57 -22 Q 59 -14 56 -9','#6b556b',.83);
    c.restore();
    // Yellow brass pins mark the same side of the braid as the wide rig.
    c.save();c.rotate(.17);
    paint(c,'M 38 -54 Q 48 -56 55 -58 Q 57 -57 57 -55 Q 47 -53 40 -51 Q 38 -51 38 -54Z','#e6a87d','#7c545c',.65);
    paint(c,'M 42 -48 Q 49 -50 55 -52 Q 57 -51 57 -49 L 44 -46 Q 42 -46 42 -48Z','#e7b285','#765159',.59);
    stroke(c,'M 40 -54 L 54 -57 M 44 -48 L 54 -51','#ffe7a0',.86);c.restore();
    // Iris and eyebrow motion are independent of the skull.
    stroke(c,'M -58 -21 Q -53 -27 -45 -25 M -38 -23 Q -22 -34 -6 -29',ink,2.42);
    stroke(c,'M -55 -21 Q -52 -24 -46 -24 M -36 -23 Q -20 -29 -9 -28','#7a535a',.82);
    iris(c,-54,-11,20,13,{old:false,open:eyeOpen,off:-4-2.1*recognize,look:1.9-4.4*recognize,glint:1});
    iris(c,-20,-13,39,18,{old:false,open:eyeOpen,off:-3.9-2.9*recognize,look:2.45-4.1*recognize,glint:1});
    stroke(c,'M -43 -11 Q -45 -4 -47 2 Q -53 8 -53 13 Q -49 17 -43 18','#ac756f',1.05);
    stroke(c,'M -63 19 Q -60 20 -57 18 Q -53 19 -51 18','#a36c65',1.05);
    stroke(c,'M -49 26 Q -46 24 -44 25 M -52 29 L -48 28','#a36568',.57);
    for(let i=0;i<6;i++){c.beginPath();c.moveTo(-12+i*2.9,14-.33*i);c.lineTo(-14+i*2.9,18-.36*i);c.strokeStyle='rgba(162,90,95,.37)';c.lineWidth=.63;c.stroke()}
    oval(c,-3.8,22.7,.49,.55,'#aa6b64');
    // A breath leaves the lips before a small smile replaces the tension.
    const breathing=shared?.16*(ease(.28,.47,t)-ease(.52,.78,t)):.76*(ease(.73,1.0,t)-ease(1.09,1.34,t));
    c.beginPath();c.moveTo(-53,32-.95*smile);
    c.quadraticCurveTo(-46,29.8+3.4*smile,-37,31-1.3*smile);
    c.quadraticCurveTo(-39,32.4+(shared?1.5:5.3)*smile+breathing*3.1,-45,33.3+(shared?1.2:2.8)*smile+breathing*2.6);
    c.quadraticCurveTo(-50,33-1*smile,-53,32-.95*smile);c.closePath();
    c.fillStyle='#9a5361';c.fill();c.strokeStyle='#834d59';c.lineWidth=.71;c.stroke();
    if(!shared&&smile>.30){c.save();c.globalAlpha*=ease(.30,.76,smile)*.75;stroke(c,'M -48 32.7 Q -44 34 -40 32.5','#ffeac1',1.15);c.restore();}
    stroke(c,'M -47 43 Q -41 44 -38 42','#c99282',.82);
    stroke(c,'M -61 -38 Q -64 -24 -59 -15 M -67 15 L -66 17 M -44 59 Q -41 66 -36 68','#ffe1ad',1.16);
    c.restore();
  }
  const oldOutline='M -66 -50 Q -59 -74 -28 -81 Q 3 -92 32 -76 Q 58 -65 61 -39 Q 64 -16 59 2 Q 63 13 55 25 Q 51 35 35 44 Q 20 60 3 66 Q -13 70 -29 65 Q -45 59 -51 52 Q -60 43 -58 34 Q -64 27 -60 22 Q -67 22 -71 17 Q -74 13 -71 9 Q -68 3 -62 -2 Q -67 -19 -66 -50Z';
  function elder(c,t,beat='main'){
    const shared=beat==='shared', answer=ease(.17,.78,t);
    const fold=shared?.11+.22*answer:ease(.08,.67,t), ask=shared?.23-.12*answer:ease(1.25,1.96,t);
    const headTilt=shared?-.021-.105*answer:-.095-.13*fold+.34*ask;
    const blink=shared?1-ease(.006,.091,Math.abs(t-.63)):Math.max(1-ease(0,.113,Math.abs(t-1.45)),1-ease(0,.092,Math.abs(t-3.37)));
    const eyeOpen=Math.max(.05,(shared?.84-.15*answer:.59+.35*ask)*(1-blink));
    const talk=shared?0:(ease(1.68,1.78,t)-ease(2.33,2.67,t))*(.60+.29*Math.sin((t-1.74)*24));
    c.save();c.translate(-4*fold-3*ask,Math.sin(t*1.75)*.39);
    coatElder(c);
    c.translate(0,66);c.rotate(headTilt);c.translate(0,-66);
    const skin=shared?lin(c,71,-40,-85,57,[[0,'#f2bf96'],[.39,'#dab18f'],[.72,'#cc9684'],[1,'#ab777b']]):lin(c,-79,-54,66,65,[[0,'#f7cc9e'],[.37,'#e8b18b'],[.71,'#c99081'],[1,'#b97c76']]);
    const wool=shared?lin(c,60,-104,-84,35,[[0,'#f0d9ba'],[.39,'#c1aea7'],[.72,'#a19098'],[1,'#807384']]):lin(c,-80,-114,65,22,[[0,'#ede2c5'],[.36,'#c5b9ac'],[.7,'#9f969a'],[1,'#827884']]);
    paint(c,'M -44 52 L -27 56 Q -18 74 -39 89 Q -30 101 15 124 Q 41 100 54 80 Q 33 63 36 45Z',skin,'#725054',1.52);
    paint(c,'M -30 57 Q -3 69 31 49 L 43 67 Q 21 101 4 106 Q -14 105 -28 90Z','#a97371');
    paint(c,'M -80 -38 Q -89 -68 -65 -87 Q -63 -103 -42 -105 Q -33 -116 -19 -111 Q -2 -125 16 -114 Q 42 -117 56 -100 Q 75 -96 82 -67 Q 90 -46 77 -21 Q 73 7 60 24 Q 38 32 22 18Z',wool,'#574a56',2);
    paint(c,oldOutline,skin,'#594651',1.95);
    c.save();c.clip(path(oldOutline));
    paint(c,'M -62 -43 Q -55 -56 -40 -61 Q -28 -47 -17 -44 Q 7 -62 30 -54 Q 50 -46 48 -20 Q 45 -2 40 13 Q 33 29 19 42 Q -3 64 -32 53 Q -28 66 -14 69 Q 19 71 40 53 Q 66 28 69 -3 L 65 -67 Q 23 -92 -14 -93 Q -54 -90 -67 -67Z','#b88277');
    paint(c,'M -70 16 Q -66 7 -58 1 Q -54 6 -57 13 Q -56 17 -55 18 Q -59 21 -70 20Z','#ffe2aa');
    paint(c,'M -65 24 Q -52 23 -51 27 L -57 31 L -61 34Z','#af726e');
    paint(c,'M -58 37 Q -53 44 -44 46 Q -39 49 -40 50 Q -49 50 -55 43Z','#efbc9a');
    paint(c,'M -44 54 Q -32 63 -18 59 Q -10 59 -4 55 Q -8 63 -20 65 Q -33 66 -44 59Z','#e9b292');
    oval(c,-20,20,46,25,rad(c,-20,20,42,[[0,'rgba(184,103,94,.32)'],[.77,'rgba(195,121,105,.11)'],[1,'rgba(195,121,105,0)']]),null,.7,-.22);
    c.restore();
    paint(c,'M 43 -14 Q 55 -23 63 -16 Q 70 -8 64 2 Q 59 16 50 19 Q 43 15 39 9Z',skin,'#7f5558',1.28);
    paint(c,'M 46 -7 Q 55 -16 59 -9 Q 59 -4 52 1 Q 50 8 45 9 Q 49 2 46 -7Z','#a96f6e');
    stroke(c,'M 43 -5 Q 52 -14 59 -10 Q 62 -3 56 2 M 49 6 Q 55 7 51 12','#8f5f64',.96);
    paint(c,'M -78 -34 Q -85 -55 -71 -75 Q -66 -99 -43 -103 Q -37 -113 -20 -109 Q -4 -121 15 -112 Q 44 -116 56 -98 Q 77 -93 83 -65 Q 86 -44 76 -22 Q 73 -12 66 -8 Q 65 -23 56 -26 Q 58 -16 51 -9 L 44 -18 Q 48 -36 37 -43 L 39 -36 Q 26 -37 18 -58 Q 12 -58 2 -47 Q -9 -43 -14 -44 Q -10 -50 -9 -56 Q -16 -46 -29 -45 L -28 -49 Q -42 -43 -49 -32 Q -51 -39 -55 -38 Q -62 -31 -59 -23 Q -67 -27 -68 -35 Q -70 -26 -66 -16 Q -72 -21 -75 -34Z',wool,'#645461',1.9);
    paint(c,'M -75 -63 Q -69 -80 -60 -88 Q -54 -95 -39 -97 Q -35 -106 -20 -104 Q -7 -113 9 -105 Q -8 -104 -15 -96 Q -32 -98 -44 -89 Q -58 -88 -65 -76Z','#e9d7b9');
    paint(c,'M 7 -101 Q 33 -108 47 -91 Q 57 -91 65 -80 Q 52 -86 43 -81 Q 27 -91 17 -91Z','#e5cfb8');
    paint(c,'M -72 -48 Q -65 -72 -56 -74 Q -43 -90 -24 -88 Q -38 -82 -42 -71 Q -56 -62 -60 -49 L -63 -46 L -64 -52Z','#b8a0a0');
    paint(c,'M -49 -58 Q -31 -76 -12 -75 Q -22 -62 -29 -57 Q -29 -50 -34 -48 Q -40 -44 -49 -35 Q -45 -50 -42 -53Z','#a5969d');
    paint(c,'M -3 -85 Q 14 -92 30 -78 Q 32 -71 38 -66 Q 22 -68 18 -58 Q 12 -64 2 -60 Q 4 -65 -2 -66 Q -6 -60 -11 -57Z','#c0ada9');
    paint(c,'M 45 -66 Q 61 -66 67 -54 Q 75 -48 72 -29 Q 64 -37 59 -39 Q 55 -45 47 -49 Z','#9d8f99');
    stroke(c,'M -76 -59 Q -74 -71 -63 -79 M -61 -84 Q -55 -92 -43 -95 M -41 -99 Q -35 -104 -25 -104 M -15 -105 Q -6 -110 3 -107','#f6e6c3',1.36);
    stroke(c,'M -64 -57 Q -56 -77 -41 -80 M -51 -64 Q -40 -76 -31 -77 M -30 -68 Q -19 -79 -10 -79 M -15 -66 Q -5 -76 3 -78','#f1d8b9',.91);
    stroke(c,'M 13 -97 Q 24 -101 34 -96 M 40 -96 Q 49 -94 53 -87 M 32 -86 Q 46 -89 56 -78 M 55 -69 Q 65 -65 69 -54 M 68 -42 Q 73 -36 72 -30','#e0c9b8',.94);
    stroke(c,'M -62 -41 L -58 -47 M -46 -48 Q -46 -54 -39 -58 M -9 -57 Q -7 -67 1 -72 M 25 -62 Q 32 -52 38 -50 M 52 -34 Q 53 -30 52 -25','#776b77',.92);
    stroke(c,'M -71 -83 Q -65 -101 -50 -102 M -32 -110 Q -27 -115 -19 -114 M 6 -113 Q 20 -118 27 -115','#c8b1a4',.72);
    // Expression, wrinkles, and frames nested as independent planes.
    c.lineCap='round';
    c.beginPath();c.moveTo(-61,-18-3*ask);c.quadraticCurveTo(-53,-22-4.5*ask,-45,-17-5*ask);c.moveTo(-41,-19-4.7*ask);c.quadraticCurveTo(-26,-30-1.6*ask,-8,-25-1.4*ask);c.lineWidth=3.36;c.strokeStyle='#a99b98';c.stroke();
    stroke(c,'M -38 -34 Q -24 -38 -12 -35 M -36 -30 Q -26 -32 -19 -32 M -49 -27 L -44 -30 M -46 -23 L -44 -25','#ae726d',.86);
    stroke(c,'M -9 -8 Q -4 -8 1 -6 M -10 -4 Q -4 -3 2 -1 M -12 6 Q -5 5 -2 8 M -44 7 Q -34 12 -21 9 M -57 5 Q -54 7 -51 7','#9f6a66',.92);
    stroke(c,'M -5 15 Q -2 23 -6 29 M -6 31 Q -8 37 -4 43 M -48 47 Q -39 52 -32 50 M -41 55 Q -32 57 -26 54','#aa716d',.82);
    iris(c,-54,-7,21,13,{old:true,open:eyeOpen,off:-2.7-1.25*ask,look:3.2-5.35*ask,glint:1});
    iris(c,-27,-10,38,17,{old:true,open:eyeOpen,off:-2.8-2.8*ask,look:3.2-5.05*ask,glint:1});
    // Thin two-tone wire glasses wrap the bridge, with glints painted sparingly.
    c.save();c.globalAlpha*=.93;
    paint(c,'M -66 -11 Q -50 -15 -47 -9 L -48 1 Q -53 10 -62 4 Q -66 1 -66 -11Z','rgba(240,215,187,.11)','#624c58',1.65);
    paint(c,'M -44 -13 Q -23 -20 -10 -17 Q -7 -17 -6 -11 L -7 -1 Q -11 10 -26 11 Q -42 11 -46 1Z','rgba(244,219,194,.09)','#624c56',1.86);
    stroke(c,'M -46 -7 Q -48 -11 -50 -6 M -7 -14 Q 11 -17 39 -10 L 48 -8','#65535c',1.67);
    stroke(c,'M -64 -11 Q -56 -12 -52 -11 M -41 -14 Q -29 -18 -21 -17 M -14 -16 Q -11 -17 -9 -14 M -7 -14 L 1 -15','#ffe8b8',1.01);
    stroke(c,'M -40 -10 L -34 -13 M -38 -6 L -29 -12','rgba(255,246,217,.57)',.7);c.restore();
    stroke(c,'M -46 -6 Q -48 2 -53 8 Q -55 12 -51 15 Q -47 19 -41 18 M -64 18 Q -60 20 -55 19','#a8716c',1.08);
    // Moustache is a two-lobe, finely combed shape and stays slightly above lips.
    paint(c,'M -55 27 Q -48 19 -40 20 Q -35 19 -31 23 Q -23 18 -16 22 Q -8 25 -5 34 Q -11 35 -19 31 Q -26 31 -30 28 Q -33 33 -40 32 Q -48 31 -55 34 Q -58 32 -55 27Z',lin(c,-51,20,-16,35,[[0,'#f0d9bd'],[.44,'#d5bfb0'],[1,'#a88d94']]),'#886d77',1.05);
    stroke(c,'M -54 28 Q -47 24 -41 24 M -52 31 Q -45 27 -38 27 M -37 23 Q -34 24 -32 26 M -28 25 Q -23 22 -17 25 Q -12 27 -10 30 M -26 27 Q -22 26 -16 30','#fff0cd',.66);
    if(talk>.12){
      c.beginPath();c.moveTo(-51,37.5);c.quadraticCurveTo(-44,34.8-3.5*talk,-33.5,36.8);
      c.quadraticCurveTo(-35,38+9*talk,-42,40+5*talk);c.quadraticCurveTo(-49,39+2*talk,-51,37.5);c.closePath();
      c.fillStyle='#9f5d63';c.fill();c.strokeStyle='#80545e';c.lineWidth=.92;c.stroke();
      if(talk>.56)stroke(c,'M -46 37 Q -42 37 -37 37','#efd0af',.68);
    }else if(shared){
      c.beginPath();c.moveTo(-52,36.2-1.7*answer);c.quadraticCurveTo(-42,36.2+2.7*answer,-33,35.8-1.25*answer);
      c.lineWidth=1.02;c.strokeStyle='#8a5662';c.stroke();
      stroke(c,'M 35 -109 Q 52 -106 60 -97 M 76 -77 Q 82 -65 82 -54 M 65 3 Q 63 10 57 14','#f5cf9e',1.34);
      stroke(c,'M -50 38 Q -47 40 -42 39','#d39c86',.69);
    }else stroke(c,'M -51 37.4 Q -43 34.2 -33 36.4','#8d5763',1.06);
    stroke(c,'M -45 44 Q -38 46 -33 44 M -40 49 Q -36 50 -25 48','#b48073',.78);
    stroke(c,'M -65 -33 Q -66 -25 -63 -18 M -70 11 L -70 14 M -56 44 Q -54 51 -51 52','#f9d2a2',.99);
    c.restore();
  }
  /* Dispatch-room close portrait: the navy of the uniform is bounced across the
     face by the same monitor she is looking at. No teeth or broad smile in this cut. */
  const mumFace='M -61 -54 Q -56 -69 -37 -78 Q -8 -94 30 -79 Q 53 -69 58 -46 Q 65 -26 59 -12 Q 67 -2 59 14 Q 55 28 43 36 Q 29 52 12 63 Q -7 76 -26 72 Q -39 69 -44 56 Q -49 46 -54 42 Q -59 35 -57 29 L -58 23 Q -67 22 -69 15 Q -67 11 -63 8 Q -59 2 -57 -5 Q -62 -22 -61 -54Z';
  function coatMum(c){
    const wool=lin(c,-137,95,126,246,[[0,'#a5b7c5'],[.24,'#7d9bad'],[.54,'#5b758a'],[.78,'#435365'],[1,'#303945']]);
    paint(c,'M -43 71 Q -59 79 -90 88 Q -119 94 -132 127 Q -145 166 -154 304 L 158 304 Q 147 177 131 133 Q 118 94 84 89 L 48 75Z',wool,'#333647',2.2);
    paint(c,'M 85 106 Q 113 109 126 143 Q 142 187 152 283 L 157 303 L 130 303 Q 124 237 116 200 Q 114 160 102 141Z','#3e4b61');
    paint(c,'M -114 114 Q -113 148 -103 164 Q -102 193 -111 233 L -117 305 L -153 305 Q -151 257 -144 210 Q -137 156 -130 137Z','#667e91');
    paint(c,'M -50 85 Q -38 101 -22 113 Q -11 109 15 111 Q 37 102 50 84 L 56 106 L 45 159 L 21 296 L -38 299 L -58 133Z',lin(c,-50,90,36,249,[[0,'#e9e5ca'],[.37,'#d2d4bf'],[.78,'#9ea9a9'],[1,'#647989']]),'#657584',1.35);
    paint(c,'M -52 83 Q -68 87 -86 95 L -80 128 L -56 133 L -68 150 Q -45 162 -17 190 L -31 148 L -33 113Z','#91adba','#48596b',1.35);
    paint(c,'M 50 84 Q 67 88 85 100 L 72 125 L 54 132 L 69 148 Q 36 162 13 194 L 29 142 L 35 111Z','#748eaa','#40576c',1.45);
    paint(c,'M 48 92 Q 62 93 75 101 L 66 120 L 54 123 L 44 120Z','#a0b4bf');
    paint(c,'M -53 91 Q -47 106 -39 114 L -27 153 L -43 139 L -52 119 L -69 122Z','#728e9f');
    stroke(c,'M -52 88 L -38 110 L -30 130 M -77 105 Q -70 112 -69 119 M 48 92 Q 44 102 40 111 M 65 126 L 57 132 L 66 145','#c0cddb',1.13);
    stroke(c,'M 12 194 Q 2 236 12 294 M 18 195 Q 10 242 18 294 M -81 168 Q -95 179 -88 214 M -105 201 L -117 236 M 94 135 Q 99 145 99 159 M 110 156 Q 115 181 116 200 M 108 243 Q 111 263 122 281','#657d93',1.24);
    stroke(c,'M -117 106 Q -124 116 -129 133 M -129 139 Q -135 153 -135 167 M -81 96 L -70 91 M 83 100 Q 99 107 105 114','#c1e0e6',1.38);
    paint(c,'M 51 160 Q 65 154 79 154 L 82 173 Q 69 177 57 180Z','#bac7bc','#46576a',1.25);
    paint(c,'M 53 161 L 77 156 L 79 160 L 55 167Z','#d5d9c6');
    stroke(c,'M 59 168 L 71 165 M 60 173 L 74 170 M 47 186 L 82 178','#697f8b',.98);
    oval(c,11,215,3.75,4.15,'#a8b7bb','#45586a',.95);oval(c,10.4,230,3.4,3.9,'#9ba9b3','#47596c',.9);
    oval(c,10.25,213.9,1.14,1.05,'#d8e5d8');
    stroke(c,'M 46 248 Q 69 242 86 242 L 88 249 M -88 237 L -64 234','#85a3b2',.84);
  }
  function mum(c,t){
    const settle=ease(.25,.68,t), resolve=ease(.60,.88,t), breath=ease(.29,.48,t)-ease(.51,.80,t);
    const blink=1-ease(.012,.091,Math.abs(t-.31));
    const after=ease(1.77,1.87,t)-ease(1.89,2.01,t);
    const open=Math.max(.05,.95-.075*settle-.83*blink-.82*after);
    c.save();c.translate(-2.7*settle,.5*breath+Math.sin(t*2.45)*.23);
    coatMum(c);
    c.translate(0,69);c.rotate(.031-.143*settle+.036*resolve);c.translate(0,-69);
    const hair=lin(c,-80,-114,89,53,[[0,'#535666'],[.29,'#393c4d'],[.63,'#2d2939'],[1,'#292836']]);
    const lit=lin(c,-83,-31,70,58,[[0,'#f2d6b0'],[.24,'#ecc5a6'],[.54,'#d6a493'],[.82,'#b88686'],[1,'#9d7782']]);
    const neck=lin(c,-74,64,60,113,[[0,'#e2b99c'],[.42,'#c39899'],[1,'#947080']]);
    // The bun is low and narrow, tied at the nape instead of tied at the crown.
    paint(c,'M 53 19 Q 64 8 80 15 Q 97 13 104 28 Q 111 41 101 52 Q 93 63 74 62 Q 62 61 53 53 L 46 37Z',hair,'#30303f',1.98);
    paint(c,'M 75 18 Q 91 17 99 29 Q 103 42 96 48 Q 93 31 79 26 Q 68 23 60 28Z','#585365');
    stroke(c,'M 76 22 Q 92 24 96 34 M 88 26 Q 99 37 95 46 M 85 29 Q 92 38 91 47 M 69 57 Q 80 60 91 54','#806877',.86);
    paint(c,'M 54 20 Q 62 16 68 19 L 72 29 L 64 37 L 57 33Z','#383344','#4b4957',1.1);
    stroke(c,'M 61 21 L 66 23 M 61 25 L 69 27 M 60 29 L 67 31','#70707b',.66);
    paint(c,'M -42 58 L -30 65 Q -24 85 -42 93 Q -29 101 -11 117 Q 15 115 47 88 Q 31 74 33 48 L 1 38Z',neck,'#705766',1.4);
    paint(c,'M -28 62 Q -6 69 30 49 Q 30 55 33 63 Q 6 102 -18 103 L -31 94 Q -20 78 -28 62Z','#9f727f');
    stroke(c,'M -40 92 Q -26 98 -20 104','#eac8b0',1.09);
    paint(c,'M -76 -36 Q -83 -67 -62 -95 Q -39 -119 -8 -119 Q 15 -123 34 -111 Q 69 -111 85 -84 Q 97 -58 83 -30 Q 71 -10 66 9 L 58 25 Q 39 29 26 19 Q -10 6 -39 18 Q -66 13 -76 -36Z',hair,'#343341',2.12);
    paint(c,mumFace,lit,'#443747',1.9);
    c.save();c.clip(path(mumFace));
    paint(c,'M -60 -58 Q -38 -69 -27 -60 Q -21 -55 -15 -52 Q 5 -62 23 -47 Q 31 -33 31 -18 Q 42 -14 40 3 Q 29 14 29 30 Q 19 51 -4 57 Q -18 66 -38 62 Q -29 75 -6 74 Q 32 65 57 35 L 64 11 L 60 -40 L 38 -73 L -30 -90Z','#ae8088');
    paint(c,'M -61 -34 Q -57 -23 -53 -18 L -48 -7 Q -43 -10 -42 -26 Q -37 -42 -26 -51 Q -43 -53 -57 -45Z','#c49d93');
    paint(c,'M -67 15 Q -63 9 -59 4 Q -55 12 -56 15 Q -55 19 -48 21 Q -57 23 -66 19Z','#fae5bf');
    paint(c,'M -67 22 Q -61 24 -56 21 Q -52 23 -48 22 L -50 26 Q -56 28 -60 26Z','#b58487');
    paint(c,'M -52 46 Q -45 49 -38 47 Q -33 49 -34 51 Q -43 54 -49 50Z','#e9bca7');
    paint(c,'M -46 56 Q -33 67 -20 67 Q -10 66 -2 63 Q -14 72 -29 70 Q -37 67 -46 56Z','#e6b6a6');
    oval(c,-15,14,31,20,rad(c,-15,14,34,[[0,'rgba(152,86,102,.27)'],[.75,'rgba(171,106,112,.12)'],[1,'rgba(171,106,112,0)']]),null,1,-.18);
    paint(c,'M -58 -39 Q -58 -20 -51 -14 L -53 -23 Q -56 -31 -54 -42Z','#ead1b7');
    c.restore();
    paint(c,'M 40 -13 Q 52 -22 60 -16 Q 70 -10 62 4 Q 57 17 47 18 Q 42 16 37 9Z',lit,'#735d6c',1.38);
    paint(c,'M 45 -5 Q 54 -14 58 -8 Q 58 -2 52 1 Q 54 8 46 10 Q 47 2 45 -5Z','#a67c85');
    stroke(c,'M 43 -6 Q 51 -14 57 -10 Q 63 -7 57 0 M 48 5 Q 54 7 49 12','#7f646e',.83);
    oval(c,48.9,15.2,3.65,4.05,'#b89667','#694957',.83);
    oval(c,48.1,13.9,1.13,1.32,'#f1d6a4');stroke(c,'M 47 20 Q 49 24 51 20','#90747b',.53);
    // Side part broad plane, smaller gathered planes, stray filaments and cold edge paint.
    paint(c,'M -76 -36 Q -82 -61 -63 -91 Q -44 -119 -9 -116 Q 6 -119 16 -109 Q 42 -118 67 -100 Q 84 -90 89 -67 Q 90 -44 76 -23 Q 72 -12 65 -5 Q 64 -18 57 -23 Q 54 -10 48 -9 Q 44 -34 34 -39 Q 18 -47 5 -48 Q -8 -47 -17 -66 Q -25 -46 -44 -36 Q -60 -27 -62 -14 Q -67 -18 -69 -34 Q -73 -27 -70 -16 Q -75 -22 -76 -36Z',hair,'#383745',1.9);
    paint(c,'M -68 -62 Q -59 -90 -33 -102 Q -17 -110 -4 -109 Q -30 -96 -37 -84 Q -45 -71 -60 -63Z',lin(c,-58,-91,-6,-106,[[0,'#64778a'],[.43,'#657180'],[1,'#5a5b70']]));
    paint(c,'M -66 -49 Q -43 -68 -31 -82 Q -24 -94 -3 -104 Q -14 -95 -14 -76 Q -25 -63 -31 -55 Q -48 -47 -59 -38Z','#565261');
    paint(c,'M -65 -45 Q -57 -51 -42 -56 Q -45 -46 -58 -34 Q -62 -27 -63 -20 Q -67 -29 -65 -45Z','#49475a');
    paint(c,'M 3 -104 Q 25 -117 43 -106 Q 61 -104 74 -84 Q 53 -95 37 -90 Q 20 -88 11 -91Z','#626174');
    paint(c,'M 15 -91 Q 41 -99 62 -83 Q 73 -70 73 -46 Q 62 -63 48 -63 Q 34 -64 20 -75Z','#4b4c63');
    paint(c,'M 25 -72 Q 50 -74 63 -58 Q 69 -40 61 -21 Q 55 -31 50 -35 Q 46 -43 33 -48 Q 27 -57 25 -72Z','#383849');
    paint(c,'M 65 -79 Q 80 -67 80 -49 Q 82 -36 73 -23 L 69 -23 Q 73 -38 69 -50 Q 70 -62 65 -79Z','#333342');
    stroke(c,'M -75 -56 Q -72 -71 -63 -86 M -62 -89 Q -52 -100 -37 -105 M -31 -107 Q -22 -110 -11 -110','#9dacbc',1.32);
    stroke(c,'M -69 -59 Q -65 -70 -53 -78 M -58 -65 Q -49 -75 -38 -81 M -39 -73 Q -30 -85 -22 -91 M -24 -72 Q -18 -78 -16 -83','#858494',.96);
    stroke(c,'M 8 -101 Q 18 -107 30 -107 M 32 -104 Q 46 -103 55 -97 M 21 -90 Q 39 -93 52 -86 M 46 -80 Q 58 -78 64 -68 M 54 -62 Q 66 -54 68 -46','#8d8194',.88);
    stroke(c,'M 71 -42 Q 72 -31 68 -25 M 56 -33 Q 58 -25 53 -17 M -50 -42 Q -57 -35 -59 -28','#74677e',.75);
    stroke(c,'M -67 -82 Q -71 -78 -75 -67 Q -81 -59 -81 -45 M -38 -107 Q -33 -116 -19 -119 Q -11 -119 -4 -116 M 68 -98 Q 84 -92 86 -78 M 75 -24 Q 76 -16 67 -11','#6e7286',.83);
    // Gaze settles from screen-left to a lower point; independent lids lead the head.
    c.beginPath();c.moveTo(-62,-20+.6*settle);c.quadraticCurveTo(-58,-26+.7*resolve,-49,-25+1.5*settle);
    c.moveTo(-41,-22+1.18*settle);c.quadraticCurveTo(-28,-31+3.4*resolve,-12,-30+2.4*resolve);
    c.lineWidth=2.04;c.strokeStyle='#59434f';c.stroke();
    stroke(c,'M -38 -22 Q -28 -26 -20 -27','#876674',.69);
    iris(c,-55,-11,20,12,{old:true,open,off:-4.8+1.42*settle,look:-.70+3.95*settle,glint:1});
    iris(c,-25,-13,39,17,{old:true,open,off:-4.2+1.82*settle,look:-.87+4.56*settle,glint:1});
    stroke(c,'M -44 -10 Q -46 -4 -49 1 Q -53 7 -52 13 Q -49 18 -44 18 M -64 20 Q -62 21 -58 19','#9f7f89',.94);
    stroke(c,'M -7 -3 Q -10 1 -15 2 M -11 2 Q -17 5 -21 5 M -49 26 Q -47 24 -44 24','#aa7d8a',.78);
    c.beginPath();c.moveTo(-55,33);c.quadraticCurveTo(-46,31.55-resolve*.77,-36,34.04-.67*resolve);
    c.quadraticCurveTo(-42,35.8+breath*1.49,-48,35.1+breath*1.16);c.quadraticCurveTo(-52,34.6,-55,33);c.closePath();
    c.fillStyle='#a86f79';c.fill();c.lineWidth=.81;c.strokeStyle='#865668';c.stroke();
    stroke(c,'M -48 41 Q -41 43 -36 41 M -62 -37 Q -63 -27 -60 -19 M -67 15 L -67 17 M -42 61 Q -39 66 -35 67','#e7bda9',.87);
    c.restore();
  }
  // Native-space actor for the optional two-shot; the canvas transform stays isolated.
  window.closeCastAt=function(c,x,y,scale,t=0,kind='teen',facing=1,beat='main'){
    if(!(scale>0)||!Number.isFinite(x)||!Number.isFinite(y))return;
    t=Number.isFinite(t)?Math.max(0,t):0;
    c.save();c.translate(x,y);c.scale(scale*(facing<0?-1:1),scale);
    c.lineJoin='round';c.lineCap='round';
    if(kind==='mum')mum(c,t);else if(kind==='grandpa')elder(c,t,beat);else teen(c,t,beat);
    c.restore();
  };
  window.closeCast=function(c,w,h,t=0,kind='teen'){
    if(!(w>0)||!(h>0))return;
    const elderKind=kind==='grandpa', motherKind=kind==='mum';
    t=Number.isFinite(t)?Math.max(0,t):0;
    const p=h>w, scale=Math.min(h*(p?.00203:.00219),w*(p?.00405:.0032));
    c.save();c.translate(w*(p?(motherKind?.56:.568):(motherKind?.63:.614)),h*(p?.41:.45));c.scale(scale,scale);
    c.lineJoin='round';c.lineCap='round';
    if(elderKind)elder(c,t);else if(motherKind)mum(c,t);else teen(c,t);
    c.restore();
  };
})();

