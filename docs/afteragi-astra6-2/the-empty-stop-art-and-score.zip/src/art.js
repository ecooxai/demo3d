// Original production drawing primitives. All coordinates are local to a supplied context.
window.Art=(()=>{
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)},lerp=(a,b,t)=>a+(b-a)*t,TAU=2*Math.PI;
const R=(seed)=>{let a=seed|0;return ()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296}};
const path=(g,d,fill,stroke,lw=1)=>{let p=new Path2D(d); if(fill){g.fillStyle=fill;g.fill(p)}if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke(p)}return p};
const line=(g,pts,c,k=1)=>{g.strokeStyle=c;g.lineWidth=k;g.beginPath();g.moveTo(...pts[0]);for(let i=1;i<pts.length;i++)g.lineTo(...pts[i]);g.stroke()};
const ell=(g,x,y,rx,ry,fill,stroke,lw=1)=>{if(rx<=0||ry<=0)return;g.beginPath();g.ellipse(x,y,rx,ry,0,0,TAU);if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke()}};
const grad=(g,x,y,X,Y,stops)=>{let l=g.createLinearGradient(x,y,X,Y);for(let [f,c] of stops)l.addColorStop(f,c);return l};
const radial=(g,x,y,a,b,stops)=>{let l=g.createRadialGradient(x,y,a,x,y,b);for(let [f,c] of stops)l.addColorStop(f,c);return l};
const rr=(g,x,y,w,h,r,fill,stroke,lw=1)=>{g.beginPath();g.roundRect(x,y,w,h,r);if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke()}};
const text=(g,s,x,y,size,col,font='Noto Sans',weight=500,align='left')=>{g.font=weight+' '+size+'px "'+font+'",sans-serif';g.fillStyle=col;g.textAlign=align;g.fillText(s,x,y)};
return{clamp,ease,lerp,TAU,R,path,line,ell,grad,radial,rr,text}
})();
