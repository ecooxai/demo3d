// THE EMPTY STOP. Original short about general intelligence, missing data and human judgment.
// draw(w,h,t,variant) is deterministic and draws one native aspect at a time; no stretching.
(()=>{
const {path:P,line:L,ell:E,grad:G,radial:D,rr:RR,text:T,TAU,R,ease,clamp,lerp}=Art;
const can=document.querySelector('#stage')||document.querySelector('canvas'),g=can.getContext('2d',{alpha:false});
function bg(w,h,t,m){if(['heat','dusk','bus','cosmos'].includes(m))city(g,w,h,t,m);else shop(g,w,h,t,m)}
function camera(w,h,z=1,ax=.5,ay=.5,dx=0,dy=0){g.translate(w*ax+dx,h*ay+dy);g.scale(z,z);g.translate(-w*ax,-h*ay)}
function page(x,y,ww,hh,ang,t,paper=true,mark=0,sel=0){atlas(g,x,y,ww,hh,t,{angle:ang,paper,mark,selected:sel})}
function pt(x,y,w,h,ang,u,v){let X=u*w,Y=v*h,C=Math.cos(ang),S=Math.sin(ang);return[x+C*X-S*Y,y+S*X+C*Y]}
function cup(x,y,s,tea=true){
 g.save();g.translate(x,y);g.scale(s,s);E(g,1,10,23,5,'rgba(46,39,39,.23)');P(g,'M -15 -18 Q -14 6 -8 11 Q 0 16 10 10 Q 15 0 15 -18 Z',tea?'#9baaa0':'#bdd0b8','#647670',1.2);E(g,0,-18,15,4.5,'#c8c8ae','#65716a',1.2);E(g,0,-17.5,12.8,3.3,'#8e7653');P(g,'M 15 -13 Q 28 -15 24 -4 Q 20 2 13 2',null,'#899b8f',3.8);P(g,'M -10 -11 Q -11 0 -8 6',null,'#d9cdb0',1);g.restore()
}
function tutor(w,h,x,y,s,t,orient=1){
 g.save();g.translate(x,y);g.rotate(-.035*orient);g.scale(s,s);
 P(g,'M -45 -6 L 46 -6 58 1 56 5 -50 6 -59 3 Z','#59615e','#3b4446',1.3);
 P(g,'M -48 -66 Q -48 -70 -43 -70 L 43 -70 Q 48 -70 48 -65 L 44 -5 -49 -4 Z','#374849','#293b3f',2);RR(g,-43,-65,85,56,3,'#20383d');T(g,'GENERAL  /  TUTOR',-38,-53,6.7,'#b3c8b6','Noto Sans',650);
 let rng=R(47);for(let i=0;i<23;i++){let xx=-32+i*2.8,v=(.3+rng()*.7)*(.4+.6*Math.pow(Math.sin(t*2.2+i*.64),2));L(g,[[xx,-33-6*v],[xx,-33+6*v]],i%4===0?'#e2b57e':'#88b7a9',1.4)}
 T(g,'LISTENING',-37,-15,5.5,'#799e95','Noto Sans',500);E(g,35,-16,1.8,1.8,'#d6a66c');g.restore()
}
function officeConsole(w,h,t,correction=false){
 const p=h>w;const ww=w*(p?.74:.50),hh=ww*(p?.54:.57),x=w*(p?.13:.083),y=h*(p?.49:.265),unit=Math.min(w/1100,h/750),ax=x+ww*.5;
 P(g,'M '+(ax-12*unit)+' '+(y+hh*.86)+' L '+(ax+15*unit)+' '+(y+hh*.86)+' '+(ax+22*unit)+' '+(y+hh+19*unit)+' '+(ax+52*unit)+' '+(y+hh+28*unit)+' '+(ax-54*unit)+' '+(y+hh+28*unit)+' '+(ax-17*unit)+' '+(y+hh+18*unit)+' Z','#536461','#37484b',1.9*unit);
 page(x,y,ww,hh,-.008,t,false,correction?1:0,correction?ease((t-.42)/.92):0)
}
function opening(w,h,t){
 const p=h>w;g.save();camera(w,h,1.027+.019*t/2.8,.54,.48,-w*.003*t,0);if(window.heatOpening)heatOpening(g,w,h,t);else bg(w,h,t,'heat');g.restore();
 // The sign/title shares the early morning negative sky, not the family’s later space.
 const a=ease((t-.14)/.42)*(1-ease((t-2.5)/.3));g.save();g.globalAlpha=a;
 const xx=w*(p?.46:.58),yy=h*(p?.11:.155),fs=Math.min(w*(p?.055:.043),h*.092);
 if(p){
  const edge=w*.951,base=h*.074,sz=w*.072;
  T(g,'MIZUHAMA  /  SUMMER',edge,base,Math.max(13,sz*.213),'#3d4c50','Noto Sans',650,'right');
  T(g,'The Empty',edge,base+sz*1.02,sz,'#303b43','Noto Serif',640,'right');
  T(g,'Stop',edge,base+sz*2.00,sz,'#303b43','Noto Serif',640,'right');
  L(g,[[edge-sz*.63,base+sz*2.19],[edge,base+sz*2.19]],'#a86f57',Math.max(2,sz*.027));
 }else{
 T(g,'M I Z U H A M A     /     S U M M E R',xx,yy,Math.max(14,fs*.22),'#4f5652','Noto Sans',640);
 T(g,'The Empty Stop',xx,yy+fs*1.02,fs,'#343b43','Noto Serif',630);
 L(g,[[xx,yy+fs*1.27],[xx+fs*.66,yy+fs*1.27]],'#ac725b',Math.max(2,fs*.024));}g.restore();dust(g,w,h,t,.42,.011)
}
function stalled(w,h,t){
 const p=h>w,tilt=ease((t-.53)/1.00),r=Math.min(w*.405,h*.444),gx=w*(p?.55:.586)-w*.020*tilt,
       gy=h*(p?.53:.57)-h*(p?.425:.456)*tilt,press=ease((t-1.53)/.23)-ease((t-1.96)/.22);
 g.save();camera(w,h,1.016+.026*ease(t/2.3),.55,.52);
 // One continuous tilt: silent blades → worn switch. Finger tests it. Nothing starts.
 softShop(g,w,h,t+.7,'bench',19,1.48);g.fillStyle='rgba(43,56,66,.17)';g.fillRect(0,0,w,h);
 const ledge=gy+r*1.64;P(g,'M 0 '+(ledge+h*.008)+' L '+w+' '+(ledge-h*.013)+' '+w+' '+(h*1.05)+' 0 '+(h*1.05)+' Z',G(g,0,ledge,0,h,[[0,'#a28e72'],[.19,'#847560'],[1,'#615952']]));
 L(g,[[0,ledge+h*.011],[w,ledge-h*.009]],'#d1b28a',Math.max(1,h*.0026));
 fan(g,gx,gy,r,t,{yaw:.82,noBase:false,phase:.40,button:press});
 if(t>1.15){
  let reach=ease((t-1.15)/.38),away=ease((t-2.02)/.30),tarX=gx-r*.10,tarY=gy+r*1.39;
  let xx=tarX-w*(.145*(1-reach)+.080*away),yy=tarY-h*(.14*(1-reach)+.051*(1-press)+.04*away),ss=h/(p?790:660);
  g.save();g.translate(xx,yy);g.scale(-1,1);hand(g,0,0,ss,.33+.05*press,t,'tap','teen');g.restore()
 }
 g.restore();slattedLight(g,w,h,t,{x:.34,slant:-.27,alpha:.145});shafts(g,w,h,t,{from:p?.13:.29,slant:.24,a:.15});dust(g,w,h,t,.55,.002)
}
function fixing(w,h,t){
 const p=h>w,r=Math.min(w*.15,h*(p?.145:.145)),fx=w*(p?.64:.60),fy=h*.762-r*1.6,hh=h*(p?.81:.87);
 let targetX=fx-r*.67,targetY=fy-r*.60,xx=targetX-.37*hh,yy=targetY+.654*hh;
 g.save();camera(w,h,1.015+.022*ease(t/3),.48,.48);bg(w,h,t,'bench');
 cast(g,xx,yy,hh,'teen','fix',t,1,null,'warm-left');shopFront(g,w,h,t,'bench');fan(g,fx,fy,r,t,{yaw:.82,phase:.40});
 tutor(w,h,w*(p?.14:.77),h*.762,Math.max(.96,h/(p?765:625)),t);
 shafts(g,w,h,t,{from:.15,slant:.39,a:.135});dust(g,w,h,t,.62);g.restore()
}
function fixInsert(w,h,t){
 const p=h>w,cam=ease(t/2.32),r=h*(p?.67:.75),fx=w*(p?.08:.25),fy=h*(p?.72:.68);
 softShop(g,w,h,t+.4,'bench',24,1.59);g.fillStyle='rgba(62,59,54,.16)';g.fillRect(0,0,w,h);
 // Macro on one retaining clip rather than a disconnected hand floating in frame.
 g.save();g.translate(w,0);g.scale(-1,1);const yaw=.9,spin=ease((t-1.01)/.76),phase=.40+Math.max(0,t-1.01)**2*8.5;
 fan(g,fx,fy,r,t,{yaw,phase,spin:9.0*spin,noBase:true});
 let clipX=fx+Math.cos(.2)*r*yaw,clipY=fy+Math.sin(.2)*r;
 // Copper-colored collar links to the red stop marker and the sunset.
 let rr=r*.069;RR(g,clipX-rr*.76,clipY-rr*1.3,rr*1.5,rr*2.1,rr*.3,'#b87e55','#594f45',rr*.13);
 E(g,clipX,clipY-rr*.17,rr*.40,rr*.40,'#d6b484','#72624d',rr*.11);
 let inr=ease(t/.63),out=ease((t-1.33)/.80),u=h/(p?530:455);
 hand(g,clipX+u*(33*(1-inr)+89*out-1),clipY+u*(-19*(1-inr)-42*out),u,-.25+.2*inr-.20*out,t,'pinch','teen');
 if(spin>.1)breeze(g,w,h,t-1.01);g.restore();dust(g,w,h,t,.51,.009)
}
function ribbonLift(w,h,t){
 const p=h>w,r=h*(p?.76:.78),yaw=.86,aimX=w*(p?.56:.59),aimY=h*(p?.44:.44),fx=aimX+r*.65*yaw,fy=aimY+r*.75;
 softShop(g,w,h,t,'bench',22,1.58);g.fillStyle='rgba(83,101,96,.105)';g.fillRect(0,0,w,h);
 g.save();camera(w,h,1.018+.063*ease(t/.70),p?.51:.52,.45);
 let flow=ease((t+.095)/.53);fan(g,fx,fy,r,t+1.1,{yaw,phase:.53+12*t*t+1.0*t,spin:14*flow,noBase:true});g.restore();
 g.save();g.translate(w,0);g.scale(-1,1);breeze(g,w,h,t+.13);g.restore();dust(g,w,h,t,.58,.038)
}
function relief(w,h,t){
 const p=h>w;softShop(g,w,h,t+1,'bench',20,1.56);g.fillStyle='rgba(234,206,163,.20)';g.fillRect(0,0,w,h);
 const hh=h*(p?2.08:2.30),xx=w*(p?.54:.59),yy=h*(p?.34:.42)+hh*.92;
 g.save();camera(w,h,1.03+.035*ease(t/1.8),.55,.42);g.save();g.translate(w,0);g.scale(-1,1);if(window.closeCast)closeCast(g,w,h,t,'teen');else cast(g,xx,yy,hh,'teen','listen',t,-1,null,'warm-left');g.restore();g.restore();
 g.save();g.translate(w,0);g.scale(-1,1);breeze(g,w,h,t+.23);g.restore();shafts(g,w,h,t,{from:.14,slant:.48,a:.12});dust(g,w,h,t,.42,.04)
}
function transit(w,h,t){
 g.save();camera(w,h,1.33+.065*ease(t/3),.61,.64,-w*.04*ease(t/3.1),0);bg(w,h,t,'bus');g.restore();if(window.waitingPassenger)waitingPassenger(g,w,h,t,false);if(window.stopForeground)stopForeground(g,w,h,t);dust(g,w,h,t,.30,.005)
}
function dispatch(w,h,t){
 const p=h>w;g.save();camera(w,h,1.017+.02*ease(t/4.45),.52,.48);bg(w,h,t,'office');
 cast(g,w*(p?.67:.74),h*(p?1.026:1.08),h*(p?.85:.95),'mum','present',t,-1,null,'cool-office');
 shopFront(g,w,h,t,'office');officeConsole(w,h,t);cup(w*(p?.91:.80),h*.766,h/800);g.restore()
}
function missing(w,h,t){
 const p=h>w;g.save();camera(w,h,1.02+.034*ease(t/2.87),.50,.49);bg(w,h,t,'table');
 let hh=h*(p?1.02:1.04);cast(g,w*(p?.63:.60),h*1.105,hh,'grandpa','study',t,-1,null,'warm-left');
 shopFront(g,w,h,t,'table');
 let ww=w*(p?.55:.37),hh2=ww*.26;page(w*(p?.045:.23),h*.748,ww,hh2,-.045,t,true,0,0);cup(w*(p?.83:.75),h*.793,h/660);g.save();g.beginPath();g.rect(0,h*.723,w,h*.277);g.clip();cast(g,w*(p?.63:.60),h*1.105,hh,'grandpa','study',t,-1,null,'warm-left','nearArm');g.restore();g.restore();dust(g,w,h,t,.39)
}
function paperReveal(w,h,t){g.save();let tighten=ease((t-2.15)/1.31);camera(w,h,1+.22*tighten,h>w?.48:.54,h>w?.54:.55);
 const p=h>w,ww=w*(p?1.48:.91),hh=ww*.637,a=-.108+.012*ease(t/4.1);tabletop(g,w,h,t);
 const aimx=w*(p?.48:.54),aimy=h*(p?.54:.55),origin=pt(0,0,ww,hh,a,575/900,410/560);
 const px=aimx-origin[0],py=aimy-origin[1];
 let stroke=ease((t-.70)/1.42);page(px,py,ww,hh,a,t,true,stroke,0);
 // A used ferry ticket anchors the map to a person, not an abstract dataset.
 g.save();g.translate(w*(p?.09:.11),h*(p?.84:.82));g.rotate(-.19);
 let sw=Math.min(w*.36,h*.34),sh=sw*.36;
 RR(g,0,0,sw,sh,3,'#ddb484','#936f55',1.4);RR(g,6,6,sw-12,sh-12,1.5,null,'#ad8465',1);
 T(g,'FERRY STEPS',sw*.08,sh*.48,sw*.09,'#614e48','Noto Sans',750);T(g,'LOCAL  /  06:20',sw*.084,sh*.72,sw*.045,'#715b4e','Noto Sans',550);g.restore();
 // Compute the same tilted ellipse tip as the atlas, in the atlas's physical paper space.
 const theta=-2.45+TAU*stroke,xx=42*Math.cos(theta),yy=24*Math.sin(theta),rc=Math.cos(-.24),rs=Math.sin(-.24);
 const [tx,ty]=pt(px,py,ww,hh,a,(575+rc*xx-rs*yy)/900,(410+rs*xx+rc*yy)/560);
 const approach=ease((t-.02)/.65),lift=ease((t-2.19)/.76),hold=approach*(1-lift);
 if(window.markingHand)markingHand(g,tx+w*(.12*(1-approach)+.145*lift),ty-h*(.068*(1-approach)+.14*lift),h/(p?487:454),t,hold,theta);
 else hand(g,tx,ty,h/(p?530:460),-.33,t,'point','grandpa');
 shafts(g,w,h,t,{from:.07,slant:.54,a:.08});dust(g,w,h,t,.37);g.restore()
}
function space(w,h,t){
 const op=spaceOptics(w,h,t);g.save();camera(w,h,op.z,.5,.49,op.dx,op.dy);bg(w,h,t,'cosmos');g.restore();orbitMatch(g,w,h,t);
 const f=ease(t/.6)*(1-ease((t-2.8)/.5));g.save();g.globalAlpha=f;const x=w*.075,yy=h*.14,sz=Math.max(17,Math.min(w*.024,h*.031));
 L(g,[[x,yy],[x+sz*1.55,yy]],'#e4a36e',2);T(g,'ASI  /  A POSSIBLE FUTURE',x,yy+sz*1.42,sz,'#e5daba','Noto Sans',600);g.restore()
}
function restore(w,h,t){
 let p=h>w;bg(w,h,t+.5,'office');
 const ww=w*(p?1.11:.80),hh=ww*.59,a=-.045,aimx=w*(p?.51:.54),aimy=h*(p?.58:.60),orig=pt(0,0,ww,hh,a,575/900,410/560),px=aimx-orig[0],py=aimy-orig[1];
 atlas(g,px,py,ww,hh,t,{paper:false,angle:a,mark:ease((t-.5)/.75),selected:ease((t-.43)/.96),focus:true,titleInset:p?224:29});
 const press=ease((t-.08)/.58),release=ease((t-1.18)/.9);
 hand(g,aimx+w*(.18*(1-press)+.13*release),aimy-h*.014-h*.11*(1-press)-h*.10*release,h/(p?580:510),-.32,t,'tap','mum');
}
function endScene(w,h,t,varn='final'){
 const p=h>w;let phase=t,stage=ease((t-.10)/1.4),realOpen=Math.min(1,(t+.18)/1.45);
 g.save();let cameraIn=varn==='land'?1.19:1.015+.07*ease(t/4.55);camera(w,h,cameraIn+(varn==='land'?.018*ease(t/5):0),p?.52:.51,.64,-w*.008*ease(t/5),0);
 bg(w,h,t+2,'dusk');threshold(g,w,h,t,'back',realOpen);if(window.porchLife)porchLife(g,w,h,t);
 let elder={x:w*(p?.715:.661),y:h*.87,h:h*(p?.50:.56)};
 let seat={x:elder.x-elder.h*.472,y:elder.y+elder.h*.014},sUnit=elder.h/280;
 let mum={x:w*(p?.275:.254),y:h*(p?.760:.747),h:h*(p?.43:.48)};
 let walkT=clamp(t-.42,0,1.50),sitT=Math.max(0,t-1.99),girlH=h*(p?.46:.51),endX=seat.x-.043*girlH;let girl={x:endX-w*(p?.164:.093)*(1-ease(walkT/1.50)),y:seat.y,h:girlH};
 shadow(g,mum.x,mum.y,mum.h*.20,mum.h*.041,.38);cast(g,mum.x,mum.y,mum.h,'mum','smile',t,1,null,'dusk-rim');
 shadow(g,elder.x,elder.y,elder.h*.21,elder.h*.043,.43);shadow(g,girl.x,girl.y,girl.h*.18,girl.h*.045,.44);
 stool(g,elder.x+elder.h*.01,elder.y-sUnit*21,sUnit,{blue:false});stool(g,seat.x,seat.y-sUnit*21,sUnit,{blue:true});
 cast(g,elder.x,elder.y,elder.h,'grandpa','invite',Math.max(0,t-.12),-1,null,'dusk-rim');
 let act=t<.42?'listen':t<1.99?'walk':'sitDown',local=t<.42?t+.7:t<1.99?walkT:sitT;cast(g,girl.x,girl.y,girl.h,'teen',act,local,1,null,'dusk-rim');coolingSign(g,w,h,t);
 // The repaired fan keeps the room cool: it is a working object in the last image, not a footnote.
 let rr=Math.min(h*(p?.083:.114),w*.077),fx=w*(p?.841:.836),foot=h*(p?.835:.80);
 stool(g,fx,foot+h*.024,h*(p?.00112:.00125),{blue:false});fan(g,fx,foot-rr*1.59-h*.038,rr,t,{yaw:.72,spin:13.7,phase:1.3+t*13.7});
 shafts(g,w,h,t,{from:.64,slant:-.30,a:.20});dust(g,w,h,t,.64,.010);
 threshold(g,w,h,t,'front',realOpen,varn==='rack');g.restore()
}
let rackBuffer=null;
function sharedLook(w,h,t){
 const p=h>w,gl=ease(t/1.06);
 // A lens from inside the same opened room, looking past the seated pair to the dusk street.
 // Crucially the defocused rear plate has *no duplicate people*, signage or old wind chime.
 g.save();camera(w,h,1.34+.021*gl,p?.55:.58,.48,-w*.015,h*.0);bg(w,h,4+t,'dusk');threshold(g,w,h,4+t,'back',1);g.restore();
 const mw=Math.max(2,Math.round(w*.31)),mh=Math.max(2,Math.round(h*.31));
 if(!rackBuffer||rackBuffer.width!==mw||rackBuffer.height!==mh){rackBuffer=document.createElement('canvas');rackBuffer.width=mw;rackBuffer.height=mh}
 let r=rackBuffer.getContext('2d');r.setTransform(1,0,0,1,0,0);r.clearRect(0,0,mw,mh);r.filter='blur('+Math.max(2.3,h*.014*mh/h)+'px)';r.drawImage(can,0,0,w,h,-6,-6,mw+12,mh+12);r.filter='none';g.drawImage(rackBuffer,0,0,w,h);
 g.fillStyle=G(g,0,0,w,0,[[0,'rgba(51,56,78,.244)'],[.54,'rgba(93,75,82,.061)'],[1,'rgba(244,181,110,.124)']]);g.fillRect(0,0,w,h);
 g.save();camera(w,h,1.004+.013*gl,.54,.50);familyClose(g,w,h,t);g.restore();
 // Two small, distinct light planes bind them to the dusk environment without washing out the ink.
 g.save();g.globalCompositeOperation='screen';g.fillStyle=D(g,w*.87,h*.22,0,Math.min(w,h)*.59,[[0,'rgba(242,171,108,.088)'],[.46,'rgba(242,175,118,.043)'],[1,'rgba(239,167,117,0)']]);g.fillRect(0,0,w,h);g.restore();
 dust(g,w,h,t+.8,.29,-.012)
}
function finalReprise(w,h,t){
 const cT=t+1.32;
 if(t<1.79||(!window.familyClose&&t<2.81)){endScene(w,h,cT);return}
 if(t<2.81&&window.familyClose){sharedLook(w,h,t-1.79);return}
 if(!window.bellClose){endScene(w,h,cT);return}
 // Cut to the same physical room from behind its glass chime. Defocus only the far plane.
 const q=t-2.81,e=ease(q/.62),mw=Math.max(2,Math.round(w*.42)),mh=Math.max(2,Math.round(h*.42));
 g.save();camera(w,h,1.135+.020*ease(q/2.15),.54,.45,-w*.072,h*.018);endScene(w,h,cT,'rack');g.restore();
 if(!rackBuffer||rackBuffer.width!==mw||rackBuffer.height!==mh){rackBuffer=document.createElement('canvas');rackBuffer.width=mw;rackBuffer.height=mh}
 let r=rackBuffer.getContext('2d');r.setTransform(1,0,0,1,0,0);r.clearRect(0,0,mw,mh);r.filter='blur('+((2.3+4.3*e)*mw/w)+'px)';r.drawImage(can,0,0,w,h,-4,-4,mw+8,mh+8);r.filter='none';
 g.drawImage(rackBuffer,0,0,w,h);
 const near=(1-e)*h*.002;g.save();if(near>.2)g.filter='blur('+near.toFixed(2)+'px)';bellClose(g,w,h,q);g.restore();
}
function decision(w,h,t){
 let p=h>w;softShop(g,w,h,t,'office',19,1.47);g.fillStyle='rgba(54,89,102,.115)';g.fillRect(0,0,w,h);
 g.save();camera(w,h,1.024+.029*ease(t/.85),.58,.49);if(window.closeCast)closeCast(g,w,h,t,'mum');
 else{let hh=h*(p?2.23:2.49);cast(g,w*(p?.60:.63),h*.34+hh*.927,hh,'mum','present',t+.34,-1,null,'cool-office')}g.restore();
 // The console bezel is in the near optical plane; her gaze is down-left toward its amber stop.
 g.save();g.filter='blur('+Math.max(3,h*.004)+'px)';P(g,'M 0 '+(h*.72)+' L '+(w*.18)+' '+(h*.754)+' '+(w*.25)+' '+h+' 0 '+h+' Z','#405a5d');
 L(g,[[0,h*.716],[w*.18,h*.750]],'#a4bcb0',h*.006);E(g,w*.066,h*.80,h*.0058,h*.0042,'#c9a171');g.restore()
}
const cutList=window.FILM_CUTS;
window.shots=cutList.map(c=>c.frame/24).concat([40]);
function shot(w,H,t){
 const frame=Math.max(0,Math.min(959,Math.round(t*24))),s=cutList.findLast(c=>c.frame<=frame),u=Math.max(0,t-s.frame/24);
 switch(s.id){
 case 'heat':opening(w,H,u);break;case 'stopped-fan':stalled(w,H,u);break;case 'repair-wide':fixing(w,H,u);break;
 case 'tutor-lens':tutorInsert(g,w,H,u);break;case 'latch':fixInsert(w,H,u);break;case 'ribbon-lifts':ribbonLift(w,H,u);break;case 'first-breeze':relief(w,H,u);break;
 case 'missed-stop':transit(w,H,u);break;case 'dispatcher':dispatch(w,H,u);break;case 'suggestion':routeStudy(g,w,H,u);break;
 case 'paper-at-home':missing(w,H,u);break;case 'grandpa-asks':grandpaLook(g,w,H,u);break;case 'blank-spot':paperReveal(w,H,u);break;
 case 'possible-orbit':space(w,H,u*3.33/2.34);break;case 'shade-scenario':forecast(g,w,H,u*3.58/3.26);break;case 'human-decision':decision(w,H,u);break;
 case 'manual-stop':restore(w,H,u*2.02/1.26);break;
 case 'bus-returns':if(window.returnBus)returnBus(g,w,H,Math.min(1.18,u*1.12));else endScene(w,H,u*1.45);break;
 case 'on-the-step':if(window.boardingClose)boardingClose(g,w,H,u/0.97);else if(window.returnBus)returnBus(g,w,H,Math.min(1.18,(t-34.02)*1.12));else endScene(w,H,u*1.45);break;
 case 'saved-stool':seatInsert(g,w,H,u);break;case 'shared-room':endScene(w,H,.90+u,'land');break;
 default:throw Error('Missing shot renderer '+s.id)
 }
 finish(g,w,H,t,s.grade)
}
window.draw=(w,h,t,variant='final')=>{
 if(can.width!==w||can.height!==h){can.width=w;can.height=h}
 let H=h-(h>w?118:105);g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='source-over';
 g.fillStyle='#000';g.fillRect(0,0,w,h);g.save();g.beginPath();g.rect(0,0,w,H);g.clip();
 if(variant==='ending'||t>=40){finalReprise(w,H,variant==='ending'?t:Math.max(0,t-55));finish(g,w,H,t,'night')}
 else shot(w,H,t);
 sceneJoin(g,w,H,t);g.restore()
};
})();
