// Original theatrical key art, separately art-directed for wide and portrait framing.
const ca=document.querySelector('canvas'),g=ca.getContext('2d');
function draw(w,h,t,flavor="cover"){
 ca.width=w;ca.height=h;let p=h>w,full=h,show=flavor.startsWith("showcase");if(show){g.fillStyle="#000";g.fillRect(0,0,w,h);h-=p?118:105;}
 const {path:P,line:L,ell:E,grad:G,radial:D,rr:RR,text:T,R,TAU}=Art;
 g.fillStyle='#1c303e';g.fillRect(0,0,w,h);
 // Amber-pink summer sky; fine wires and roof eaves are real painted setting layers.
 g.save();g.translate(w*.51,h*.45);g.scale(p?1.28:1.23,p?1.28:1.23);g.translate(-w*.51,-h*.45);
 city(g,w,h,t+1,'dusk');g.restore();
 // Let the sun halo and suspended route line live at a convincing depth behind the heroine.
 const ax=w*(p?.54:.68),ay=h*(p?.275:.30),rad=h*(p?.208:.235);
 g.save();g.fillStyle=D(g,ax,ay,rad*.22,rad*1.65,[[0,'rgba(255,209,134,.28)'],[.42,'rgba(247,196,130,.23)'],[1,'rgba(245,194,151,0)']]);g.fillRect(ax-rad*1.7,ay-rad*1.7,rad*3.4,rad*3.4);
 g.strokeStyle='rgba(255,222,170,.67)';g.lineWidth=h*.002;g.beginPath();g.ellipse(ax,ay,rad*1.04,rad*.97,-.30,-2.40,.69);g.stroke();g.restore();
 let hhero=h*(p?1.55:2.04),hx=w*(p?.645:.745),hy=h*(p?.33:.40)+hhero*.89;
 if(window.closeCast){g.save();g.translate(w*(p?.045:.065),-h*(p?.08:.105));g.scale(p?1.12:1.17,p?1.12:1.17);closeCast(g,w,h,1.42,'teen');g.restore()}else cast(g,hx,hy,hhero,'teen','listen',1.38,-1,null,'dusk-rim');
 let fanx=w*(p?.203:.31),fany=h*(p?.619:.784),fr=h*(p?.235:.30);fan(g,fanx,fany,fr,1.1,{yaw:.78,phase:.54,spin:0});
 shafts(g,w,h,t,{from:.72,slant:-.34,a:.12});dust(g,w,h,.64,.59,.007);finish(g,w,h,t,'night');
 // Optical falloff creates type room, not a rectangular pasted-on card.
 if(p)g.fillStyle=G(g,0,h*.47,0,h,[[0,'rgba(25,35,46,0)'],[.23,'rgba(28,39,50,.45)'],[.53,'rgba(28,39,50,.89)'],[1,'#1c2834']]);
 else g.fillStyle=G(g,0,0,w*.79,h*.25,[[0,'rgba(24,37,48,.98)'],[.36,'rgba(28,42,52,.93)'],[.68,'rgba(33,48,59,.53)'],[1,'rgba(38,52,62,0)']]);
 g.fillRect(0,0,w,h);
 if(p){let x=w*.067,sz=w*.114;T(g,'AN ORIGINAL ANIMATED SHORT',x,h*.695,w*.024,'#e4c49a','Noto Sans',650);
 T(g,'The Empty',x,h*.803,sz,'#f2e4c9','Noto Serif',630);
 T(g,'Stop',x,h*.904,sz*1.11,'#f2e4c9','Noto Serif',630);
 L(g,[[x,h*.931],[w*.925,h*.931]],'#897d6d',1.4);T(g,'MIZUHAMA  /  HIGH SUMMER',x,h*.963,w*.0185,'#d1c4a9','Noto Sans',580);
 T(g,'60 SEC',w*.928,h*.963,w*.022,'#e8cca0','Noto Sans',650,'right')
 }else{let x=w*.062,sz=h*.124;T(g,'AN ORIGINAL ANIMATED SHORT',x,h*.210,h*.026,'#e1bd93','Noto Sans',650);
 T(g,'The Empty',x,h*.408,sz,'#f3e3c9','Noto Serif',640);T(g,'Stop',x,h*.557,sz*1.12,'#f3e3c9','Noto Serif',640);
 L(g,[[x,h*.634],[x+w*.204,h*.634]],'#bd9a71',1.55);
 T(g,'MIZUHAMA  /  HIGH SUMMER',x,h*.690,h*.024,'#daC8a9','Noto Sans',580);
 T(g,'60 SEC      •      ANIME',x,h*.898,h*.022,'#c8bfae','Noto Sans',590)
 }
 if(show){
  const hours=flavor.split('|')[1]||'0.00',pad=p?42:55;
  g.fillStyle='#000';g.fillRect(0,h,w,full-h);
  T(g,'GPT-6.2 Astra',pad,h+(p?54:49),50,'#fff','Noto Sans',700);
  const fs=p?27:24;T(g,'OpenAI Dot  /  Wtruby  /  Canvas 2D + FFmpeg',pad,h+(p?94:88),fs,'#d2d5d2','Noto Sans',500);
  T(g,hours+' h',w-pad,h+(p?94:88),fs,'#fff','Noto Sans',530,'right')
 }

}
