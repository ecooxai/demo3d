// The paper correction is made physically. Tip is the origin; grip and cast shadow follow it.
// Painted for the waterfront sheet, not an emissive interface or reused touch gesture.
window.markingHand=(g,x,y,unit,t,contact,theta)=>{
 const {path:P,line:L,ell:E,grad:G,radial:D,clamp}=Art;
 let q=unit,z=clamp(contact),roll=-.19+.060*Math.sin(theta+.7),oldInk='#69594e',red='#a34f48';
 g.save();g.translate(x,y);g.rotate(roll);g.scale(q,q);g.lineCap='round';g.lineJoin='round';
 // Tiny warm contact occlusion at the red lead and the much softer detached wrist.
 g.save();g.scale(1,.46);E(g,4,5,8,2.8,'rgba(70,56,44,'+(.08+.17*z)+')');g.restore();
 g.save();g.fillStyle=D(g,77,13,1,137,[[0,'rgba(61,53,45,'+(.22+.055*z)+')'],[.48,'rgba(64,51,45,.095)'],[1,'rgba(71,56,48,0)']]);g.translate(2,8);g.scale(1,.42);g.fillRect(-85,-140,290,281);g.restore();
 // Long ochre herringbone cuff exits right of frame at either crop.
 P(g,'M 122 -66 Q 139 -74 162 -74 L 541 -140 610 -28 192 18 Q 160 19 131 -2 Z','#747c64','#535b50',1.6);
 P(g,'M 138 -16 Q 211 -42 244 -39 L 560 -93 610 -28 192 18 142 1 Z','#575f52');
 P(g,'M 151 -63 Q 226 -74 277 -87 L 325 -94 251 -74 161 -55 Z','#9a9977');
 P(g,'M 119 -62 Q 129 -71 146 -72 L 169 -9 Q 162 1 146 4 L 126 6 Z','#9a9977',oldInk,1.3);
 for(let j=0;j<6;j++){let a=125+j*3.6;P(g,'M '+a+' -63 Q '+(a+6)+' -43 '+(a+18)+' -1',null,j%2?'#a8aa85':'#7a8066',.85)}
 // Palm and far fingers, drawn before the writing tool.
 let skin=G(g,48,-80,111,7,[[0,'#efd4a8'],[.46,'#d9b28e'],[1,'#b08a72']]);
 P(g,'M 16 -50 Q 25 -65 44 -73 L 70 -84 Q 82 -90 96 -83 L 126 -68 143 -64 154 -7 Q 132 -6 117 -1 104 3 94 9 Q 87 13 79 10 L 64 2 49 -7 Q 41 -12 42 -19 L 45 -34 30 -31 Q 18 -31 13 -38 11 -43 16 -50 Z',skin,oldInk,1.75);
 P(g,'M 44 -28 Q 49 -35 57 -34 L 81 -17 Q 91 -9 105 -8 Q 113 -8 125 -12 L 137 -13 Q 128 -4 114 1 L 98 8 Q 87 13 79 9 L 57 -1 47 -8 Q 42 -16 44 -28 Z','#b89377');
 P(g,'M 47 -20 Q 57 -23 65 -16 L 80 -3 Q 79 4 73 5 Q 62 3 51 -4 L 44 -11 Q 42 -16 47 -20 Z','#d1aa86',oldInk,1.25);
 P(g,'M 57 -24 Q 62 -26 70 -21 L 88 -9 Q 91 -2 85 1 Q 78 2 71 -3 L 58 -11 Q 53 -16 57 -24 Z','#dbb48e',oldInk,1.2);
 P(g,'M 67 -25 Q 73 -29 82 -22 L 99 -13 Q 102 -8 97 -5 Q 91 -2 84 -6 L 69 -15 Q 65 -18 67 -25 Z','#dbb48e',oldInk,1.1);
 // Original hexagonal oxide-red pencil. Tip actually coincides with the mark endpoint.
 g.save();g.rotate(.50);
 P(g,'M 0 0 L -3.0 -9.2 -4.7 -21.0 -4.7 -129.2 -2.6 -134.4 2.1 -134.5 4.1 -130.5 4.9 -21.0 2.6 -8.2 Z','#ad604f','#694d45',.9);
 P(g,'M -4.3 -21 L -1.5 -22.8 -1.6 -129.9 -4.1 -128 Z','#c98365');
 P(g,'M -1.4 -22.8 L 1.6 -22.1 1.3 -131.3 -1.6 -129.9 Z','#ad5d4b');
 P(g,'M 1.6 -22.1 L 4.6 -20.9 4.0 -130.1 1.3 -131.3 Z','#844b44');
 P(g,'M -4.5 -21.4 L -1.35 -23.6 1.35 -22.2 4.7 -21.3 1.25 -5 -1 -4.6 Z','#dfbc89','#8f755d',.55);
 P(g,'M -1.2 -4.8 L -.1 .4 1.4 -5.8 Z',red);P(g,'M 2.5 -17 L 1.45 -8.2',null,'#a88d6b',.5);
 P(g,'M -4.4 -116.8 L -1.4 -118.1 1.5 -118.1 4.1 -116.9 4.2 -113.3 1.45 -114.8 -1.4 -114.8 -4.6 -113.3 Z','#dbc79b');
 L(g,[[-1,-110],[-1,-93]],'#e0c495',.9);g.restore();
 // Thumb pad and crooked index encircle the barrel, not the air alongside it.
 P(g,'M 18 -47 Q 15 -53 20 -59 L 35 -72 Q 45 -80 52 -79 60 -79 67 -71 L 79 -56 Q 83 -51 78 -47 75 -43 70 -44 L 56 -58 47 -62 31 -48 Q 24 -42 18 -47 Z','#deba96',oldInk,1.55);
 P(g,'M 20 -54 Q 28 -65 41 -72 L 46 -73 Q 41 -69 37 -66 L 26 -54 23 -49 20 -49 Z','#f2d6ad');
 P(g,'M 21 -49 Q 24 -54 28 -55 L 31 -53 Q 29 -48 25 -46 L 21 -46 Z','#efd1ad',oldInk,.6);
 P(g,'M 54 -54 Q 63 -51 64 -43 65 -37 59 -32 L 45 -25 29 -23 Q 21 -22 16 -26 13 -29 15 -33 17 -36 24 -37 L 39 -40 49 -48 Q 50 -53 54 -54 Z','#d8b390',oldInk,1.5);
 P(g,'M 16 -31 Q 19 -35 26 -35 L 29 -34 Q 28 -30 22 -28 18 -28 16 -29 Z','#e9ccab',oldInk,.65);
 P(g,'M 34 -24 Q 46 -26 56 -33 M 46 -64 Q 52 -65 57 -60 M 76 -63 Q 84 -61 89 -54 M 83 -74 Q 89 -75 98 -68 M 110 -55 Q 118 -52 119 -47 M 101 -41 Q 108 -42 114 -36',null,'#a7856c',.95);
 P(g,'M 84 -74 Q 96 -72 104 -65 L 118 -62',null,'#e6c59c',1.45);
 for(const [u,v,a] of [[98,-46,1.1],[107,-48,.7],[88,-57,.9],[102,-39,.6],[49,-67,.7],[120,-37,1.1],[90,-69,.65]])E(g,u,v,a,a*.63,'rgba(137,100,75,.39)');
 g.restore()
};
