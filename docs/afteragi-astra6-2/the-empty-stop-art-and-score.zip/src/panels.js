// Two editorial inserts: a physically mounted general-purpose tutor and the man missing from its map.
(() => {
const {path:P,line:L,ell:E,grad:G,radial:D,rr:RR,text:T,R,TAU,ease,clamp}=Art;
window.tutorInsert=(g,w,h,t)=>{
 const p=h>w,unit=Math.min(w/890,h/610),ww=Math.min(w*(p?.90:.65),h*1.21),hh=ww*.56,cx=w*(p?.49:.49),cy=h*.48;
 softShop(g,w,h,t,'bench',22,1.50);g.fillStyle='rgba(69,66,57,.13)';g.fillRect(0,0,w,h);
 g.save();g.translate(cx,cy);g.rotate(-.048+.009*ease(t/1.16));g.transform(1,0,.052,1,0,0);
 // A scuffed, passive field terminal with a visible lens and illuminated recording indication.
 P(g,'M '+(-ww*.38)+' '+(hh*.47)+' l '+(ww*.75)+' 0 '+(ww*.085)+' '+(hh*.16)+' '+(-ww*.89)+' '+(hh*.018)+' Z','#67726d','#485354',2.4*unit);
 RR(g,-ww*.51,-hh*.56,ww*1.02,hh*1.095,ww*.035,G(g,-ww*.38,-hh*.55,ww*.36,hh*.53,[[0,'#8f9b92'],[.23,'#5c6c6b'],[.66,'#3c5051'],[1,'#5f706a']]),'#2f4243',2.9*unit);
 RR(g,-ww*.487,-hh*.503,ww*.974,hh*.982,ww*.023,'#263a40','#b3b5a0',1.25*unit);
 // Live preview, a close overhead look through the same hardware, not an invented floating UI.
 g.save();let sx=-ww*.451,sy=-hh*.396,sw=ww*.658,sh=hh*.765;g.beginPath();g.roundRect(sx,sy,sw,sh,ww*.012);g.clip();
 g.fillStyle=G(g,sx,sy,sx+sw,sy+sh,[[0,'#9d9b80'],[.7,'#74938a'],[1,'#506e6a']]);g.fillRect(sx,sy,sw,sh);
 let r=sh*.68,fx=sx+sw*.34,fy=sy+sh*.65;fan(g,fx,fy,r,t,{yaw:.70,phase:.40,noBase:true});
 let gx=fx+r*.70*.978,gy=fy+r*.197,gRad=sh*.102;
 // The tutor sees her fingers as well as the part. Entry from the same left-side working lane.
 g.save();g.translate(gx-sh*.026,gy+sh*.046);g.scale(-1,1);hand(g,0,0,sh*.00160,-.17,t,'pinch','teen');g.restore();
 // Corner tracking guides converge without obscuring the screw.
 for(let ax of [-1,1])for(let ay of [-1,1])L(g,[[gx+ax*gRad*.45,gy+ay*gRad],[gx+ax*gRad,gy+ay*gRad],[gx+ax*gRad,gy+ay*gRad*.45]],'#f4cf93',1.9*unit);
 for(let j=0;j<4;j++){let ly=sy+sh*(.19+j*.22);L(g,[[sx+sw*.966,ly],[sx+sw*.988,ly]],'rgba(217,235,206,.53)',unit)}
 g.restore();
 const tx=ww*.247;E(g,tx,-hh*.337,3.1*unit,3.1*unit,'#e3b27d');T(g,'LIVE',tx+8*unit,-hh*.322,ww*.025,'#d5d1b9','Noto Sans',650);
 L(g,[[tx,-hh*.24],[ww*.44,-hh*.24]],'#5e7975',unit);
 T(g,'LOOSE',tx,-hh*.04,ww*.035,'#e6d3a8','Noto Sans',650);T(g,'LATCH',tx,hh*.065,ww*.035,'#a7c7b7','Noto Sans',600);
 for(let i=0;i<14;i++){let xx=tx+i*ww*.013,a=hh*(.015+.049*Math.abs(Math.sin(7.1*i+t*5.6)));L(g,[[xx,hh*.245-a],[xx,hh*.245+a]],i%4===0?'#d9b884':'#83ad9e',ww*.0044)}
 // True camera aperture off the screen. The activity light pulses once as focus locks.
 E(g,0,-hh*.527,ww*.009,ww*.009,'#223b40','#b2b3a0',unit);E(g,0,-hh*.528,ww*.0048,ww*.0048,'#537d83');E(g,-ww*.001,-hh*.532,ww*.0019,ww*.0019,'#c7dcc7');
 let pulse=.55+.35*Math.exp(-((t-.42)**2/.023));E(g,ww*.037,-hh*.527,ww*.0036,ww*.0036,'rgba(222,178,113,'+pulse+')');
 // Gentle sheet-glass glint sits above display but leaves the highlighted contact obvious.
 P(g,'M '+(-ww*.46)+' '+(-hh*.49)+' L '+(-ww*.30)+' '+(-hh*.49)+' '+(ww*.22)+' '+(hh*.46)+' '+(ww*.135)+' '+(hh*.46)+' Z','rgba(203,223,199,.045)');
 for(let k of [-1,1]){E(g,k*ww*.466,hh*.50,unit*2.1,unit*2.1,'#59706b','#a2a791',unit*.5)}
 g.restore();dust(g,w,h,t,.46,.003)
};
window.grandpaLook=(g,w,h,t)=>{
 const p=h>w,hh=h*(p?2.29:2.53),x=w*(p?.57:.58),y=h*(p?.36:.37)+hh*.915;
 softShop(g,w,h,t,'table',21,1.32);g.fillStyle='rgba(228,181,139,.09)';g.fillRect(0,0,w,h);
 if(window.closeCast)closeCast(g,w,h,1.27+t,'grandpa');else cast(g,x,y,hh,'grandpa','study',1.56+t,-1,null,'warm-left');
 // Over-the-shoulder left edge makes his eyeline a conversation rather than a talking icon.
 let f=h*.024;g.save();g.filter='blur('+Math.round(f*.32)+'px)';
 P(g,'M 0 '+(h*.28)+' Q '+(w*.055)+' '+(h*.25)+' '+(w*.099)+' '+(h*.42)+' Q '+(w*.11)+' '+(h*.55)+' '+(w*.06)+' '+(h*.68)+' L '+(w*.14)+' '+(h*.92)+' '+(w*.13)+' '+h+' 0 '+h+' Z','#3e4552');
 P(g,'M 0 '+(h*.65)+' Q '+(w*.072)+' '+(h*.67)+' '+(w*.106)+' '+(h*.83)+' L '+(w*.169)+' '+h+' 0 '+h+' Z','#ad7562');g.restore();
 shafts(g,w,h,t,{from:.19,slant:.34,a:.08});dust(g,w,h,t,.40)
};
window.routeStudy=(g,w,h,t)=>{
 const p=h>w,par=ease(t/1.96),ww=w*(p?1.05:.79),hh=ww*.61,ang=-.025,xx=w*(p?-.035:.093)-w*.013*par,yy=h*(p?.203:.092)+h*.019*par;
 softShop(g,w,h,t,'office',18,1.34);g.fillStyle='rgba(29,47,58,.17)';g.fillRect(0,0,w,h);
 atlas(g,xx,yy,ww,hh,t,{paper:false,angle:ang,drawRoute:.27+.73*ease(t/1.08),focus:true,titleInset:p?80:23});
 g.save();g.translate(xx,yy);g.rotate(ang);
 let tx=ww*.055,ty=hh*.751,sw=ww*.23,sh=hh*.17;
 RR(g,tx,ty,sw,sh,ww*.009,'rgba(23,43,49,.90)','#73918a',ww*.0012);
 T(g,'TRAVEL TIME',tx+sw*.08,ty+sh*.31,sw*.079,'#afcbb8','Noto Sans',600);
 T(g,'−12 MIN',tx+sw*.08,ty+sh*.78,sw*.172,'#f6cd96','Noto Sans',690);
 g.restore();dust(g,w,h,t,.26)
};
})();
