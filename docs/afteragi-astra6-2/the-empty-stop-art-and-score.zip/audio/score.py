#!/usr/bin/env python3
"""Original cues for The Empty Stop. All timbres, ambience, room and score synthesized here, no sampled instruments."""
from pathlib import Path
import wave, numpy as np, math
p=Path(__file__).resolve().parent
sr=48000; D=60; rng=np.random.default_rng(11137)
dry=np.zeros((sr*D,2),'f'); wet=np.zeros_like(dry)
tau=2*math.pi
def tm(d): return np.arange(max(1,round(sr*d)),dtype='d')/sr
def hz(n): return 440*2**((n-69)/12)
def noise(t,rate):
    points=np.arange(0,len(t)+sr/rate,sr/rate); return np.interp(np.arange(len(t)),points,rng.standard_normal(len(points)))
def pan(x): return np.array([math.cos((x+1)*math.pi/4),math.sin((x+1)*math.pi/4)],'f')
def add(t0,s,v=.2,pos=0,rv=.22):
    a=round(t0*sr); start=max(0,-a); a=max(0,a); l=min(len(s)-start,len(dry)-a)
    if l<1:return
    s=np.asarray(s[start:start+l]*v,dtype='f')
    lr=s[:,None]*pan(pos); dry[a:a+l]+=lr
    if rv: wet[a:a+l]+=lr*rv
def ease(t,a,r):
    return np.minimum(1,t/max(1/sr,a))**1.5*np.minimum(1,(t[-1]-t)/max(1/sr,r))**1.5
def piano(at,n,hold=1.4,v=.21,pp=None):
    f=hz(n); d=min(5.8,hold+1.7); t=tm(d); ph=tau*f*t
    rel=np.exp(-np.maximum(0,t-hold)*3.8)
    b=.000035*(f/440)**.8; tone=np.zeros(len(t),'d')
    for k,amp in enumerate([1,.40,.26,.135,.073,.035,.018],1):
        part=ph*k*(1+b*k*k)**.5; phase=.23*k
        decay=np.exp(-t*(.62+.12*k)*(f/350)**.23)
        tone+=amp*decay*(.57*np.sin(part+phase)+.28*np.sin(part*(1.00094)+phase)+.15*np.sin(part*.9985+phase))
    hammer=(noise(t,1600)*.09+noise(t,230)*.12)*np.exp(-t*46)
    attack=(1-np.exp(-t/.004)); tone=(tone+hammer)*attack*rel*ease(t,.001,.15)
    add(at,tone,v, np.clip((n-62)/45,-.6,.6) if pp==None else pp,.33)
def string(at,n,d,v=.09,pan0=-.4,slow=.55,kind=0):
    t=tm(d); f=hz(n)
    for j in range(3):
        wob=rng.uniform(4.25,5.7); phase=rng.uniform(0,tau)
        ph=tau*f*(1+(j-1)*.0016)*t+(.00115*f/wob)*np.sin(tau*wob*t+phase)+.00020*f*np.sin(tau*.78*t+phase)
        harmon= [1,.43,.29,.11,.075,.042] if kind==0 else [1,.16,.12,.07,.021]
        s=sum(a*np.sin((k+1)*ph+.06*k) for k,a in enumerate(harmon))
        express=(.76+.16*np.sin(t/d*math.pi*1.25)+.06*np.sin(tau*.64*t+phase))*ease(t,slow,min(.65,d*.35))
        add(at+j*.011,s*express,v*(.38 if j==1 else .30),np.clip(pan0+.17*(j-1),-1,1),.5)
def glass(at,n,d,v,side):
    t=tm(d); ph=tau*hz(n)*t
    out=sum(a*np.sin(r*ph)*np.exp(-t*b) for r,a,b in [(1,1,.85),(2.003,.38,1.6),(3.997,.15,2.6),(5.36,.1,4.7)])
    add(at,out*ease(t,.004,.25),v,side,.53)
def dud(at,n=41,v=.10):
    t=tm(.6); ph=tau*(hz(n)*t+1.7*(1-np.exp(-t*29)))
    s=(np.sin(ph)*np.exp(-t*9)+noise(t,220)*np.exp(-t*32)*.23)*ease(t,.004,.09)
    add(at,s,v,-.06,.15)
def foley(at,d,bands,v,side,attack=.03,release=.12,wetness=.1,decay=0):
    t=tm(d); a=sum(g*noise(t,f) for f,g in bands)*ease(t,attack,release)*np.exp(-t*decay)
    add(at,a,v,side,wetness)
# City heat. Separate stereo airfields, a drifting pair of insect trills, a faulty motor.
for base,d,level in [(0,9,.045),(12,7.6,.030),(20,6.8,.025),(34,5.9,.035),(55,5.0,.026)]:
    for side in [-.85,.8]:
        foley(base,d,[(145,.65),(930,.29),(3600,.08)],level,side,.6,.65,0)
for at,d,v in [(.25,3.1,.014),(2.7,2.7,.009),(34.2,2.0,.009),(55.6,1.7,.007)]:
    t=tm(d); ph=tau*(2980*t+2.8*np.sin(tau*4.4*t)); flutter=np.maximum(0,np.sin(tau*35*t))**1.6
    add(at, (np.sin(ph)+.5*np.sin(ph*1.08))*flutter*ease(t,.35,.42),v,.68,.09)
for at in [1.12,1.38,2.72,5.34,7.78,8.09]:
    foley(at,.11,[(820,.72),(4400,.3)],.09 if at<5 else .13,-.34,.002,.028,.10,35)
# Human hand seats the bearing; vibration ramps up, then stable blade air.
at=9.46; t=tm(3.15); ramp=1-np.exp(-t*1.8); ph=tau*(37*t+5.8/.62*(.62*t+np.exp(-.62*t)-1))
motor=(.36*np.sin(ph)+.15*np.sin(2*ph)+noise(t,590)*(.16+.32*(.5+.5*np.sin(ph*.37))))*ramp*ease(t,.02,.52)
add(at,motor,.16,-.32,.15)
# Cooling bus brake valve, door relay, two restrained map selector contacts.
for a in [15.88,16.19,19.48,22.11,26.22]: foley(a,.10,[(780,.65),(3800,.25)],.092,.19,.002,.033,.18,29)
foley(21.24,.48,[(3700,.45),(950,.7)],.064,-.58,.035,.22,.16)
# Grandfather's paper and marker; city vision has air rather than a trailer boom.
for at,d,v in [(23.30,.24,.07),(23.65,.34,.063),(24.16,.18,.05)]:
    foley(at,d,[(3200,.72),(700,.3)],v,-.35,.008,.065,.13)
for side in [-.75,.72]:
    foley(26.24,3.69,[(170,.60),(1100,.32),(5100,.09)],.065,side,1.42,1.8,.60)
# Harmonic bed, sparse to increasing family of timbres; six-eighths implied, rubato.
chords=[
(0.35, [50,57,61,64,66],.52),(3.60,[43,54,59,62,66],.61),
(6.56,[47,54,57,62,64],.73),(9.7,[45,55,59,62,64],.79),
(12.15,[50,57,61,64,66],.83),(15.3,[42,52,57,61,66],.83),
(18.35,[43,54,59,62,69],.73),(21.52,[47,54,57,61,66],.64),
(24.60,[40,52,55,59,66],.69),(27.05,[43,54,57,62,66],1.01),
(30.15,[47,54,62,66,69],1.05),(33.05,[45,52,55,62,64],.8),
(35.14,[50,57,61,64,66],.8),(38.12,[43,54,59,62,66],.66),
(40.03,[47,54,57,62,66],.74),(42.45,[43,54,59,62,66],.76),
(45.0,[50,57,61,64,66],.86),(47.64,[42,52,57,61,66],.85),
(50.22,[43,54,59,62,69],.91),(52.78,[45,52,55,62,64],.91),
(54.98,[43,54,59,62,66],.88),(57.06,[50,57,61,64,66],.66)]
for i,(at,ns,lev) in enumerate(chords):
    span=(chords[i+1][0] if i+1<len(chords) else 60.0)-at; h=span*.88
    piano(at,ns[0],h,.16*lev,-.35)
    for j,(off,k,dyn) in enumerate([(.065,1,.115),(.24,2,.088),(.41,3,.077)]):
        piano(at+off,ns[k],max(.62,h-off),lev*dyn)
    if i>=2:
        for j,k in enumerate([0,2,3]):
            if i<4 and j>0:continue
            string(at+.09+j*.07,ns[k]+(0 if j==0 else 0),span+.35,.048*lev*(1.45 if 27<=at<34 else 1),[-.45,-.19,.36][j],min(.9,span*.26),int(j>0))
    if (12<=at<20) or 27<=at<33.1 or 40<=at<55:
        dur=span/6
        for j,k in enumerate([1,2,4,3,1,2]):
            if 40<=at<42 and j in (1,4):continue
            piano(at+j*dur+.055,ns[k]+(12 if k in (1,2) else 0),.27,.056*lev*(1.20 if j%3==0 else .82),(-.18 if j%2==1 else .31))
    if 26.8<=at<33.5 or 42<=at<55:
        dud(at,ns[0] if ns[0]<48 else ns[0]-12,.116); dud(at+span*.52,ns[0],.04)
# Original four-note rising "human hand" cell: hesitate, lift, fall, settle.
mel=[(1.72,66,.85,.70),(2.83,69,.57,.63),(3.57,71,1.10,.74),(5.05,64,.92,.56),
(6.75,66,.63,.78),(7.57,69,.54,.81),(8.40,74,.90,.94),(9.76,73,.42,.64),(10.42,69,1.16,.76),
(12.60,66,.67,.88),(13.58,69,.39,.68),(14.04,71,.83,.80),(15.21,73,1.14,.85),
(16.79,69,.50,.78),(17.55,66,.85,.70),(18.81,67,.96,.82),(20.12,62,1.10,.57),
(21.84,61,.70,.61),(22.82,64,.62,.63),(24.08,66,.48,.68),(24.88,64,1.02,.63),
(27.28,71,.82,1.0),(28.31,74,.61,.87),(29.13,78,1.07,1.04),(30.58,76,.60,.86),
(31.37,73,.62,.84),(32.14,74,1.02,.94),(33.49,69,.65,.69),(35.39,66,.71,.77),
(36.31,69,.60,.75),(37.19,71,.70,.77),(38.31,67,.72,.66),(39.26,66,.53,.59),
(40.84,62,.50,.52),(42.72,66,.47,.67),(43.49,69,.42,.73),(44.31,71,.53,.76),
(45.14,74,.73,.85),(46.25,73,.35,.64),(46.77,69,.51,.66),(47.77,66,.56,.75),
(48.54,64,.51,.68),(49.38,69,.50,.71),(50.36,71,.57,.84),(51.20,74,.45,.83),
(52.00,78,.72,.90),(52.93,76,.48,.81),(53.73,73,.55,.77),
(55.40,71,.74,.84),(56.38,69,.48,.77),(57.14,66,.67,.80),(58.03,62,1.42,.77)]
for at,n,h,v in mel:
    piano(at,n,h,v*.235,.10)
    if 27<=at<33 or 50<=at<56.9:
        string(at+.028,n,h+.34,.068*v,.28,min(.20,h*.25))
    if 27<=at<32 or (55.3<at<58.2 and n<=69):
        glass(at+.07,n+12,h+1.1,.024*v,.55)
# Deliberately separated crescent of upper harmonics during the ASI vision.
for i,n in enumerate([76,78,81,85,88,90]): glass(26.41+i*.235,n,2.4,.038 if i<4 else .022,-.55+i*.17)
# Tactile workprints beat markers, recorded nowhere; triggered narrowly so the montage breathes.
for k,at in enumerate([40.06,42.45,45.0,47.64,50.22,52.78]):
    foley(at,.11,[(850,.6),(3200,.3)],.048,(-1)**k*.28,.001,.035,.14,26)
# Recut 07: let the deciding person briefly come forward without new musical notes.
a,z=round(31.72*sr),round(33.42*sr)
u=np.linspace(0,1,z-a)
duck=1-.158*np.sin(np.pi*u)**2
dry[a:z]*=duck[:,None]; wet[a:z]*=(.5+.5*duck)[:,None]
# Picture-conformed effects. Synthesized in distinct close/distant acoustic scales.
def busmotion(at,d,strength,returning=False):
    t=tm(d); u=t/d
    move=np.cos(np.pi*u)
    # Gliding induction tone and wheel wash. Doppler maps to position, not pitch alone.
    ph=tau*((97 if returning else 111)*t + (8 if returning else 12)*d/np.pi*np.sin(np.pi*u))
    wave=(.47*np.sin(ph)+.18*np.sin(ph*1.51)+.12*np.sin(ph*2.00)+.06*np.sin(ph*3.015))
    wash=.34*noise(t,510)+.12*noise(t,2400)+.04*noise(t,6400)
    shape=ease(t,d*.28,d*.42)*(.71+.20*(1-move)/2+.09*np.sin(2.6*np.pi*u))
    x=(.55+.10*np.sin(np.pi*u)) if returning else -.63*move+.05
    s=(wave+wash)*shape*strength
    add(at,s*np.sqrt((1-x)*.5),1,-1,.15)
    add(at,s*np.sqrt((1+x)*.5),1,1,.17)
def palmwood(at,dt=.26,vol=.115,side=-.21,shade=1.0):
    t=tm(dt)
    # Flesh transient and dowel-like seat-board resonances with nonuniform decays.
    strike=(.42*noise(t,970)+.27*noise(t,2740)+.24*noise(t,260))*np.exp(-t*155)
    wood=sum(a*np.sin(tau*f*shade*t+ph)*np.exp(-t*b) for a,f,b,ph in
             [(.87,112,19,.07),(.34,181,29,.46),(.28,261,37,.54),(.11,378,54,.78),(.045,854,81,.9)])
    add(at,(strike+wood)*ease(t,.0018,.04),vol,side,.10)
def airglass(at,n,v,side):
    t=tm(1.55); ph=tau*hz(n)*t
    voice=sum(a*np.sin(ph*k+.20*k)*np.exp(-t*b) for a,k,b in [(1,1,2.35),(.31,2.006,3.6),(.21,3.74,5.1),(.15,5.09,7.7)])
    whisper=noise(t,2800)*.05*np.exp(-t*44)
    add(at,(voice+whisper)*ease(t,.003,.18),v,side,.32)
# Repaired fan transitions from mechanical motor to steady air by the relief insert.
for side in [-.5,.54]:
    foley(10.31,1.91,[(420,.75),(1350,.27),(3500,.09)],.022,side,.46,.37,.06)
# First transit glimpse: soft pull-past and pneumatic release. No exaggerated horn.
busmotion(12.19,2.54,.077)
foley(12.39,.52,[(3200,.39),(780,.6)],.042,.42,.065,.35,.12)
# Soft airflow through forecast and decision, no second electronic composition.
for side in [-.40,.46]:
    foley(28.55,3.05,[(210,.49),(950,.32),(3900,.09)],.020,side,1.10,1.04,.22)
# Map contact and pressure release as the route returns.
foley(33.112,.09,[(890,.49),(2190,.31)],.062,.15,.001,.030,.09,36)
foley(33.46,.34,[(380,.55),(1400,.32),(3100,.11)],.019,.27,.11,.17,.16)
# Returned bus settles first, then separate slight breath, glide and latch at 34.64.
busmotion(33.89,.91,.065,True)
foley(34.14,.47,[(3300,.48),(1900,.39),(690,.43)],.059,.52,.051,.24,.14)
foley(34.28,.40,[(420,.47),(1004,.41),(2800,.12)],.056,.48,.020,.18,.11)
foley(34.632,.10,[(680,.31),(1800,.45),(3650,.22)],.061,.52,.002,.031,.11,24)
foley(34.66,.91,[(380,.59),(970,.29),(3200,.085)],.017,.52,.37,.28,.10)
# Acoustic foreground crosses the edit: hand touches wood twice, then a hesitant approach.
foley(35.63,.32,[(820,.53),(2450,.23)],.017,-.16,.14,.13,.08)
palmwood(35.930,.24,.111,-.19,.97)
palmwood(36.400,.23,.096,-.15,1.03)
def shoestep(at,vol,side,firmness=1):
    t=tm(.16); ph=tau*(80*t+1.9*(1-np.exp(-t*19)))
    heel=.34*np.sin(ph)*np.exp(-t*46)+.38*noise(t,440)*np.exp(-t*48)
    roll=(.19*noise(t,1490)+.08*noise(t,4750))*np.exp(-t*25)
    add(at,(heel*firmness+roll)*ease(t,.002,.033),vol,side,.12)
shoestep(37.350,.055,.37,.9)
shoestep(37.830,.042,.15,.8)
foley(38.29,.39,[(580,.52),(1380,.39),(2700,.10)],.028,-.12,.115,.17,.09)
palmwood(38.470,.20,.059,-.18,.84)
# Ambient branches and cooling cloth support the pause; leave a gap as she rests.
for side in [-.62,.54]:
    foley(37.08,2.81,[(290,.47),(910,.31),(3070,.11)],.016,side,.51,.67,.075)
# Actual hanging glass reacts to a brief gust. Leave the resolving piano unmasked.
for side in [-.47,.6]:
    foley(58.18,1.74,[(390,.43),(1160,.39),(2800,.21)],.020,side,.39,.44,.12)
airglass(58.598,86,.064,.56)
airglass(58.727,93,.023,.66)
airglass(59.04,86,.019,.47)
# Recut 08 sync touches. Add after the established score so its RNG/mix is unchanged.
def dead_contact(at):
    t=tm(.102)
    # The failing rocker clicks dry, with no motor or electrical UI ping.
    plastic=.57*noise(t,4100)*np.exp(-t*255)+.17*noise(t,1200)*np.exp(-t*151)
    spring=.60*np.sin(tau*1070*t+.24)*np.exp(-t*312)+.27*np.sin(tau*1760*t)*np.exp(-t*370)
    add(at,(plastic+spring)*ease(t,.00075,.014),.082,-.28,.09)
    foley(at+.047,.044,[(1600,.38),(4700,.40)],.020,-.27,.0009,.012,.07,106)
dead_contact(4.520)
# The ribbon is already carried by the motor's broadband wash; no extra whoosh.
# Rubber footfalls on steel differ from the dry pavement under the later two steps.
def tread(at):
    t=tm(.17)
    heel=.44*noise(t,400)*np.exp(-t*63)+.22*noise(t,1700)*np.exp(-t*86)
    friction=.17*noise(t,3600)*np.exp(-t*75)
    rails=.19*np.sin(tau*292*t+.2)*np.exp(-t*45)+.12*np.sin(tau*796*t+.2)*np.exp(-t*73)
    add(at,(heel+friction+rails)*ease(t,.0017,.030),.082,.44,.13)
tread(35.290)
# The existing door latch remains the single transient; fold adds only movement.
foley(34.645,.152,[(460,.47),(1280,.32),(2920,.19)],.017,.52,.024,.074,.085,2)
# Stereo hall: baked sparse deterministic early reflections and decorrelated damped feedback paths.
room=np.zeros_like(dry)
for delay,level,cross in [(.023,.22,True),(.041,.16,False),(.061,.13,True),(.087,.11,False),(.119,.09,True)]:
    off=round(delay*sr); tap=wet[:,::-1] if cross else wet;room[off:]+=level*tap[:-off]
for sample,fb,lev in [(3467,.73,.100),(4391,.70,.090),(5129,.68,.082),(6151,.65,.073)]:
    off=sample
    for k in range(1,17):
        i=off*k; tap=wet[:,::-1] if k%2 else wet
        room[i:]+=lev*fb**(k-1)*tap[:-i]
dry+=room
t=np.arange(len(dry))/sr
dry*=np.minimum(1,t/.075)[:,None]*np.minimum(1,(60-t)/.89)[:,None]
# Optimize stereo output gently without a sustained compressor or hard clipping.
dry=np.tanh(dry*.94); dry*=.89/max(1e-7,np.max(np.abs(dry)))
with wave.open(str(p/'score.wav'),'wb') as w:
    w.setnchannels(2); w.setsampwidth(2);w.setframerate(sr);w.writeframes(np.rint(dry*32767).astype('<i2').tobytes())
print('score.wav 60.000s / 48 kHz stereo, peak',20*np.log10(np.max(np.abs(dry))))

