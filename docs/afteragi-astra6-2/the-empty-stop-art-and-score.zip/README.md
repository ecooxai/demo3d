# The Empty Stop — original art and score

This small optional companion contains the original drawing, camera, animation, English text and score-synthesis source for The Empty Stop, an animated short about a public AI tutor, a missed bus stop, and who gets to choose. No preexisting character art, footage, sound loops or stock assets are required. The same program composes separate 1600×1000 and 1000×1200 views.

**What is not included:** The film's 40–55-second first-iteration and progress reel uses genuine historic MP4 captures. Those evidence archives remain local/private, not in this download. This is NOT represented as a standalone reconstruction of the complete released 60-second binary. Finished mastered films include editorial subtitles/black credits and AAC audio.

## Art preview and original score
Use installed Chromium, Node.js 22 or later with native WebSocket support, FFmpeg, Python 3 with NumPy, and suitable Noto Sans/Serif/CJK system fonts. No remote art services or external images are used. Run from the extracted folder.

~~~sh
# 3-second native image sequence rendered into a wide silent MP4
node src/capture.mjs src/film.html example-wide.mp4 1600 1000 22.75 3 24 final
# The original last art pass, natively composed for portrait
node src/capture.mjs src/film.html ending-portrait.mp4 1000 1200 0 5 24 ending
# Recreate the tone, instrumentation and foley as an original 60-second stereo score.wav
(cd audio && python3 score.py)
~~~

For long outputs, render the 0–40 narrative in five-second chunks. In unusually long directory paths, set FILM_RENDER_TMP to a short private writable directory so Chromium can create its local Unix socket. The authoring code speaks to its own localhost headless Chromium debugger only, not to a hosted rendering service.

The public inventory lists every included file and SHA-256. It omits private operation records, accounts, previous workprints, machine paths and upload configurations.
